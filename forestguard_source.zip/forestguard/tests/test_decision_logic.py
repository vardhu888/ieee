"""Unit tests for fusion, the agent's decision rules, the audit log and
the vibration DSP/simulator. Run: pytest -q"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from forestguard import config  # noqa: E402
from forestguard import vibration_dsp as vd  # noqa: E402
from forestguard import vibration_sim as vs  # noqa: E402
from forestguard.agent import Action, AgentConfig, ForestGuardAgent, State, WindowObservation  # noqa: E402
from forestguard.fusion import FamilyLikelihoods, fuse_window  # noqa: E402


@pytest.fixture
def lik():
    """Likelihood table where human_gait is typical of human_movement,
    machinery of vehicles/logging, weather of weather, none of everything else."""
    tg, pf = [], []
    def add(g, fam, n):
        tg.extend([g] * n); pf.extend([fam] * n)
    add("human_movement", "human_gait", 80); add("human_movement", "none", 20)
    add("vehicle", "machinery", 90); add("vehicle", "none", 10)
    add("logging", "machinery", 40); add("logging", "none", 60)
    add("human_voice", "none", 90); add("human_voice", "human_gait", 10)
    add("firearm_proxy", "transient", 40); add("firearm_proxy", "none", 60)
    add("weather", "weather", 70); add("weather", "none", 30)
    add("wildlife", "none", 95); add("wildlife", "weather", 5)
    add("large_animal", "animal_gait", 60); add("large_animal", "none", 35); add("large_animal", "human_gait", 5)
    return FamilyLikelihoods.fit(tg, pf)


def obs(i, probs, fam=None, conf=0.9, available=None, rms=0.05):
    full = {c: 0.0 for c in config.FOREST_CLASSES}
    full.update(probs)
    rest = 1 - sum(probs.values())
    if rest > 0:
        full["chirping_birds"] += rest
    return WindowObservation(i, 5.0 * i, full, vib_available=(fam is not None) if available is None else available,
                             vib_family=fam, vib_family_conf=conf, vib_rms=rms)


QUIET = {"chirping_birds": 0.95}
STEPS = {"footsteps": 0.85}


# ------------------------------------------------------------ fusion
def test_vibration_support_raises_and_absence_lowers(lik):
    gp = {"human_movement": 0.6}
    base = fuse_window(gp, 0.6, None, 0, lik)
    sup = fuse_window(gp, 0.6, "human_gait", 0.9, lik)
    against = fuse_window(gp, 0.6, "animal_gait", 0.9, lik)
    assert "vibration_missing" in base.flags and base.p_fused == pytest.approx(0.6, abs=1e-3)
    assert sup.p_fused > 0.85 > base.p_fused > against.p_fused


def test_absence_is_context_dependent(lik):
    """No vibration is strong evidence against a vehicle, weak against logging."""
    v = fuse_window({"vehicle": 0.7}, 0.7, "none", 0.9, lik)
    lg = fuse_window({"logging": 0.7}, 0.7, "none", 0.9, lik)
    assert v.terms["vib_log_lr_type"] < lg.terms["vib_log_lr_type"]


def test_frequency_match_adds_evidence(lik):
    m = fuse_window({"vehicle": 0.6}, 0.6, "machinery", 0.9, lik, audio_f0=40, vib_dom_freq=41, vib_tonality=0.9)
    mm = fuse_window({"vehicle": 0.6}, 0.6, "machinery", 0.9, lik, audio_f0=40, vib_dom_freq=63, vib_tonality=0.9)
    assert "frequency_match" in m.flags and "frequency_mismatch" in mm.flags
    assert m.p_fused > mm.p_fused


def test_conflict_flagged(lik):
    r = fuse_window({"vehicle": 0.9}, 0.9, "none", 0.9, lik)
    assert any(f.startswith("conflict") for f in r.flags)


# ------------------------------------------------------------ agent rules
def test_single_uncorroborated_window_does_not_escalate(lik):
    ag = ForestGuardAgent(lik)
    d = ag.step(obs(0, STEPS, None, available=False))
    assert d.action != Action.ESCALATE.value and not ag.alerts
    assert ag.state == State.WATCH


def test_corroborated_persistence_escalates(lik):
    ag = ForestGuardAgent(lik, AgentConfig(immediate_p=1.01))  # isolate the persistence rule
    d0 = ag.step(obs(0, STEPS, "human_gait"))
    assert d0.action != Action.ESCALATE.value
    d = ag.step(obs(1, STEPS, "human_gait"))
    assert d.action == Action.ESCALATE.value and ag.alerts[0]["threat_type"] == "human_presence"
    assert ag.alerts[0]["corroborated"]


def test_missing_vibration_requires_extra_window(lik):
    ag = ForestGuardAgent(lik)
    for i in range(2):
        ag.step(obs(i, STEPS, None, available=False))
    assert not ag.alerts
    ag.step(obs(2, STEPS, None, available=False))
    assert len(ag.alerts) == 1


def test_footsteps_and_voices_count_as_one_incident(lik):
    ag = ForestGuardAgent(lik, AgentConfig(immediate_p=1.01))
    ag.step(obs(0, {"laughing": 0.8}, "none"))
    ag.step(obs(1, {"footsteps": 0.8}, "human_gait"))
    assert len(ag.alerts) == 1 and ag.alerts[0]["threat_type"] == "human_presence"
    v1 = ForestGuardAgent(lik, AgentConfig(immediate_p=1.01, merge_human=False, expectation_aware_bar=False))
    v1.step(obs(0, {"laughing": 0.8}, "none"))
    v1.step(obs(1, {"footsteps": 0.8}, "human_gait"))
    assert not v1.alerts


def test_no_extra_bar_where_ground_coupling_is_not_expected(lik):
    """Voices rarely couple into the ground, so 'no vibration' must not raise the bar."""
    ag = ForestGuardAgent(lik, AgentConfig(immediate_p=1.01))
    assert ag.expected_coupling("human_voice") < 0.5 <= ag.expected_coupling("vehicle")
    ag.step(obs(0, {"laughing": 0.8}, "none"))
    d = ag.step(obs(1, {"coughing": 0.8}, "none"))
    assert d.action == Action.ESCALATE.value
    assert any("rarely couples" in r for r in ag.log.records[0]["reasons"])


def test_immediate_escalation_with_strong_corroboration(lik):
    ag = ForestGuardAgent(lik)
    d = ag.step(obs(0, {"engine": 0.97}, "machinery"))
    assert d.action == Action.ESCALATE.value


def test_storm_context_raises_bar_for_engine_like_types(lik):
    def run(cfg):
        ag = ForestGuardAgent(lik, cfg)
        for i in range(4):
            ag.step(obs(i, {"thunderstorm": 0.95}, None, available=False))
        for i in range(4, 7):
            ag.step(obs(i, {"engine": 0.6, "thunderstorm": 0.3}, None, available=False))
        return ag
    with_ctx, without = run(AgentConfig()), run(AgentConfig(use_context=False))
    assert len(without.alerts) == 1 and len(with_ctx.alerts) == 0


def test_firearm_single_event(lik):
    ag = ForestGuardAgent(lik)
    d = ag.step(obs(0, {"fireworks": 0.93}, None, available=False))
    assert d.action == Action.ESCALATE.value and ag.alerts[0]["threat_type"] == "firearm_proxy"


def test_no_duplicate_alerts_and_cooldown(lik):
    ag = ForestGuardAgent(lik)
    for i in range(5):
        ag.step(obs(i, STEPS, "human_gait"))
    assert len(ag.alerts) == 1 and ag.state == State.ESCALATED
    for i in range(5, 5 + ag.cfg.cooldown):
        d = ag.step(obs(i, QUIET, "none"))
    assert d.action == Action.DE_ESCALATE.value and ag.state == State.MONITORING


def test_on_demand_vibration_duty_cycle(lik):
    ag = ForestGuardAgent(lik)
    for i in range(10):
        d = ag.step(obs(i, QUIET, "none"))
        assert not d.vibration_used
    assert ag.summary()["vibration_duty_cycle"] == 0.0
    d = ag.step(obs(10, {"footsteps": 0.4}, "human_gait"))
    assert d.vibration_used


def test_duty_cycled_vibration_is_not_reported_as_missing(lik):
    ag = ForestGuardAgent(lik)
    d = ag.step(obs(0, QUIET, "none"))
    assert "vibration_not_requested" in d.flags and "vibration_missing" not in d.flags
    d = ag.step(obs(1, STEPS, None, available=False))
    assert "vibration_missing" in d.flags


def test_sensor_maintenance_flag(lik):
    ag = ForestGuardAgent(lik, AgentConfig(vib_policy="always"))
    for i in range(5):
        d = ag.step(obs(i, QUIET, None, available=False))
    assert ag.sensor_flagged and "sensor_maintenance" in d.flags


def test_noisy_sensor_is_downweighted(lik):
    ag = ForestGuardAgent(lik, AgentConfig(vib_policy="always"))
    for i in range(30):
        ag.step(obs(i, QUIET, "none", rms=0.15))
    d = ag.step(obs(30, STEPS, "human_gait"))
    assert "vibration_downweighted" in d.flags


def test_every_decision_explained_and_log_tamper_evident(lik):
    ag = ForestGuardAgent(lik)
    for i in range(6):
        ag.step(obs(i, STEPS if i % 2 else QUIET, "human_gait" if i % 2 else "none"))
    assert all(r["reasons"] for r in ag.log.records)
    assert ag.log.verify()
    ag.log.records[2]["p_fused"] = 0.0
    assert not ag.log.verify()


# ------------------------------------------------------------ vibration
def test_simulation_reproducible_and_labelled(tmp_path):
    p = vs.SimParams(dropout_p=0)
    a = vs.simulate_window("1-1-A-0.wav", "engine", p, scenario_key="k")
    b = vs.simulate_window("1-1-A-0.wav", "engine", p, scenario_key="k")
    c = vs.simulate_window("1-1-A-0.wav", "engine", p, scenario_key="other")
    assert np.array_equal(a.signal, b.signal) and not np.array_equal(a.signal, c.signal)
    assert a.meta["simulated"] is True
    path = tmp_path / "w.csv"
    vs.to_csv(a, path)
    assert path.read_text().startswith("# SIMULATED")


def test_dropout_returns_missing():
    w = vs.simulate_window("x.wav", "engine", vs.SimParams(dropout_p=1.0))
    assert not w.available and w.signal is None


def test_dsp_dominant_frequency_and_cadence():
    fs = config.VIB_SR
    t = np.arange(5 * fs) / fs
    tone = np.sin(2 * np.pi * 50 * t) + 0.05 * np.random.default_rng(0).normal(size=t.size)
    assert abs(vd.analyse(tone).dom_freq - 50) < 1.5
    imp = np.zeros_like(t)
    for t0 in np.arange(0.1, 5, 0.5):  # 2 Hz impulse train
        i = int(t0 * fs)
        k = np.sin(2 * np.pi * 25 * t[:100]) * np.exp(-t[:100] / 0.03)
        imp[i:i + 100] += k[: len(imp) - i]
    f = vd.analyse(imp + 0.02 * np.random.default_rng(1).normal(size=t.size))
    assert abs(f.cadence_hz - 2.0) < 0.15 and f.n_peaks >= 8


def test_analyse_rejects_bad_input():
    with pytest.raises(ValueError):
        vd.analyse(np.array([np.nan] * 2500))
