// Builds FORESTGUARD_Technical_Report.docx from results/results_summary.json.
// Every number in the report is read from the results files, never typed in.
// Usage: node report/build_report.js
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, ImageRun, LevelFormat, PageBreak, Footer, PageNumber,
  TableOfContents, Header,
} = require("docx");

const ROOT = path.resolve(__dirname, "..");
const R = path.join(ROOT, "results");
const FIG = path.join(R, "figures");
const S = JSON.parse(fs.readFileSync(path.join(R, "results_summary.json"), "utf8"));

// ------------------------------------------------------------ helpers
const FONT = "Arial";
const W = 9026; // A4 text width in DXA with 1" margins
const pct = (x, d = 1) => (100 * x).toFixed(d) + "%";
const f3 = (x) => Number(x).toFixed(3);
const P = (text, opts = {}) => new Paragraph({ spacing: { after: 120, line: 300 }, ...opts,
  children: (Array.isArray(text) ? text : [text]).map((t) => (typeof t === "string" ? new TextRun(t) : t)) });
const B = (t) => new TextRun({ text: t, bold: true });
const I = (t) => new TextRun({ text: t, italics: true });
const H1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const H2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
const bullet = (t) => new Paragraph({ numbering: { reference: "bullets", level: 0 }, spacing: { after: 60, line: 280 },
  children: (Array.isArray(t) ? t : [t]).map((x) => (typeof x === "string" ? new TextRun(x) : x)) });
let LIST = 0;
const newList = () => { LIST += 1; return null; };
const num = (t) => new Paragraph({ numbering: { reference: "numbers", level: 0, instance: LIST }, spacing: { after: 60, line: 280 },
  children: (Array.isArray(t) ? t : [t]).map((x) => (typeof x === "string" ? new TextRun(x) : x)) });

function evidenceTag(kind) {
  const real = kind === "REAL";
  return new Paragraph({ spacing: { after: 80 }, children: [new TextRun({
    text: real ? "  EVIDENCE: REAL (measured on real ESC-50 audio)  " : "  EVIDENCE: SIMULATED (synthetic vibration channel)  ",
    bold: true, size: 17, color: real ? "0B5E3B" : "7A4A00",
    shading: { type: ShadingType.CLEAR, fill: real ? "D3F1E5" : "FBE6C6", color: "auto" } })] });
}

function figure(file, caption, widthPx = 600) {
  const p = path.join(FIG, file);
  if (!fs.existsSync(p)) return [P(I(`[figure ${file} not generated]`))];
  const buf = fs.readFileSync(p);
  const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20); // PNG IHDR
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 60 },
      children: [new ImageRun({ type: "png", data: buf, transformation: { width: widthPx, height: Math.round(widthPx * h / w) },
        altText: { title: caption, description: caption, name: file } })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 },
      children: [new TextRun({ text: caption, italics: true, size: 18, color: "52514E" })] }),
  ];
}

const border = { style: BorderStyle.SINGLE, size: 4, color: "C9C8C3" };
const borders = { top: border, bottom: border, left: border, right: border };
function table(head, rows, widths) {
  const total = widths.reduce((a, b) => a + b, 0);
  const cell = (t, i, hdr) => new TableCell({
    borders, width: { size: widths[i], type: WidthType.DXA },
    shading: hdr ? { fill: "26332C", type: ShadingType.CLEAR, color: "auto" } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: [new Paragraph({ alignment: i === 0 ? AlignmentType.LEFT : AlignmentType.RIGHT,
      children: [new TextRun({ text: String(t), bold: hdr, size: 18, color: hdr ? "FFFFFF" : "0B0B0B" })] })] });
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    rows: [new TableRow({ tableHeader: true, children: head.map((h, i) => cell(h, i, true)) }),
      ...rows.map((r) => new TableRow({ children: r.map((c, i) => cell(c, i, false)) }))] });
}
const spacer = () => new Paragraph({ spacing: { after: 160 }, children: [] });

// ------------------------------------------------------------ numbers
const A = S.audio, AD = S.audio_ablation_denoise, WL = S.window_level, EP = S.episodes;
const em = Object.fromEntries(EP.summary.map((r) => [r.method, r]));
const cons = em.agent_conservative, SEL = S.agent_selection_dev;
const selRow = Object.fromEntries(SEL.candidates.map((r) => [r.method, r]));
const full = em.agent_full, v1 = em.agent_v1, nov = em.agent_no_vibration_k2, aud = em.audio_any_window,
  per = em.audio_persistence, alw = em.agent_always_vibration, noctx = em.agent_no_context;
const faRatio = (nov.false_alerts_per_benign_hour / Math.max(full.false_alerts_per_benign_hour, 0.01)).toFixed(1);
const ctxDelta = Math.abs(full.recall - noctx.recall) + Math.abs(full.fpr - noctx.fpr);
const ctxNull = ctxDelta < 0.01;
const kinds = EP.detection_rate_by_kind;
const NICE = { audio_any_window: "Audio, any window", fused_any_window: "Fusion, any window",
  audio_persistence: "Audio + persistence", agent_full: "Agent, sensitive mode (selected)", agent_v1: "Agent v1 (first design)", agent_conservative: "Agent, conservative mode",
  agent_always_vibration: "Agent, vibration always on", agent_no_vibration: "Agent, no vibration (k=3)",
  agent_no_vibration_k2: "Agent, no vibration (k=2)", agent_no_context: "Agent, no context rule",
  audio_only: "Audio only", vibration_only: "Vibration only", AND_rule: "AND rule", OR_rule: "OR rule",
  learned_late_fusion: "Learned late fusion (LR)", bayesian_evidence_fusion: "Bayesian evidence fusion (ours)" };
const LAT = S.latency_ms_per_window;
const SW = { n: 8 * 5 * 6 };
const sw = (field, v, m, k) => { const r = S.sweeps[field].find((x) => x[field] === v && x.method === m); return r ? r[k] : NaN; };
const latTotal = (LAT.audio_preprocess + LAT.audio_features + LAT.audio_head + LAT.vibration_analysis_and_classifier + LAT.fusion_and_agent);

// ------------------------------------------------------------ content
const body = [];
// title page
body.push(
  new Paragraph({ spacing: { before: 2400, after: 200 }, children: [new TextRun({ text: "FORESTGUARD AI", bold: true, size: 64, color: "1F3A2E" })] }),
  new Paragraph({ spacing: { after: 400 }, children: [new TextRun({ text: "Evidence-aware acoustic–vibration sensing with a stateful, explainable agent for detecting unauthorised human activity in forests", size: 30, color: "26332C" })] }),
  P([B("Technical report  ·  "), new TextRun("Ingénieux IEEE Hackathon, Track 2: Forests & Wildlife Intelligent Sensing  ·  Mahindra University  ·  4 November 2026")]),
  P([B("Team: "), new TextRun("Anvitha Reddy (team members to be added)")]),
  spacer(),
  new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text: "Evidence levels used throughout", bold: true, size: 22 })] }),
  P([B("REAL — "), new TextRun("measured on real ESC-50 recordings with the dataset's official 5-fold cross-validation.")]),
  P([B("SIMULATED — "), new TextRun("involves the synthetic ground-vibration channel and monitoring episodes assembled from held-out real audio clips. These results measure the method under the simulator's stated assumptions; they are not field performance and no real multimodal validation is claimed.")]),
  new Paragraph({ children: [new PageBreak()] }),
  new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: "Contents", bold: true, size: 30, color: "1F3A2E" })] }),
  ...["1. Abstract", "2. Problem and motivation", "3. Research gap", "4. Proposed architecture", "5. Methodology",
    "6. Datasets", "7. Implementation", "8. Experimental design", "9. Results", "10. Novelty and contributions",
    "11. Limitations and unsuccessful experiments", "12. Path to government deployment",
    "13. Scalability and next research questions", "References", "Appendix A. Reproducibility"]
    .map((t) => new Paragraph({ spacing: { after: 90 }, children: [new TextRun({ text: t, size: 22 })] })),
  new Paragraph({ children: [new PageBreak()] }),
);

// 1 abstract
body.push(H1("1. Abstract"),
  P(`Acoustic monitors for illegal logging and poaching fail in practice less from missed chainsaws than from false alarms: wind, rain, thunder and livestock produce loud, threat-like sounds, and rangers stop trusting a system that cries wolf. FORESTGUARD asks whether an agent that demands independent ground-vibration corroboration and temporal persistence can suppress those false alarms without losing intrusions, and how it behaves when the vibration sensor is weak or missing.`),
  P(`The audio front end (high-pass filtering, energy segmentation, log-mel/MFCC features, onset cadence and fundamental-frequency estimation) feeds a 22-class classifier evaluated on real ESC-50 clips: ${pct(A.accuracy_mean)} ± ${pct(A.accuracy_std)} accuracy and threat-versus-natural F1 ${f3(A.threat_vs_natural.f1)} (REAL). Because no paired acoustic–seismic forest dataset exists, a physics-based geophone simulator generates vibration whose timing and frequencies are taken from the real recordings, with propagation loss, natural vibration sources and sensor faults that prevent the two channels from being trivially redundant. A label-agnostic vibration analyser (FFT, RMS, dominant frequency, envelope peaks, cadence) feeds Bayesian log-odds fusion whose likelihood ratios are learned only from training folds, and a stateful agent decides when to wake the vibration sensor, when to wait for more evidence and when to escalate to a ranger, logging every decision in a hash-chained audit trail.`),
  P(`On ${EP.n_episodes} simulated 60-second monitoring episodes built from held-out clips, stateless audio alerting raised ${aud.false_alerts_per_benign_hour} false alerts per benign hour at ${pct(aud.recall)} recall. The selected agent (sensitive mode) raised ${full.false_alerts_per_benign_hour} at ${pct(full.recall)} recall; an otherwise identical agent without vibration raised ${nov.false_alerts_per_benign_hour} at ${pct(nov.recall)}, so vibration evidence cut false alerts ${faRatio}× (SIMULATED). A conservative mode raised ${cons.false_alerts_per_benign_hour} false alerts per hour at ${pct(cons.recall)} recall, giving operators a choice of operating point. On-demand sensing analysed vibration in ${pct(full.vibration_duty_cycle, 0)} of windows with results matching always-on sensing. We report limits honestly: brief single-window presence is rarely escalated, a weather-context rule ${ctxNull ? "had no measurable effect" : "changed results only slightly"}, and all multimodal results await real-sensor validation.`));

// 2 problem
body.push(H1("2. Problem and motivation"),
  P("India's forest departments patrol very large areas with limited staff. Illegal tree felling, poaching and vehicle intrusion are usually discovered after the fact. Passive acoustic monitoring offers continuous coverage at low cost: a chainsaw or engine is audible far beyond what a patrol can see. The operational failure mode is false alarms. A detector that treats every loud, mechanical-sounding event as a threat will fire on thunder, wind gusts, rain on leaves and grazing livestock, which are common in Indian forests and buffer zones. Each false alarm costs a patrol trip and erodes trust."),
  P([B("Problem formulation. "), new TextRun("Given synchronised 5-second windows from a microphone and a ground-vibration sensor at one node, decide in real time whether to keep monitoring, gather more evidence, or escalate an incident for human investigation, so that genuine human activity (logging, vehicles, people on foot, gunshot-like blasts) is escalated quickly while natural disturbances are not. Every decision must be explainable and auditable, and the system must degrade gracefully when one sensor is missing or noisy.")]),
  P([B("Research question. "), new TextRun("Can a stateful agent that requires independent vibration corroboration and temporal persistence reduce false alerts from natural disturbances without unacceptable loss of intrusion recall, and how does that trade-off depend on vibration-sensor quality and availability?")]));

// 3 research gap
body.push(H1("3. Research gap"),
  bullet([B("Single-modality acoustic systems "), new TextRun("(e.g. smartphone-based Guardian devices deployed by Rainforest Connection) detect chainsaws and gunshots from sound alone and rely on humans to filter false positives.")]),
  bullet([B("Seismic footstep detection "), new TextRun("with geophones is a mature defence and security topic, but it is rarely combined with acoustic classification for conservation, and even more rarely with an explicit decision policy.")]),
  bullet([B("Most audio classification work stops at per-clip accuracy. "), new TextRun("Benchmarks such as ESC-50 and FSC22 measure whether a clip is labelled correctly, not whether an operational alert policy produces tolerable false-alarm rates over time.")]),
  bullet([B("Fusion is usually a fixed AND/OR rule or a learned score. "), new TextRun("Neither encodes that the absence of vibration means different things for different sources: it is strong evidence against a nearby vehicle and almost none against a distant chainsaw or a voice.")]),
  P("FORESTGUARD targets the gap between clip classification and an evidence-aware, stateful alert policy, and measures it at the level that matters to a ranger: false alerts per hour and time to detect."));

// 4 architecture
body.push(H1("4. Proposed architecture"),
  ...figure("architecture.png", "Figure 1. System architecture. Blue: real audio path; orange: simulated vibration path; green: decision layer.", 620),
  P("Each node processes 5-second windows. The audio path runs continuously; the vibration analysis path is woken by the agent. Fusion combines the two into per-threat-type posteriors, and the agent turns the stream of fused evidence into actions."),
  ...figure("agent_workflow.png", "Figure 2. The agent's seven-step decision loop, escalation rules and state machine.", 620));

// 5 methodology
body.push(H1("5. Methodology"),
  H2("5.1 Acoustic signal processing (REAL data)"),
  bullet("Resample to 16 kHz mono; 4th-order zero-phase Butterworth high-pass at 80 Hz to remove wind and handling rumble."),
  bullet("Optional stationary-noise spectral gate (per-bin noise floor from the quietest 15% of frames); evaluated as an ablation."),
  bullet("Energy segmentation: a frame is active when its RMS exceeds the clip's own noise floor (10th-percentile dB) by 10 dB. Segments give event timestamps; continuous sources such as engines are reported as one continuous event."),
  bullet("Features (226-d): log-mel mean/std (64 bands), MFCC and delta statistics, spectral centroid/bandwidth/roll-off/flatness/contrast, zero-crossing rate, onset-envelope cadence (0.5–4 Hz autocorrelation) and a harmonic-product-spectrum low fundamental (20–250 Hz)."),
  bullet("Classifier: standardisation + multinomial logistic regression over 22 forest-relevant ESC-50 classes. A YAMNet (AudioSet-pretrained) embedding backend is implemented for Colab; its weights were not reachable from the build environment, so all REAL numbers in this report use the handcrafted backend."),
  bullet("Threat score P(threat) = sum of the probabilities of the eight human-activity classes, grouped into logging (chainsaw, hand saw), vehicle (engine, helicopter), human movement (footsteps), human voice (laughing, coughing) and firearm proxy (fireworks — ESC-50 has no gunshot class)."),
  H2("5.2 Synthetic vibration generation (SIMULATED)"),
  P("received(f) = source(f) · √(r₀/r) · exp(−πfr/(Qv)) · H_geophone(f) + noise, with Q = 20, v = 200 m/s, a 4.5 Hz second-order geophone corner, 500 Hz sampling and source distance r drawn uniformly from 3–60 m. Order-of-magnitude soil values are assumed; they are not calibrated to a site."),
  bullet("Footsteps: damped 15–35 Hz impulses at the onset times measured on the real audio clip when at least three onsets are found, otherwise a 1.6–2.2 Hz gait."),
  bullet("Engines and chainsaws: harmonic series at the fundamental measured on the real clip when it is tonal and in range; slow RPM drift and amplitude modulation; chainsaw felling adds a large impact in 30% of windows."),
  bullet("Natural sources also shake the ground: thunder (2–30 Hz bursts), wind-rocked roots (1–8 Hz), rain impacts, livestock and dog gait whose cadence overlaps the human range."),
  bullet("Confounds independent of the audio label: an unrelated animal walking past (15%), 50 Hz mains-hum artefacts (5%), sensor dropout (5%)."),
  bullet("Every window is reproducible from (seed, clip, scenario key), carries simulated = True, and every exported CSV begins with a '# SIMULATED' header."),
  H2("5.3 Vibration analysis"),
  P("The analyser sees only the waveform: RMS and peak-based SNR against the sensor baseline, Welch PSD, dominant frequency, tonality and harmonic check, Hilbert envelope, envelope peak detection with inter-peak regularity, gait cadence from envelope autocorrelation, kurtosis, crest factor, duty cycle, burst concentration and four band-energy ratios. Hand-written pattern rules were tried first and rejected: resonant footstep impulses looked tonal and thunder bursts produced gait-like peaks. A 100-tree random forest over the named features now predicts the source family (none, human gait, animal gait, machinery, transient, weather)."),
  H2("5.4 Evidence fusion"),
  P("logit P(g | audio, vibration) = logit P(g | audio) + log LR_v(g) + consistency, where LR_v(g) = P(observed vibration family | g) / P(observed family | not g). The likelihood table is estimated with an inner cross-validation on the training folds only. This one table encodes context-dependent expectations: a vehicle almost always couples into the ground, so 'no vibration' is strong evidence against it, while voices rarely couple, so absence is uninformative. A frequency-match term adds evidence when audio and vibration fundamentals agree within 12%. Missing vibration contributes nothing and is flagged; strong disagreement is flagged as a conflict."),
  H2("5.5 Stateful agent"),
  bullet("Context: a running weather estimate from audio; in storm context the evidence bar rises for engine-like and blast-like types."),
  bullet("Energy: vibration analysis runs only when audio P(threat) ≥ 0.30 or an investigation is open."),
  bullet("Sensor health: three dropouts in five requests flags maintenance; a noise floor above 1.8× calibration halves the vibration weight."),
  bullet("Memory: a decaying per-type belief and a 30-second event history. Footsteps and voices count as one human-presence incident."),
  bullet("Escalation: immediately when P(type) ≥ 0.97 with vibration log-LR ≥ 1; on a single blast-like event with P ≥ 0.90; or when the same incident type is suspicious in k windows within 30 s, where k = 2 if corroborated and 3 if not. In sensitive mode the extra window is demanded only when the training-fold table says the source normally couples into the ground; conservative mode demands it for every type."),
  bullet("One alert per incident, de-escalation after four quiet windows, and a SHA-256 hash-chained audit record with reasons and evidence terms for every window."));

// 6 datasets
body.push(H1("6. Datasets"),
  table(["Dataset", "Content", "Use here", "Licence / attribution"], [
    ["ESC-50 (Piczak 2015)", "2,000 × 5 s clips, 50 classes, 5 official folds", "22 forest-relevant classes, 880 clips; all REAL results", "CC BY-NC 3.0; clips from freesound.org"],
    ["FSC22 (Bandara et al. 2023)", "2,025 forest sound clips, 27 classes", "Cross-dataset test script provided; not run in this report", "See dataset page; cite Sensors 23(4):2032"],
    ["Synthetic vibration", "Physics-based geophone windows", "All SIMULATED results", "Generated by this project"],
  ], [1900, 2400, 2626, 2100]),
  spacer(),
  P(`Inspection confirmed ESC-50's metadata columns (filename, fold, target, category, esc10, src_file, take), 40 clips per class and 5-second 44.1 kHz mono PCM files. Using the official folds keeps all takes of one source recording in the same fold, avoiding leakage.`));

// 7 implementation
body.push(H1("7. Implementation"),
  table(["Module", "File", "Responsibility"], [
    ["Configuration & taxonomy", "forestguard/config.py", "paths, seeds, class → threat-group mapping"],
    ["Data", "forestguard/data.py", "ESC-50 loader and validation, FSC22 inspector and loader"],
    ["Acoustic DSP", "forestguard/audio_dsp.py", "filters, segmentation, spectrograms, features, cadence, f0"],
    ["Audio models", "forestguard/audio_models.py", "handcrafted and YAMNet backends, fold-wise CV, timing"],
    ["Vibration simulator", "forestguard/vibration_sim.py", "physics generator, CSV export (SIMULATED)"],
    ["Vibration DSP", "forestguard/vibration_dsp.py", "FFT, RMS, peaks, periodicity, source-family model"],
    ["Fusion", "forestguard/fusion.py", "Bayesian fusion, likelihood table, baselines"],
    ["Agent", "forestguard/agent.py", "state machine, rules, sensor health, audit log"],
    ["Pipeline & experiments", "forestguard/pipeline.py, experiments.py", "leakage-safe data flow, episodes, metrics, sweeps"],
    ["Dashboard", "app/dashboard.py", "Streamlit command centre"],
    ["Tests", "tests/test_decision_logic.py", "22 unit tests for fusion, agent rules, DSP, simulator"],
  ], [2300, 3100, 3626]),
  spacer(),
  P(`Stack: Python 3, NumPy, SciPy, pandas, librosa, scikit-learn, Plotly, Streamlit, Matplotlib (TensorFlow Hub for YAMNet). A single command (python scripts/run_all.py) regenerates every result, figure, CSV and the dashboard bundle from the fixed seeds (model seed ${S.run.seed}; episode seed 2026).`));

// 8 experiments
newList();
body.push(H1("8. Experimental design"),
  num([B("Audio classification (REAL). "), new TextRun("22-class accuracy and macro F1 over the official folds; binary threat-versus-natural precision, recall, F1, FPR and AUC; denoising ablation; per-stage latency.")]),
  num([B("Window-level fusion (SIMULATED). "), new TextRun("880 held-out windows, one per clip, comparing audio-only, vibration-only, AND, OR, learned late fusion (logistic regression on both scores, fold-wise) and our Bayesian evidence fusion.")]),
  num([B("Episode-level alerting (SIMULATED). "), new TextRun(`${EP.n_episodes} 60-second episodes (12 windows), 20 per scenario per fold, drawn only from fold-f clips with fold-f models. Benign: calm, storm, livestock. Intrusions overlaid on random benign backgrounds: logging (4–8 windows), vehicle pass (2–3), foot patrol (3–6 footsteps/voices), poaching (footsteps then a blast), brief presence (one window). Metrics: episode precision/recall/F1, benign-episode FPR, false alerts per benign hour, median time to detect, vibration duty cycle.`)]),
  num([B("Ablations. "), new TextRun("Stateless audio and fusion alerting; audio with persistence only; the agent without vibration (k = 3, and a fairer k = 2); vibration always on; no context rule; and the first agent design (v1).")]),
  num([B("Sensitivity sweeps (SIMULATED). "), new TextRun("Vibration coupling strength (0.25–2× default) and dropout probability (0–0.8), retraining vibration models at each point.")]),
  P([B("Development protocol. "), new TextRun(`Agent v1 was evaluated on a development episode draw (seed 42). Its failure analysis motivated two candidate changes (Section 10). All four combinations were compared on the development draw with a selection rule fixed in advance: highest episode F1 among configurations with at most 5 false alerts per benign hour. The rule chose ${SEL.chosen} (development F1 ${f3(selRow[SEL.chosen].f1)}, ${selRow[SEL.chosen].false_alerts_per_benign_hour} false alerts per hour). Every episode result in Section 9 comes from a separate test draw (seed 2026), with all candidates reported.`)]));

// 9 results
body.push(H1("9. Results"),
  H2("9.1 Audio classification"), evidenceTag("REAL"),
  table(["Metric", "Raw (80 Hz high-pass)", "+ spectral gate"], [
    ["22-class accuracy (mean ± sd over folds)", `${pct(A.accuracy_mean)} ± ${pct(A.accuracy_std)}`, `${pct(AD.accuracy_mean)} ± ${pct(AD.accuracy_std)}`],
    ["Macro F1", f3(A.macro_f1), f3(AD.macro_f1)],
    ["Threat vs natural: precision", f3(A.threat_vs_natural.precision), f3(AD.threat_vs_natural.precision)],
    ["Threat vs natural: recall", f3(A.threat_vs_natural.recall), f3(AD.threat_vs_natural.recall)],
    ["Threat vs natural: F1", f3(A.threat_vs_natural.f1), f3(AD.threat_vs_natural.f1)],
    ["Threat vs natural: false-positive rate", f3(A.threat_vs_natural.fpr), f3(AD.threat_vs_natural.fpr)],
    ["Threat vs natural: ROC AUC", f3(A.threat_vs_natural.auc), f3(AD.threat_vs_natural.auc)],
  ], [4426, 2300, 2300]),
  spacer(),
  P(`Per-fold accuracy: ${A.accuracy_per_fold.map((x) => pct(x)).join(", ")}. The spread is large, so small differences between configurations should not be over-read. The spectral gate did not help (${pct(AD.accuracy_mean)} vs ${pct(A.accuracy_mean)}); it suppresses informative stationary texture such as insects and engines, so it is off by default. The natural classes most often mistaken for threats were ${Object.entries(A.false_alarm_sources).slice(0, 4).map(([k, v]) => `${k} (${v})`).join(", ")} — the false-alarm sources the agent must handle.`),
  ...figure(`audio_confusion_${A.backend}.png`, "Figure 3. Row-normalised confusion matrix of the 22-class audio classifier (REAL, out-of-fold).", 470),
  H2("9.2 Window-level fusion"), evidenceTag("SIMULATED"),
  table(["Method", "Precision", "Recall", "F1", "FPR", "AUC"],
    Object.entries(WL.methods).map(([k, m]) => [NICE[k] || k, f3(m.precision), f3(m.recall), f3(m.f1), f3(m.fpr), m.auc ? f3(m.auc) : "–"]),
    [3226, 1160, 1160, 1160, 1160, 1160]),
  spacer(),
  P(`Fusion improves single-window F1 over audio alone (${f3(WL.methods.audio_only.f1)} → ${f3(WL.methods.bayesian_evidence_fusion.f1)}) and lowers the false-positive rate (${f3(WL.methods.audio_only.fpr)} → ${f3(WL.methods.bayesian_evidence_fusion.fpr)}). The learned late-fusion baseline ${WL.methods.learned_late_fusion.f1 >= WL.methods.bayesian_evidence_fusion.f1 ? "is marginally better" : "is marginally worse"} at this level (F1 ${f3(WL.methods.learned_late_fusion.f1)}). We keep the Bayesian form because its per-type likelihood ratios are interpretable and are what the agent's explanations and coupling-aware rules are built on. The vibration source-family classifier is correct on ${pct(WL.vibration_family_accuracy)} of available windows.`),
  ...figure("window_methods.png", "Figure 4. Window-level F1 and false-positive rate (SIMULATED vibration, real audio).", 560),
  H2("9.3 Episode-level alerting"), evidenceTag("SIMULATED"),
  table(["Method", "Precision", "Recall", "Benign FPR", "False alerts / benign h", "Median TTD (s)", "Vibration duty"],
    EP.summary.map((r) => [NICE[r.method] || r.method, f3(r.precision), f3(r.recall), f3(r.fpr), r.false_alerts_per_benign_hour,
      r.median_time_to_detect_s === null || isNaN(r.median_time_to_detect_s) ? "–" : r.median_time_to_detect_s, pct(r.vibration_duty_cycle, 0)]),
    [2426, 1150, 950, 1100, 1300, 1100, 1000]),
  spacer(),
  bullet(`Stateless audio alerting fires on ${pct(aud.fpr, 0)} of benign one-minute episodes (${aud.false_alerts_per_benign_hour} false alerts per benign hour). Persistence alone reduces this to ${per.false_alerts_per_benign_hour}/h.`),
  bullet(`The full agent reaches ${full.false_alerts_per_benign_hour} false alerts per benign hour with precision ${f3(full.precision)} and recall ${f3(full.recall)}. Removing only the vibration channel (k = 2 ablation) gives ${nov.false_alerts_per_benign_hour}/h at recall ${f3(nov.recall)}: the vibration evidence accounts for a ${faRatio}× reduction in false alerts.`),
  bullet(`On-demand vibration (${pct(full.vibration_duty_cycle, 0)} duty cycle) performs like always-on sensing (recall ${f3(alw.recall)}, ${alw.false_alerts_per_benign_hour}/h), saving roughly ${pct(1 - full.vibration_duty_cycle, 0)} of vibration processing.`),
  bullet(`Development-to-test gap: the selected configuration had ${selRow[SEL.chosen].false_alerts_per_benign_hour} false alerts per hour on the development draw and ${full.false_alerts_per_benign_hour} on the test draw, above the 5/h budget it was selected under. The extra alerts come mainly from livestock episodes (${pct(kinds.agent_full.livestock, 0)} alerted), where animal calls misread as human voices need no ground corroboration.`),
  bullet(`Operating points: the conservative mode (footsteps and voices merged, corroboration demanded for every type) gives ${cons.false_alerts_per_benign_hour}/h at recall ${f3(cons.recall)}; agent v1 gives ${v1.false_alerts_per_benign_hour}/h at recall ${f3(v1.recall)}. Choosing between sensitive and conservative modes is a policy decision for the forest department, not a technical one.`),
  bullet(`Weather-context rule: ${ctxNull ? "no measurable effect (identical within 1 percentage point). The fusion's vibration term already handles most storm confusions, so the rule is redundant in this simulation." : `recall ${f3(noctx.recall)} and FPR ${f3(noctx.fpr)} without it, versus ${f3(full.recall)} and ${f3(full.fpr)} with it.`}`),
  ...figure("episode_tradeoff.png", "Figure 5. Recall against false alerts per benign hour for every alerting policy (SIMULATED).", 560),
  ...figure("detection_by_kind.png", "Figure 6. Share of episodes alerted, by scenario. Left of the line are benign scenarios where the ideal is 0.", 600),
  P(`By scenario, the full agent alerted on ${pct(kinds.agent_full.logging, 0)} of logging, ${pct(kinds.agent_full.vehicle_pass, 0)} of vehicle-pass, ${pct(kinds.agent_full.poaching, 0)} of poaching and ${pct(kinds.agent_full.foot_patrol, 0)} of foot-patrol episodes, but only ${pct(kinds.agent_full.brief_presence, 0)} of single-window brief-presence episodes. That is the explicit price of requiring persistence or corroboration.`),
  H2("9.4 Sensitivity to the vibration sensor"), evidenceTag("SIMULATED"),
  ...figure("sweep_snr_scale.png", "Figure 7. Episode recall and benign FPR as vibration coupling strength varies.", 600),
  ...figure("sweep_dropout.png", "Figure 8. Episode recall and benign FPR as vibration dropout increases.", 600),
  P(`Coupling strength (${SW.n} episodes per point): even at a quarter of the default coupling the agent stays at ${sw("snr_scale", 0.25, "agent_full", "false_alerts_per_benign_hour")} false alerts per benign hour, against ${sw("snr_scale", 0.25, "agent_no_vibration_k2", "false_alerts_per_benign_hour")} for the same agent without vibration. Recall rises from ${f3(sw("snr_scale", 0.25, "agent_full", "recall"))} to ${f3(sw("snr_scale", 2.0, "agent_full", "recall"))} as coupling strengthens. The false-alarm benefit is therefore not fragile to how strongly sources couple into the ground in this simulation.`),
  P([B("Dropout exposes a real weakness. "), new TextRun(`Recall falls from ${f3(sw("dropout_p", 0.0, "agent_full", "recall"))} with no dropout to ${f3(sw("dropout_p", 0.8, "agent_full", "recall"))} at 80% dropout, below the ${f3(sw("dropout_p", 0.8, "agent_no_vibration_k2", "recall"))} of an agent that never uses vibration. The agent keeps demanding corroboration from a sensor that is mostly absent. It does flag the sensor for maintenance, but the flag does not change its policy. The obvious fix, switching to the no-vibration policy once the sensor is flagged unreliable, is not implemented or evaluated here.`)]),
  H2("9.5 Compute and latency"),
  table(["Stage (per 5 s window)", "Time (ms)"], [
    ["Audio pre-processing", LAT.audio_preprocess], ["Audio features", LAT.audio_features], ["Audio classifier head", LAT.audio_head],
    ["Vibration analysis + source-family model", LAT.vibration_analysis_and_classifier], ["Fusion + agent decision", LAT.fusion_and_agent],
    ["Total", latTotal.toFixed(1)]], [6026, 3000]),
  spacer(),
  P(`Measured on ${LAT.note}. The whole chain uses about ${pct(latTotal / 5000, 1)} of real time, leaving large headroom for an embedded processor. YAMNet would add a MobileNet forward pass (about 3.7 M parameters) and has not been timed here.`),
  ...figure("example_signals.png", "Figure 9. Real log-mel spectrograms with detected segments (left), simulated geophone windows (centre) and their FFTs (right).", 620));

// 10 novelty
newList();
body.push(H1("10. Novelty and contributions"),
  num([B("Coupling-aware evidence fusion. "), new TextRun("Likelihood ratios learned per threat type encode that missing vibration is evidence against some sources and not others, instead of a fixed AND/OR.")]),
  num([B("An agent evaluated as an alert policy. "), new TextRun("Results are reported as false alerts per hour and time to detect over monitoring episodes, not only clip accuracy.")]),
  num([B("Energy-aware active sensing. "), new TextRun("The agent wakes the vibration channel only when needed and matches always-on performance.")]),
  num([B("A non-circular, physics-parameterised vibration simulator "), new TextRun("driven by measurements from the real recordings, with natural vibration sources and sensor faults, released with CSV export.")]),
  num([B("Auditability. "), new TextRun("Every decision carries its evidence terms and reasons in a tamper-evident chain suitable for later review.")]),
  P([B("Iteration disclosed. "), new TextRun("v1 counted footsteps and voices as separate threat types and demanded corroboration for every type, giving low foot-patrol recall on the development draw. Two changes were proposed: merge them into one human-presence incident, and demand corroboration only where ground coupling is expected. Selection on the development draw and evaluation on a separate test draw showed the first change is close to free, while the second trades false alerts for recall. Both resulting modes are reported.")]));

// 11 limitations
body.push(H1("11. Limitations and unsuccessful experiments"),
  bullet([B("No real vibration data. "), new TextRun("All multimodal results depend on the simulator; propagation constants are order-of-magnitude values. Fusion gains could shrink or grow with real geophones.")]),
  bullet([B("Shared parameters between modalities. "), new TextRun("Footstep timing and engine fundamentals are taken from the audio, so the frequency-match benefit is partly built into the simulation.")]),
  bullet([B("Episodes are composed from isolated 5 s clips. "), new TextRun("Real streams have overlapping sources, varying distance over time and long quiet periods; false alerts per hour depend on how often benign sounds occur.")]),
  bullet([B("Proxy classes. "), new TextRun("Fireworks stands in for gunshots; laughing and coughing stand in for human voices in the field.")]),
  bullet([B("Dataset scale. "), new TextRun("880 clips; fold-to-fold accuracy varies widely.")]),
  bullet([B("YAMNet and FSC22 were not run in this environment. "), new TextRun("Both are implemented and scripted for Colab.")]),
  bullet([B("Brief presence is rarely escalated, "), new TextRun("a deliberate trade-off that may be unacceptable for some uses.")]),
  bullet([B("No graceful fallback under heavy dropout. "), new TextRun("At 50% dropout and above, the agent misses more intrusions than an agent without vibration (Section 9.4).")]),
  P([B("Unsuccessful attempts: "), new TextRun(`hand-written vibration pattern rules (replaced by a learned classifier); spectral-gate denoising (lower accuracy); the weather-context rule (${ctxNull ? "no measurable benefit" : "small effect"}).`)]));

// 12 deployment
body.push(H1("12. Path to government deployment"),
  ...figure("deployment.png", "Figure 10. Proposed field architecture (future work; not validated).", 600),
  P("The prototype is a software system validated on real audio and simulated vibration. A forest-department deployment would need the following, in order:"),
  ...(newList() || []),
  num("A paired acoustic–seismic data collection at a pilot site with ground truth from patrol logs or camera traps, to measure real coupling, false-alarm sources and detection ranges."),
  num("Site calibration of the likelihood tables and persistence thresholds, re-learned from ranger-verified alerts."),
  num("Hardware hardening (IP65 enclosure, lightning protection, geophone burial) and approvals from the forest department, including data-handling rules."),
  H2("12.1 Indicative node bill of materials"),
  P(I("Indicative retail estimates for planning only, not quotations; they need vendor confirmation.")),
  table(["Component", "Example", "Approx. cost (INR)"], [
    ["Microphone", "MEMS I²S microphone with windshield", "300–800"],
    ["Vibration sensor", "4.5–10 Hz geophone + 24-bit ADC", "4,000–8,000"],
    ["Edge compute", "ESP32-S3 (audio features) or Raspberry Pi Zero 2 W class", "600–2,000"],
    ["Radio", "LoRa module (event messages)", "800–1,500"],
    ["Power", "10 W solar panel, Li-ion pack, charge controller", "2,500–4,000"],
    ["Enclosure & mounting", "IP65 box, mast or tree mount", "1,500–2,500"],
    ["Total per node", "", "≈ 10,000–19,000"],
  ], [2600, 4226, 2200]),
  spacer(),
  H2("12.2 Operations, privacy and reliability"),
  bullet("Low bandwidth: nodes transmit compact event messages (type, time, confidence, reasons) rather than audio; optional short clips only on escalation."),
  bullet("Privacy: no continuous audio leaves the node, and voices are classified as presence, not recorded or transcribed. Retention rules should be agreed with the department."),
  bullet("Reliability: the agent flags its own sensor faults. In the current version it does not yet change policy when the vibration channel fails, which the dropout sweep shows costs recall; a policy switch on the maintenance flag is the first planned fix."),
  bullet("Maintenance: quarterly cleaning of panels and windshields, battery replacement every 2–3 years, remote health reporting."),
  bullet("Human verification: every alert is a request for a ranger to investigate, never an automated enforcement action."),
  H1("13. Scalability and next research questions"),
  bullet("Multi-node reasoning: corroboration across neighbouring nodes and coarse localisation from arrival-time differences."),
  bullet("Real-sensor validation of the central claim: does vibration corroboration still cut false alerts several-fold with real geophones and real forest soil?"),
  bullet("Learning the escalation policy from ranger feedback (for example contextual bandits) while keeping rule-level explanations."),
  bullet("Pretrained embeddings (YAMNet, BEATs) and domain adaptation across forests; FSC22 cross-dataset evaluation is the first step."),
  bullet("Energy measurement on real hardware to turn the duty-cycle saving into battery life."));

// references
newList();
body.push(H1("References"),
  num("K. J. Piczak, “ESC: Dataset for Environmental Sound Classification,” Proc. 23rd ACM International Conference on Multimedia, 2015. https://github.com/karolpiczak/ESC-50"),
  num("M. Bandara, R. Jayasundara, I. Ariyarathne, D. Meedeniya, C. Perera, “Forest Sound Classification Dataset: FSC22,” Sensors, 23(4):2032, 2023."),
  num("J. F. Gemmeke et al., “Audio Set: An ontology and human-labeled dataset for audio events,” Proc. IEEE ICASSP, 2017."),
  num("Google, “YAMNet” audio event classifier (MobileNet v1 trained on AudioSet), TensorFlow Hub: https://tfhub.dev/google/yamnet/1"),
  num("A. G. Howard et al., “MobileNets: Efficient convolutional neural networks for mobile vision applications,” arXiv:1704.04861, 2017."),
  num("K. M. Houston, D. P. McGaffigan, “Seismic footstep signal characterization,” Proc. SPIE 5071, 2003."),
  num("A. Pakhomov et al., “Testing of new seismic sensors for footstep detection and other security applications,” Proc. SPIE 5778, 2005."),
  num("Rainforest Connection, “Guardian: real-time threat detection,” https://rfcx.org/guardian"),
  num("B. McFee et al., “librosa: Audio and music signal analysis in Python,” Proc. 14th Python in Science Conference, 2015."),
  num("F. Pedregosa et al., “Scikit-learn: Machine learning in Python,” JMLR 12, 2011."),
  H1("Appendix A. Reproducibility"),
  bullet("git clone --depth 1 https://github.com/karolpiczak/ESC-50.git data/ESC-50"),
  bullet("pip install -r requirements.txt"),
  bullet("python -m pytest -q tests   (expect 22 passed)"),
  bullet("python scripts/run_all.py   (writes results/, results/figures/, cache/dashboard_bundle.pkl)"),
  bullet("streamlit run app/dashboard.py"),
  P(`This run: backend ${S.run.backend}, ${S.run.episodes_per_type_per_fold} episodes per scenario per fold, ${S.run.seconds} s wall time. Simulation parameters: ${Object.entries(S.sim_params).map(([k, v]) => `${k}=${v}`).join(", ")}.`));

// ------------------------------------------------------------ document
const doc = new Document({
  creator: "FORESTGUARD team", title: "FORESTGUARD AI Technical Report",
  styles: {
    default: { document: { run: { font: FONT, size: 21 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 30, bold: true, color: "1F3A2E" }, paragraph: { spacing: { before: 360, after: 140 }, keepNext: true, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 24, bold: true, color: "26332C" }, paragraph: { spacing: { before: 240, after: 100 }, keepNext: true, outlineLevel: 1 } },
    ],
  },
  numbering: { config: [
    { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] },
    { reference: "numbers", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 540, hanging: 340 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: "FORESTGUARD AI · Technical report", size: 16, color: "8A8983" })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: ["Page ", PageNumber.CURRENT], size: 16, color: "8A8983" })] })] }) },
    children: body,
  }],
});
const outDir = path.join(ROOT, "submission");
fs.mkdirSync(outDir, { recursive: true });
Packer.toBuffer(doc).then((buf) => {
  const out = path.join(outDir, "FORESTGUARD_Technical_Report.docx");
  fs.writeFileSync(out, buf);
  console.log("wrote", out);
});
