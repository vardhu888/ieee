# FORESTGUARD AI

**Evidence-aware acoustic + vibration sensing with a stateful, explainable agent for detecting
unauthorised human activity in forests.**  Ingénieux IEEE Hackathon, Track 2 (Forests & Wildlife Intelligent Sensing).

> **Evidence levels.** **REAL** = measured on real ESC-50 recordings (official 5-fold CV).
> **SIMULATED** = involves the synthetic ground-vibration channel and monitoring episodes assembled
> from held-out real clips. Simulated results measure the method under the simulator's assumptions;
> they are **not** field performance, and no real multimodal validation is claimed.

## Research question
Can an agent that demands independent vibration corroboration and temporal persistence suppress false
alerts from natural disturbances (thunder, wind, rain, livestock) without unacceptable loss of intrusion
recall, and how does that depend on vibration-sensor quality and availability?

## Headline results
| | Value | Evidence |
|---|---|---|
| 22-class audio accuracy (handcrafted features) | 68.8% ± 4.3% | REAL |
| Threat-vs-natural F1 / AUC (audio) | 0.784 / 0.923 | REAL |
| False alerts per benign hour: stateless audio → agent | 79.0 → 6.2 | SIMULATED |
| Agent episode recall (sensitive / conservative mode) | 78.8% / 74.8% | SIMULATED |
| False-alert reduction from vibration evidence (same agent, with vs without) | 1.9× | SIMULATED |
| Vibration analysis duty cycle (on-demand) | 55% | SIMULATED |
| End-to-end compute per 5 s window | 38.5 ms (0.8% of real time) | measured |

## Quick start
```bash
git clone --depth 1 https://github.com/karolpiczak/ESC-50.git data/ESC-50
pip install -r requirements.txt
python -m pytest -q tests          # expect: 22 passed
python scripts/run_all.py          # ~15-20 min; --quick for a 3-minute smoke run
streamlit run app/dashboard.py     # command-centre dashboard
```
Colab: open `notebooks/ForestGuard_Colab.ipynb` and run the cells in order. Each cell lists its expected
output and how to verify it. YAMNet: `python scripts/run_all.py --backend yamnet` (needs `tensorflow_hub`;
set `FG_RESULTS_DIR` to keep results separate). FSC22: `python scripts/cross_dataset_fsc22.py --inspect`.

## How it works
1. **Acoustic DSP (real audio):** 16 kHz, 80 Hz Butterworth high-pass, energy segmentation against the
   clip's own noise floor (event timestamps), log-mel/MFCC/spectral features, onset cadence, harmonic-product
   low fundamental → 22-class logistic head (out-of-fold).
2. **Vibration simulator (SIMULATED):** surface-wave spreading, anelastic absorption (Q=20, v=200 m/s),
   4.5 Hz geophone response, source distance 3–60 m. Footstep timing and engine/saw fundamentals are measured
   on the real clip. Natural sources (thunder, wind, rain, livestock) also shake the ground; unrelated animals,
   50 Hz hum and dropout are added independently of the label. CSVs carry a `# SIMULATED` header.
3. **Vibration DSP:** RMS/peak SNR, Welch FFT, dominant frequency, tonality, Hilbert envelope, peak detection,
   cadence autocorrelation, kurtosis, duty cycle, burst concentration → random-forest source family.
4. **Fusion:** Bayesian log-odds, `logit P(g|a,v) = logit P(g|a) + log LR_v(g) + frequency-match`, with
   likelihood ratios estimated by inner CV on training folds only. Missing and conflicting evidence are flagged.
5. **Agent:** weather context, on-demand vibration, sensor health, decaying belief, 30 s history, escalation
   when evidence is corroborated or persistent (bar raised where corroboration was expected but absent),
   one alert per incident, cooldown, SHA-256 hash-chained audit log with reasons for every window.

## Results
### Audio classification — REAL
| Metric | Raw | + spectral gate |
|---|---|---|
| 22-class accuracy | 68.8% ± 4.3% | 66.7% ± 8.0% |
| Macro F1 | 0.686 | 0.665 |
| Threat-vs-natural precision / recall / F1 | 0.797 / 0.772 / 0.784 | 0.780 / 0.762 / 0.771 |
| Threat-vs-natural FPR | 0.113 | 0.123 |

Per-fold accuracy: 67.6%, 70.5%, 67.6%, 75.6%, 62.5%.

### Window-level fusion — SIMULATED (880 held-out windows)
| Method | Precision | Recall | F1 | FPR | AUC |
|---|---|---|---|---|---|
| Audio only | 0.797 | 0.772 | 0.784 | 0.113 | 0.923 |
| Vibration only | 0.846 | 0.616 | 0.713 | 0.064 | 0.841 |
| AND rule | 0.968 | 0.472 | 0.634 | 0.009 | – |
| OR rule | 0.757 | 0.916 | 0.829 | 0.168 | – |
| Learned late fusion (LR) | 0.894 | 0.844 | 0.868 | 0.057 | 0.969 |
| **Bayesian evidence fusion (ours)** | 0.862 | 0.856 | 0.859 | 0.079 | 0.961 |

### Episode-level alerting — SIMULATED (800 × 60 s episodes, test draw seed 2026)
| Method | Precision | Recall | Benign FPR | False alerts / benign h | Median TTD (s) | Vibration duty |
|---|---|---|---|---|---|---|
| Audio, alert on any window | 0.685 | 0.972 | 0.743 | 79.0 | 0.0 | 0% |
| Fusion, alert on any window | 0.727 | 0.976 | 0.610 | 58.0 | 0.0 | 100% |
| Audio + persistence | 0.819 | 0.830 | 0.307 | 20.0 | 5.0 | 0% |
| **Agent, sensitive mode (selected)** | 0.931 | 0.788 | 0.097 | 6.2 | 5.0 | 55% |
| Agent v1 (first design) | 0.986 | 0.720 | 0.017 | 1.0 | 5.0 | 55% |
| Agent, conservative mode | 0.984 | 0.748 | 0.020 | 1.2 | 5.0 | 55% |
| Agent, vibration always on | 0.932 | 0.800 | 0.097 | 6.2 | 5.0 | 100% |
| Agent, no vibration (k=3) | 0.874 | 0.526 | 0.127 | 7.8 | 15.0 | 0% |
| Agent, no vibration (k=2) | 0.863 | 0.740 | 0.197 | 12.0 | 5.0 | 0% |
| Agent, no context rule | 0.931 | 0.788 | 0.097 | 6.2 | 5.0 | 55% |

Figures: `results/figures/`. Per-scenario detection rates: `results/episode_detection_rate_by_kind.csv`.

### Protocol and honest notes
* Agent v1 was developed on a separate episode draw (seed 42). Candidate fixes were compared there with a rule
  fixed in advance (max F1 with ≤ 5 false alerts per benign hour), which chose `v2_both`.
  All numbers above come from the separate test draw. On the test draw the selected mode gave
  6.2 false alerts per hour, against 4.4 on the development draw.
* Learned late fusion is slightly better than our fusion at single-window F1; the advantage of our design shows at the episode level and in explainability.
* The spectral-gate denoiser lowered accuracy and is off by default.
* The weather-context rule had no measurable effect.
* Brief single-window human presence is escalated in only 23% of episodes, a deliberate trade-off.
* Fireworks stands in for gunshots (ESC-50 has no gunshot class). YAMNet and FSC22 are implemented but were not run in the build environment.

## Project layout
```
forestguard/   config, data, audio_dsp, audio_models, vibration_sim, vibration_dsp, fusion, agent, pipeline, experiments
scripts/       run_all.py, select_agent.py, figures.py, diagrams.py, cross_dataset_fsc22.py, build_docs.py
app/           dashboard.py (Streamlit command centre)
tests/         test_decision_logic.py (22 tests)
notebooks/     ForestGuard_Colab.ipynb
results/       metrics JSON/CSV, figures, vibration_csv/ (SIMULATED), example_audit_log.jsonl
report/        build_report.js (Word report generator)
```

## Data and attribution
* **ESC-50**: K. J. Piczak, "ESC: Dataset for Environmental Sound Classification", ACM MM 2015.
  CC BY-NC 3.0; clips originate from freesound.org.
* **FSC22**: M. Bandara et al., "Forest Sound Classification Dataset: FSC22", *Sensors* 23(4):2032, 2023.
* **YAMNet**: Google, TensorFlow Hub `google/yamnet/1`, trained on AudioSet (Gemmeke et al., ICASSP 2017).
* Vibration data are generated by this project and are synthetic.
