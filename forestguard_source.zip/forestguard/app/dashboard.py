"""FORESTGUARD AI - forest monitoring command centre (Streamlit).

Run:  streamlit run app/dashboard.py
Needs: python scripts/run_all.py  (creates cache/dashboard_bundle.pkl and results/)
"""
from __future__ import annotations

import json
import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from forestguard import audio_dsp, config, pipeline  # noqa: E402
from forestguard import vibration_dsp as vd  # noqa: E402
from forestguard import vibration_sim as vs  # noqa: E402
from forestguard.agent import AgentConfig, ForestGuardAgent  # noqa: E402

st.set_page_config(page_title="FORESTGUARD AI", page_icon="🌲", layout="wide")

BG, PANEL, LINE, INK, INK2 = "#0f1512", "#16201b", "#26332c", "#e8efe9", "#9fb3a6"
C1, C2, C3 = "#3987e5", "#d95926", "#199e70"
STATUS = {"MONITORING": ("#0ca30c", "●"), "WATCH": ("#fab219", "▲"), "ESCALATED": ("#d03b3b", "■")}

st.markdown(f"""
<style>
.stApp {{ background:{BG}; color:{INK}; }}
header[data-testid="stHeader"] {{ background:{BG}; }}
section[data-testid="stSidebar"] {{ background:{PANEL}; border-right:1px solid {LINE}; }}
h1,h2,h3,h4,p,label,span,div {{ color:{INK}; }}
.fg-head {{ display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid {LINE};
           padding-bottom:10px; margin-bottom:14px; }}
.fg-title {{ font-size:26px; font-weight:800; letter-spacing:2px; }}
.fg-sub {{ color:{INK2}; font-size:13px; }}
.fg-tile {{ background:{PANEL}; border:1px solid {LINE}; border-radius:10px; padding:12px 14px; }}
.fg-tile .k {{ color:{INK2}; font-size:11px; text-transform:uppercase; letter-spacing:1px; }}
.fg-tile .v {{ font-size:24px; font-weight:700; margin-top:2px; }}
.fg-badge {{ display:inline-block; padding:2px 8px; border-radius:6px; font-size:11px; font-weight:700;
            border:1px solid {LINE}; margin-right:6px; }}
.real {{ background:#123a2a; color:#7fe0b0; }} .sim {{ background:#3a2a12; color:#f3c27a; }}
.fg-alert {{ background:#2a1515; border:1px solid #d03b3b; border-radius:10px; padding:10px 14px; margin-bottom:8px; }}
</style>""", unsafe_allow_html=True)


def badge(kind: str) -> str:
    return ('<span class="fg-badge real">REAL AUDIO</span>' if kind == "real"
            else '<span class="fg-badge sim">SIMULATED VIBRATION</span>')


def tile(col, k, v, color=INK):
    col.markdown(f'<div class="fg-tile"><div class="k">{k}</div><div class="v" style="color:{color}">{v}</div></div>',
                 unsafe_allow_html=True)


def dark(fig, h=320):
    fig.update_layout(template="plotly_dark", paper_bgcolor=PANEL, plot_bgcolor=PANEL, height=h,
                      margin=dict(l=40, r=20, t=60, b=40), font=dict(color=INK),
                      title_font=dict(color=INK, size=14), legend=dict(orientation="h", y=1.08, x=0, font=dict(color=INK)))
    fig.update_xaxes(gridcolor=LINE); fig.update_yaxes(gridcolor=LINE)
    return fig


@st.cache_resource
def load_bundle():
    p = config.CACHE_DIR / "dashboard_bundle.pkl"
    if not p.exists():
        return None
    with open(p, "rb") as f:
        return pickle.load(f)


@st.cache_data
def load_summary():
    p = config.RESULTS_DIR / "results_summary.json"
    return json.loads(p.read_text()) if p.exists() else None


@st.cache_data
def load_audio(path):
    return audio_dsp.preprocess(audio_dsp.load_audio(path), denoise=False)


B = load_bundle()
S = load_summary()
st.markdown('<div class="fg-head"><div><div class="fg-title">🌲 FORESTGUARD AI</div>'
            '<div class="fg-sub">Acoustic + vibration intrusion monitoring · stateful explainable agent · node-01</div></div>'
            f'<div>{badge("real")}{badge("sim")}</div></div>', unsafe_allow_html=True)
if B is None:
    st.error("No model bundle found. Run `python scripts/run_all.py` first.")
    st.stop()

# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("Patrol simulation")
    kind = st.selectbox("Scenario", pipeline.THREAT_TYPES_EP + pipeline.BENIGN_TYPES, index=0)
    fold = st.selectbox("Held-out fold", [1, 2, 3, 4, 5], index=0,
                        help="Clips and models: audio is out-of-fold, vibration models trained on other folds")
    seed = st.number_input("Episode seed", 0, 9999, 7)
    st.subheader("Simulated sensor")
    snr = st.slider("Vibration coupling (x default)", 0.25, 2.0, 1.0, 0.25)
    drop = st.slider("Vibration dropout probability", 0.0, 0.9, 0.05, 0.05)
    st.subheader("Agent")
    policy = st.radio("Vibration analysis", ["on_demand", "always", "never"], horizontal=True)
    mode = st.radio("Operating mode", ["sensitive", "conservative"], horizontal=True,
                    help="Sensitive: no extra evidence demanded for sources that rarely shake the ground "
                         "(higher recall). Conservative: corroboration or extra persistence for every type.")
    use_ctx = st.checkbox("Weather-context rule", True)
    k = st.slider("Persistence windows (corroborated)", 1, 4, 2)
    st.caption("Vibration is synthetic (physics-based simulator). Audio clips are real ESC-50 recordings "
               "with held-out classifier outputs.")


@st.cache_data(show_spinner="Running patrol...")
def run_episode(kind, fold, seed, snr, drop, policy, use_ctx, k, mode):
    df, oof, hints = B["df"], B["oof"].set_index("filename"), B["hints"]
    models = B["models"][fold]
    params = vs.SimParams(snr_scale=snr, dropout_p=drop)
    eps = [e for e in pipeline.build_episodes(df, fold, 3, seed=int(seed)) if e["kind"] == kind]
    ep = eps[0]
    ag = ForestGuardAgent(models.lik, AgentConfig(vib_policy=policy, use_context=use_ctx, persistence_k=k,
                                                 expectation_aware_bar=(mode == "sensitive")))
    rows, signals = [], []
    for w, (fn, cat) in enumerate(zip(ep["files"], ep["categories"])):
        o, ex = pipeline.make_observation(w, 5.0 * w, fn, cat, oof.loc[fn], hints[fn], models, params,
                                          f"dash{seed}-{w}")
        d = ag.step(o)
        probs = sorted(o.audio_class_probs.items(), key=lambda kv: -kv[1])
        rows.append({"window": w, "t_start_s": 5.0 * w, "clip": fn, "scenario_truth": cat,
                     "audio_top": probs[0][0], "audio_conf": round(probs[0][1], 3),
                     "p_audio_threat": d.p_audio, "p_fused": d.p_fused, "threat_type": d.threat_type,
                     "vib_family": o.vib_family if d.vibration_used else ("missing" if not o.vib_available else "not requested"),
                     "state": d.state_after, "action": d.action,
                     "events": "; ".join(f"{5 * w + s:.2f}-{5 * w + e:.2f}s" for s, e in o.audio_segments[:4]) or "continuous",
                     "reasons": " | ".join(d.reasons)})
        signals.append({"path": df.set_index("filename").loc[fn, "path"], "vib": ex.get("signal"),
                        "meta": ex["vib_meta"], "top": probs[:5], "f0": o.audio_f0})
    return ep, pd.DataFrame(rows), signals, ag.alerts, ag.log.records, ag.summary()


ep, wdf, sigs, alerts, records, summ = run_episode(kind, fold, seed, snr, drop, policy, use_ctx, k, mode)

state = wdf["state"].iloc[-1]
c = st.columns(6)
color, icon = STATUS[state]
tile(c[0], "Node state", f"{icon} {state}", color)
tile(c[1], "Alerts raised", len(alerts), "#d03b3b" if alerts else INK)
tile(c[2], "Windows (5 s)", len(wdf))
tile(c[3], "Vibration duty cycle", f"{summ['vibration_duty_cycle']:.0%}")
tile(c[4], "Audit chain", "VERIFIED" if summ["log_intact"] else "BROKEN", "#0ca30c" if summ["log_intact"] else "#d03b3b")
tile(c[5], "Scenario truth", "INTRUSION" if ep["threat"] else "BENIGN", INK2)

tabs = st.tabs(["Live monitor", "Signals & sensor correlation", "Agent decisions & audit log",
                "Experiments", "System & deployment"])

# ---------------------------------------------------------------- live
with tabs[0]:
    left, right = st.columns([2.2, 1])
    fig = go.Figure()
    for i in ep["threat_windows"]:
        fig.add_vrect(x0=5 * i, x1=5 * i + 5, fillcolor="#d03b3b", opacity=0.12, line_width=0)
    x = wdf["t_start_s"] + 2.5
    fig.add_trace(go.Scatter(x=x, y=wdf["p_audio_threat"], name="Audio P(threat)", mode="lines+markers",
                             line=dict(color=C1, width=2), marker=dict(size=8)))
    fig.add_trace(go.Scatter(x=x, y=wdf["p_fused"], name="Fused P(threat)", mode="lines+markers",
                             line=dict(color=C2, width=2), marker=dict(size=8)))
    for a in alerts:
        fig.add_vline(x=a["t_start"] + 2.5, line=dict(color="#d03b3b", width=2, dash="dash"))
        fig.add_annotation(x=a["t_start"] + 2.5, y=1.05, text=f"ALERT: {a['threat_type']}", showarrow=False,
                           font=dict(color="#ff8080"))
    fig.add_hline(y=0.5, line=dict(color=INK2, width=1, dash="dot"))
    fig.update_yaxes(range=[0, 1.12], title="probability"); fig.update_xaxes(title="time (s)")
    fig.update_layout(title="Threat evidence over the 60 s patrol (red bands: true intrusion windows)")
    left.plotly_chart(dark(fig, 360), use_container_width=True)
    with right:
        st.markdown("#### Alerts")
        if not alerts:
            st.markdown(f'<div class="fg-tile">No escalation. {"Agent kept monitoring." if not ep["threat"] else "Intrusion not escalated (missed)."}</div>',
                        unsafe_allow_html=True)
        for a in alerts:
            st.markdown(f'<div class="fg-alert"><b>ALERT #{a["alert_id"]} · {a["threat_type"].upper()}</b><br>'
                        f't = {a["t_start"]:.0f} s · confidence {a["confidence"]:.2f} · '
                        f'{"vibration-corroborated" if a["corroborated"] else "audio + persistence only"}<br>'
                        f'<span style="color:{INK2};font-size:12px">{a["reasons"][-1]}</span></div>',
                        unsafe_allow_html=True)
    st.markdown("#### Detected events")
    st.dataframe(wdf[["window", "t_start_s", "events", "audio_top", "audio_conf", "p_audio_threat",
                      "vib_family", "p_fused", "state", "action", "scenario_truth"]],
                 use_container_width=True, hide_index=True)

# ---------------------------------------------------------------- signals
with tabs[1]:
    wsel = st.slider("Window", 0, len(wdf) - 1, int(ep["threat_windows"][0]) if ep["threat_windows"] else 0)
    s = sigs[wsel]
    y = load_audio(s["path"])
    st.markdown(f"{badge('real')} clip `{Path(s['path']).name}` · scenario label **{wdf.scenario_truth[wsel]}**",
                unsafe_allow_html=True)
    a1, a2 = st.columns([2, 1])
    lm = audio_dsp.log_mel(y)
    t = np.linspace(0, 5, lm.shape[1])
    fig = go.Figure(go.Heatmap(z=lm, x=t, colorscale="Viridis", colorbar=dict(title="dB")))
    for seg in audio_dsp.segment_activity(y):
        fig.add_vrect(x0=seg.start_s, x1=seg.end_s, line=dict(color="#ffffff", width=1), fillcolor="rgba(0,0,0,0)")
    fig.update_layout(title="Log-mel spectrogram with detected event segments")
    fig.update_xaxes(title="time (s)"); fig.update_yaxes(title="mel bin")
    a1.plotly_chart(dark(fig, 300), use_container_width=True)
    names = [n for n, _ in s["top"]][::-1]
    vals = [v for _, v in s["top"]][::-1]
    fig = go.Figure(go.Bar(x=vals, y=names, orientation="h", marker_color=C1, text=[f"{v:.2f}" for v in vals],
                           textposition="outside"))
    fig.update_layout(title="Audio classification (held-out model)"); fig.update_xaxes(range=[0, 1.15])
    a2.plotly_chart(dark(fig, 300), use_container_width=True)

    st.markdown(f"{badge('sim')} geophone channel · " +
                ", ".join(f"{k_}={v}" for k_, v in s["meta"].items() if k_ != "simulated"), unsafe_allow_html=True)
    if s["vib"] is None:
        st.warning("Vibration channel missing for this window (simulated dropout). The agent records this "
                   "and raises its evidence requirement.")
    else:
        v = s["vib"]
        tv = np.arange(len(v)) / config.VIB_SR
        f, X = vd.fft_spectrum(v)
        feat = vd.analyse(v)
        b1, b2 = st.columns(2)
        fig = go.Figure(go.Scatter(x=tv, y=v, line=dict(color=C3, width=1)))
        fig.update_layout(title="Vibration waveform (simulated)"); fig.update_xaxes(title="time (s)")
        b1.plotly_chart(dark(fig, 280), use_container_width=True)
        fig = go.Figure(go.Scatter(x=f, y=X, line=dict(color=C3, width=1.5)))
        fig.add_vline(x=feat.dom_freq, line=dict(color=C2, dash="dash"))
        if s["f0"]:
            fig.add_vline(x=s["f0"], line=dict(color=C1, dash="dot"))
        fig.update_layout(title=f"FFT · dominant {feat.dom_freq:.1f} Hz (orange) · audio f0 {s['f0']:.1f} Hz (blue)")
        fig.update_xaxes(title="frequency (Hz)", range=[0, 250])
        b2.plotly_chart(dark(fig, 280), use_container_width=True)
        # sensor correlation: audio RMS envelope vs vibration envelope at 100 Hz
        fs_e = 100
        a_env = np.sqrt(np.convolve(y ** 2, np.ones(160) / 160, "same"))[:: config.AUDIO_SR // fs_e][: 5 * fs_e]
        v_env = vd.envelope(v)[:: config.VIB_SR // fs_e][: 5 * fs_e]
        n = min(len(a_env), len(v_env))
        za = (a_env[:n] - a_env[:n].mean()) / (a_env[:n].std() + 1e-12)
        zv = (v_env[:n] - v_env[:n].mean()) / (v_env[:n].std() + 1e-12)
        lags = np.arange(-50, 51)
        xc = [np.mean(za[max(0, -L): n - max(0, L)] * zv[max(0, L): n - max(0, -L)]) for L in lags]
        c1, c2 = st.columns([2, 1])
        fig = make_subplots(specs=[[{"secondary_y": False}]])
        fig.add_trace(go.Scatter(x=np.arange(n) / fs_e, y=za, name="audio envelope (z)", line=dict(color=C1, width=1.5)))
        fig.add_trace(go.Scatter(x=np.arange(n) / fs_e, y=zv, name="vibration envelope (z)", line=dict(color=C3, width=1.5)))
        fig.update_layout(title="Cross-modal envelopes"); fig.update_xaxes(title="time (s)")
        c1.plotly_chart(dark(fig, 280), use_container_width=True)
        fig = go.Figure(go.Scatter(x=lags * 10, y=xc, line=dict(color=C2, width=2)))
        fig.update_layout(title=f"Cross-correlation · peak {max(xc):.2f} at {lags[int(np.argmax(xc))] * 10} ms")
        fig.update_xaxes(title="lag (ms)")
        c2.plotly_chart(dark(fig, 280), use_container_width=True)
        st.dataframe(pd.DataFrame([{k_: round(v_, 3) if isinstance(v_, float) else v_
                                    for k_, v_ in vars(feat).items()}]), use_container_width=True, hide_index=True)

# ---------------------------------------------------------------- decisions
with tabs[2]:
    st.markdown(f"Hash-chained log: each record stores SHA-256 of its content and the previous record. "
                f"Chain status: **{'VERIFIED' if summ['log_intact'] else 'BROKEN'}**")
    for r in records:
        col, ic = STATUS[r["state_after"]]
        with st.expander(f"{ic} t={r['t_start']:.0f}s · {r['action']} · {r['threat_type']} · "
                         f"P_fused={r['p_fused']:.2f} · {r['state_before']} → {r['state_after']}"):
            for reason in r["reasons"]:
                st.markdown(f"- {reason}")
            st.json({"evidence": r["evidence"], "flags": r["flags"], "belief": r["belief"],
                     "vibration_used": r["vibration_used"], "hash": r["hash"][:16] + "…",
                     "prev_hash": r["prev_hash"][:16] + "…"})
    st.download_button("Download audit log (JSONL)", "\n".join(json.dumps(r, default=str) for r in records),
                       file_name="forestguard_audit_log.jsonl")

# ---------------------------------------------------------------- experiments
with tabs[3]:
    if S is None:
        st.info("Run scripts/run_all.py to populate results.")
    else:
        au = S["audio"]
        st.markdown(f"### Audio classification {badge('real')}", unsafe_allow_html=True)
        cc = st.columns(4)
        tile(cc[0], f"{au['n_classes']}-class accuracy", f"{au['accuracy_mean']:.3f} ± {au['accuracy_std']:.3f}")
        tile(cc[1], "Macro F1", f"{au['macro_f1']:.3f}")
        tile(cc[2], "Threat-vs-natural F1", f"{au['threat_vs_natural']['f1']:.3f}")
        tile(cc[3], "Backend", au["backend"])
        st.markdown(f"### Window-level fusion {badge('sim')}", unsafe_allow_html=True)
        st.dataframe(pd.DataFrame(S["window_level"]["methods"]).T, use_container_width=True)
        st.markdown(f"### Episode-level alerting {badge('sim')}", unsafe_allow_html=True)
        st.dataframe(pd.DataFrame(S["episodes"]["summary"]), use_container_width=True, hide_index=True)
        st.markdown("### Latency (ms per 5 s window)")
        st.json(S.get("latency_ms_per_window", {}))
        figs = sorted((config.RESULTS_DIR / "figures").glob("*.png"))
        for i in range(0, len(figs), 2):
            cols = st.columns(2)
            for col, p in zip(cols, figs[i:i + 2]):
                col.image(str(p), caption=p.stem, use_container_width=True)

# ---------------------------------------------------------------- system
with tabs[4]:
    st.markdown("""
#### Pipeline
**Microphone** → high-pass 80 Hz → (optional spectral gate) → energy segmentation → log-mel / MFCC features
(or YAMNet embeddings) → 22-class head → P(class) per 5 s window
**Geophone** (simulated here) → RMS / Welch PSD / dominant frequency / Hilbert envelope / peak detection /
cadence autocorrelation → source-family classifier
**Fusion** → Bayesian log-odds with training-fold likelihood ratios + frequency-match consistency
**Agent** → context, duty-cycled vibration, sensor health, decaying belief, persistence & corroboration rules,
hash-chained audit log → *continue monitoring* / *watch* / *escalate to ranger*

#### What is real and what is simulated
* **Real:** every audio clip (ESC-50), every audio probability (out-of-fold), all acoustic DSP.
* **Simulated:** the vibration channel, and episodes assembled from real clips. Fusion and agent results
  measure the method *under the simulator's assumptions*, not field performance.

#### Path to deployment
Solar node (MEMS mic + 4.5 Hz geophone + Cortex-M/RPi-class MCU) runs audio continuously and wakes vibration
analysis on demand; sends compact event messages over LoRa; central command centre receives alerts with
reasons; rangers verify. Requires paired field recordings, threshold calibration per site, and forest-department
approvals before operational use.
""")
