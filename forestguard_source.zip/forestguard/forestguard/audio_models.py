"""Audio classification backends and fold-wise evaluation.

Backends
--------
* ``handcrafted`` : 226-dim log-mel/MFCC/spectral feature vector (audio_dsp).
                    Runs anywhere; used as the baseline.
* ``yamnet``      : YAMNet (Google, AudioSet-pretrained, TF Hub) frame
                    embeddings, mean+max pooled to 2048 dims. Needs
                    tensorflow + tensorflow_hub and internet on first load
                    (works in Google Colab).

Both feed the same lightweight head (standardise + multinomial logistic
regression) trained with ESC-50's official 5 folds, so every clip gets an
out-of-fold (OOF) probability vector that was produced by a model which
never saw that clip or any other take of the same source recording.
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from . import audio_dsp, config
from .logging_utils import get_logger

log = get_logger(__name__)

YAMNET_HANDLE = "https://tfhub.dev/google/yamnet/1"
_YAMNET = None


def _yamnet():
    global _YAMNET
    if _YAMNET is None:
        try:
            import tensorflow_hub as hub
        except ImportError as e:  # pragma: no cover - environment dependent
            raise RuntimeError("YAMNet backend needs: pip install tensorflow tensorflow_hub") from e
        log.info("Loading YAMNet from %s", YAMNET_HANDLE)
        _YAMNET = hub.load(YAMNET_HANDLE)
    return _YAMNET


def yamnet_embedding(y: np.ndarray) -> np.ndarray:
    model = _yamnet()
    _scores, emb, _spec = model(y.astype(np.float32))
    emb = emb.numpy()
    return np.concatenate([emb.mean(0), emb.max(0)]).astype(np.float32)


def yamnet_top_classes(y: np.ndarray, k: int = 3) -> list[tuple[str, float]]:
    """Zero-shot AudioSet labels from YAMNet, used for display in the dashboard."""
    import csv
    import tensorflow as tf
    model = _yamnet()
    scores, _e, _s = model(y.astype(np.float32))
    path = model.class_map_path().numpy().decode()
    with tf.io.gfile.GFile(path) as f:
        names = [r["display_name"] for r in csv.DictReader(f)]
    mean = scores.numpy().mean(0)
    top = np.argsort(mean)[::-1][:k]
    return [(names[i], float(mean[i])) for i in top]


def featurize(y: np.ndarray, backend: str) -> np.ndarray:
    if backend == "handcrafted":
        return audio_dsp.handcrafted_features(y)
    if backend == "yamnet":
        return yamnet_embedding(y)
    raise ValueError(f"Unknown backend {backend!r}")


def extract_features(df: pd.DataFrame, backend: str, denoise: bool = True,
                     cache: bool = True) -> tuple[np.ndarray, dict]:
    """Feature matrix for every row of df (cached to disk). Returns X and a
    timing dict (mean ms per 5 s clip for preprocessing and featurising)."""
    config.ensure_dirs()
    tag = f"{df['dataset'].iloc[0]}_{backend}_{'dn' if denoise else 'raw'}_{len(df)}"
    path = Path(config.CACHE_DIR) / f"feat_{tag}.npz"
    if cache and path.exists():
        z = np.load(path, allow_pickle=True)
        if list(z["files"]) == list(df["filename"]):
            log.info("Loaded cached features %s", path.name)
            return z["X"], z["timing"].item()
    feats, t_pre, t_feat = [], [], []
    for i, p in enumerate(df["path"]):
        try:
            y = audio_dsp.load_audio(p)
            t0 = time.perf_counter()
            y = audio_dsp.preprocess(y, denoise=denoise)
            t1 = time.perf_counter()
            feats.append(featurize(y, backend))
            t2 = time.perf_counter()
            t_pre.append(t1 - t0)
            t_feat.append(t2 - t1)
        except Exception as e:  # keep going, but never silently
            log.error("Feature extraction failed for %s: %s", p, e)
            raise
        if (i + 1) % 200 == 0:
            log.info("  %s features: %d/%d", backend, i + 1, len(df))
    X = np.vstack(feats)
    timing = {"preprocess_ms": 1000 * float(np.mean(t_pre)),
              "featurize_ms": 1000 * float(np.mean(t_feat))}
    if cache:
        np.savez(path, X=X, files=df["filename"].to_numpy(), timing=np.array(timing, dtype=object))
    return X, timing


def make_head(seed: int = config.SEED):
    return make_pipeline(StandardScaler(),
                         LogisticRegression(C=0.5, max_iter=4000, random_state=seed))


def crossval_oof(df: pd.DataFrame, X: np.ndarray, classes: list[str],
                 seed: int = config.SEED) -> tuple[pd.DataFrame, dict]:
    """Official-fold cross-validation. Returns an OOF probability frame
    (one column per class, plus filename/fold/category) and timing."""
    y = df["category"].to_numpy()
    proba = np.zeros((len(df), len(classes)), dtype=np.float64)
    infer_ms = []
    for fold in sorted(df["fold"].unique()):
        tr, te = df["fold"].to_numpy() != fold, df["fold"].to_numpy() == fold
        model = make_head(seed).fit(X[tr], y[tr])
        order = [list(model.classes_).index(c) for c in classes]
        t0 = time.perf_counter()
        p = model.predict_proba(X[te])[:, order]
        infer_ms.append(1000 * (time.perf_counter() - t0) / te.sum())
        proba[te] = p
        acc = (np.array(classes)[p.argmax(1)] == y[te]).mean()
        log.info("  fold %d: accuracy %.3f (%d test clips)", fold, acc, te.sum())
    out = pd.DataFrame(proba, columns=classes)
    out.insert(0, "filename", df["filename"].to_numpy())
    out.insert(1, "fold", df["fold"].to_numpy())
    out.insert(2, "category", y)
    return out, {"head_infer_ms": float(np.mean(infer_ms))}


def threat_score(oof: pd.DataFrame, classes: list[str]) -> np.ndarray:
    """P(any human-activity class) = sum of threat-class probabilities."""
    cols = [c for c in classes if config.is_threat(c)]
    return oof[cols].sum(axis=1).to_numpy()


def fit_full(df: pd.DataFrame, X: np.ndarray, seed: int = config.SEED):
    """Model trained on every fold (for the live dashboard / cross-dataset test)."""
    return make_head(seed).fit(X, df["category"].to_numpy())
