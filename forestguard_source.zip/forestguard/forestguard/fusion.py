"""Evidence-aware acoustic-vibration fusion.

Main method: Bayesian log-odds fusion under conditional independence

    logit P(g | a, v) = logit P(g | a) + log LR_v(g) [+ consistency] [* reliability]

* P(g | a): audio posterior for threat type g (sum of its class probabilities)
* LR_v(g) = P(vibration family observed | g) / P(vibration family observed | not g),
  estimated from a confusion table built on TRAINING folds only (Laplace
  smoothed). This encodes context-dependent expectations automatically:
  a vehicle almost always couples into the ground, a distant chainsaw rarely
  does, so "no vibration" weighs heavily against a vehicle but barely
  against logging.
* consistency: when audio and vibration both show a tonal source, matching
  fundamentals (within 12 %) add evidence; a mismatch removes some.
* reliability: the agent can down-weight vibration (degraded sensor).
* Missing vibration contributes nothing and is flagged; strong
  disagreement between modalities is flagged as a conflict.

Window-level baselines implemented alongside: audio-only, vibration-only,
AND, OR and a learned late fusion (logistic regression on the two scores).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from sklearn.linear_model import LogisticRegression

from . import config
from .vibration_dsp import FAMILIES

THREAT_TYPES = list(config.THREAT_GROUPS)
EPS = 1e-4


def logit(p):
    p = np.clip(p, EPS, 1 - EPS)
    return np.log(p / (1 - p))


def sigmoid(z):
    return 1 / (1 + np.exp(-z))


@dataclass
class FamilyLikelihoods:
    """P(predicted vibration family | true group), from training folds."""
    table: dict[str, np.ndarray]          # group -> vector over FAMILIES
    counts: dict[str, int]

    @staticmethod
    def fit(true_groups: list[str], pred_families: list[str], alpha: float = 1.0) -> "FamilyLikelihoods":
        groups = sorted(set(true_groups) | set(THREAT_TYPES) | {"non_threat"})
        table, counts = {}, {}
        tg = np.asarray(true_groups)
        pf = np.asarray(pred_families)
        for g in groups:
            if g == "non_threat":
                mask = ~np.isin(tg, THREAT_TYPES)
            elif g == "any_threat":
                continue
            else:
                mask = tg == g
            c = np.array([(pf[mask] == f).sum() for f in FAMILIES], dtype=float)
            table[g] = (c + alpha) / (c.sum() + alpha * len(FAMILIES))
            counts[g] = int(mask.sum())
        mask = np.isin(tg, THREAT_TYPES)
        c = np.array([(pf[mask] == f).sum() for f in FAMILIES], dtype=float)
        table["any_threat"] = (c + alpha) / (c.sum() + alpha * len(FAMILIES))
        counts["any_threat"] = int(mask.sum())
        return FamilyLikelihoods(table, counts)

    def log_lr(self, group: str, family: str, priors: dict[str, float] | None = None) -> float:
        """log P(family | group) / P(family | not group). 'Not group' is the
        prior-weighted mix of every other group (natural or other threats)."""
        i = FAMILIES.index(family)
        num = self.table[group][i]
        if group == "any_threat":
            others = ["non_threat"]
        else:  # every other concrete group (natural groups and other threat types)
            others = [g for g in self.table if g not in (group, "any_threat", "non_threat")
                      and self.counts.get(g, 0) > 0]
        w = np.array([(priors or {}).get(g, self.counts.get(g, 1)) for g in others], dtype=float)
        den = float(np.dot(w / w.sum(), [self.table[g][i] for g in others]))
        return float(np.log(num / den))


@dataclass
class FusionResult:
    p_audio: float
    p_fused: float
    threat_type: str
    p_type_audio: float
    p_type_fused: float
    terms: dict = field(default_factory=dict)
    flags: list = field(default_factory=list)


def fuse_window(audio_group_probs: dict[str, float], p_audio_threat: float,
                vib_family: str | None, vib_family_conf: float, lik: FamilyLikelihoods,
                audio_f0: float = 0.0, vib_dom_freq: float = 0.0, vib_tonality: float = 0.0,
                vib_reliability: float = 1.0, audio_reliability: float = 1.0) -> FusionResult:
    """Fuse one window. audio_group_probs: P(group | audio) for the threat
    groups. Returns the fused P(any threat), the most likely threat type and
    every evidence term (for the explanation log)."""
    flags: list[str] = []
    la = logit(p_audio_threat) * audio_reliability
    terms = {"audio_logit": float(la)}
    ttype = max(THREAT_TYPES, key=lambda g: audio_group_probs.get(g, 0.0))
    p_type_a = float(audio_group_probs.get(ttype, 0.0))
    l_type = logit(p_type_a) * audio_reliability

    if vib_family is None:
        flags.append("vibration_missing")
        terms["vib_log_lr_any"] = 0.0
        terms["vib_log_lr_type"] = 0.0
        lv_any = lv_type = 0.0
    else:
        lv_any = lik.log_lr("any_threat", vib_family) * vib_reliability
        lv_type = lik.log_lr(ttype, vib_family) * vib_reliability
        terms["vib_family"] = vib_family
        terms["vib_family_conf"] = float(vib_family_conf)
        terms["vib_log_lr_any"] = float(lv_any)
        terms["vib_log_lr_type"] = float(lv_type)
        if vib_reliability < 1.0:
            flags.append("vibration_downweighted")

    cons = 0.0
    if vib_family == "machinery" and audio_f0 > 0 and vib_dom_freq > 0 and vib_tonality > 0.6:
        rel = min(abs(vib_dom_freq - audio_f0 * h) / (audio_f0 * h) for h in (0.5, 1, 2))
        cons = 1.5 if rel < 0.12 else -0.5
        terms["freq_match_rel_err"] = float(rel)
        flags.append("frequency_match" if rel < 0.12 else "frequency_mismatch")
    terms["consistency"] = float(cons * vib_reliability)

    z_any = la + lv_any + terms["consistency"]
    z_type = l_type + lv_type + terms["consistency"]
    p_fused = float(sigmoid(z_any))
    if vib_family is not None and p_type_a > 0.7 and lv_type < -1.0:
        flags.append("conflict_audio_threat_vibration_against")
    if vib_family is not None and p_audio_threat < 0.3 and lv_any > 1.5:
        flags.append("conflict_vibration_threat_audio_against")
    return FusionResult(float(p_audio_threat), p_fused, ttype, p_type_a, float(sigmoid(z_type)),
                        terms, flags)


# ------------------------------------------------------------ baselines
class LateFusionLR:
    """Learned late-fusion baseline: logistic regression on
    [logit p_audio, logit p_vib, vib_missing]."""

    def __init__(self, seed: int = config.SEED):
        self.m = LogisticRegression(max_iter=2000, random_state=seed)

    @staticmethod
    def _X(pa, pv, missing):
        pv = np.where(missing, 0.5, pv)
        return np.column_stack([logit(pa), logit(pv), missing.astype(float)])

    def fit(self, pa, pv, missing, y):
        self.m.fit(self._X(np.asarray(pa), np.asarray(pv), np.asarray(missing)), y)
        return self

    def predict_proba(self, pa, pv, missing):
        return self.m.predict_proba(self._X(np.asarray(pa), np.asarray(pv), np.asarray(missing)))[:, 1]


def rule_and(pa, pv, missing, tau=0.5):
    return (np.asarray(pa) > tau) & (np.where(missing, False, np.asarray(pv) > tau))


def rule_or(pa, pv, missing, tau=0.5):
    return (np.asarray(pa) > tau) | (np.where(missing, False, np.asarray(pv) > tau))
