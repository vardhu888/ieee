"""Dataset loading and inspection.

ESC-50: meta/esc50.csv with columns
    filename, fold, target, category, esc10, src_file, take
(verified on the official GitHub release).

FSC22: distributed via Kaggle. Its folder layout differs between mirrors, so
`load_fsc22` inspects whatever is on disk instead of assuming a layout, and
`inspect_fsc22` prints what it found so dataset-specific mapping can be
checked before use.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from . import config
from .logging_utils import get_logger

log = get_logger(__name__)

ESC50_COLUMNS = {"filename", "fold", "target", "category", "esc10", "src_file", "take"}


def load_esc50(root: Path | None = None, forest_only: bool = True) -> pd.DataFrame:
    root = Path(root or config.ESC50_ROOT)
    meta_path = root / "meta" / "esc50.csv"
    if not meta_path.exists():
        raise FileNotFoundError(
            f"ESC-50 metadata not found at {meta_path}. "
            "Clone it with: git clone --depth 1 https://github.com/karolpiczak/ESC-50.git"
        )
    df = pd.read_csv(meta_path)
    missing = ESC50_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Unexpected ESC-50 metadata, missing columns: {missing}")
    df["path"] = df["filename"].map(lambda f: str(root / "audio" / f))
    if forest_only:
        unknown = set(config.FOREST_CLASSES) - set(df["category"])
        if unknown:
            raise ValueError(f"Taxonomy classes not present in ESC-50: {unknown}")
        df = df[df["category"].isin(config.FOREST_CLASSES)].copy()
    df["group"] = df["category"].map(config.CLASS_TO_GROUP)
    df["is_threat"] = df["category"].map(config.is_threat)
    df["dataset"] = "ESC-50"
    df = df.reset_index(drop=True)
    log.info("ESC-50 loaded: %d clips, %d classes, folds %s",
             len(df), df["category"].nunique(), sorted(df["fold"].unique()))
    return df


def summarize(df: pd.DataFrame) -> pd.DataFrame:
    return (df.groupby(["group", "category"]).size()
              .rename("clips").reset_index()
              .sort_values(["group", "category"]))


# ----------------------------------------------------------------- FSC22
AUDIO_EXT = {".wav", ".mp3", ".flac", ".ogg"}

# Mapping from FSC22 class names (lower-cased, separators stripped) to our
# taxonomy classes. Only classes with a clear counterpart are mapped; the
# mapping is applied after inspection, and unmapped classes are reported.
FSC22_TO_TAXONOMY = {
    "chainsaw": "chainsaw",
    "handsaw": "hand_saw",
    "vehicleengine": "engine",
    "helicopter": "helicopter",
    "footsteps": "footsteps",
    "speaking": "laughing",       # coarse: both map to group human_voice
    "firework": "fireworks",
    "thunderstorm": "thunderstorm",
    "rain": "rain",
    "wind": "wind",
    "fire": "crackling_fire",
    "waterdrops": "water_drops",
    "birdchirping": "chirping_birds",
    "insect": "insects",
    "frog": "frog",
}


def _norm(name: str) -> str:
    return "".join(ch for ch in name.lower() if ch.isalnum())


def inspect_fsc22(root: Path | None = None) -> dict:
    """Report what an FSC22 download actually contains (CSV files, audio
    folder names, class-name candidates)."""
    root = Path(root or config.FSC22_ROOT)
    if not root.exists():
        return {"found": False, "root": str(root)}
    csvs = sorted(str(p.relative_to(root)) for p in root.rglob("*.csv"))
    audio = [p for p in root.rglob("*") if p.suffix.lower() in AUDIO_EXT]
    parents = pd.Series([p.parent.name for p in audio]).value_counts()
    return {"found": True, "root": str(root), "csv_files": csvs,
            "n_audio": len(audio), "audio_parent_dirs": parents.head(40).to_dict()}


def load_fsc22(root: Path | None = None) -> pd.DataFrame:
    """Build a dataframe for FSC22 with the same columns as ESC-50 where
    possible. Labels are taken from a metadata CSV if one with a class column
    exists, otherwise from the audio file's parent folder name."""
    root = Path(root or config.FSC22_ROOT)
    audio = [p for p in root.rglob("*") if p.suffix.lower() in AUDIO_EXT]
    if not audio:
        raise FileNotFoundError(f"No audio files found under {root}")
    by_name = {p.name: p for p in audio}
    df = None
    for csv in root.rglob("*.csv"):
        meta = pd.read_csv(csv)
        cols = {c.lower(): c for c in meta.columns}
        fcol = next((cols[c] for c in cols if "file" in c or "dataset" in c), None)
        ccol = next((cols[c] for c in cols if "class" in c and "id" not in c), None)
        if fcol and ccol and meta[fcol].astype(str).isin(by_name).any():
            df = pd.DataFrame({"filename": meta[fcol].astype(str),
                               "raw_class": meta[ccol].astype(str)})
            df = df[df["filename"].isin(by_name)]
            log.info("FSC22 labels taken from %s (%s, %s)", csv.name, fcol, ccol)
            break
    if df is None:
        df = pd.DataFrame({"filename": [p.name for p in audio],
                           "raw_class": [p.parent.name for p in audio]})
        log.info("FSC22 labels taken from parent folder names")
    df["path"] = df["filename"].map(lambda f: str(by_name[f]))
    df["category"] = df["raw_class"].map(lambda c: FSC22_TO_TAXONOMY.get(_norm(c)))
    unmapped = sorted(df.loc[df["category"].isna(), "raw_class"].unique())
    if unmapped:
        log.info("FSC22 classes without a taxonomy counterpart (dropped): %s", unmapped)
    df = df.dropna(subset=["category"]).copy()
    df["group"] = df["category"].map(config.CLASS_TO_GROUP)
    df["is_threat"] = df["category"].map(config.is_threat)
    df["dataset"] = "FSC22"
    return df.reset_index(drop=True)
