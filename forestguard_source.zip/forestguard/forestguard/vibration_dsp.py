"""Vibration signal analysis (label-agnostic: sees only the waveform).

Signal processing: RMS energy, FFT / Welch PSD, dominant frequency, band
energies, tonality and harmonic check, Hilbert envelope, envelope peak
detection, gait-cadence periodicity (envelope autocorrelation),
impulsiveness (kurtosis, crest factor), duty cycle and burst concentration.

Interpretation, in two stages:
1. A physical activity gate: is anything above the sensor's noise floor?
   (RMS- and peak-based SNR against the agent's adaptive baseline.)
2. A small classifier over the named features above that predicts the
   source *family* (human_gait, animal_gait, machinery, transient, weather,
   none). It is trained only on simulations of training-fold clips. Hand
   rules were tried first and rejected: resonant footstep impulses look
   tonal and thunder bursts produce gait-like envelope peaks.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
from scipy import signal as sps
from scipy.stats import kurtosis
from sklearn.ensemble import RandomForestClassifier

from . import config

BANDS = {"b_1_10": (1, 10), "b_10_40": (10, 40), "b_40_120": (40, 120), "b_120_250": (120, 249)}
BASELINE_RMS = 0.050   # measured: mean RMS of 30 simulated quiet windows (sd 0.0008)
FAMILIES = ["none", "human_gait", "animal_gait", "machinery", "transient", "weather"]

PROFILE_TO_FAMILY = {
    "biped_gait": "human_gait", "incidental_steps": "human_gait",
    "quadruped_gait": "animal_gait", "light_gait": "animal_gait",
    "machinery_vehicle": "machinery", "machinery_airborne": "machinery",
    "machinery_handheld": "machinery", "periodic_stroke": "machinery",
    "blast_transient": "transient",
    "weather_rumble": "weather", "rain_impacts": "weather", "root_sway": "weather",
}


@dataclass
class VibFeatures:
    rms: float
    snr_db: float
    peak_snr_db: float
    crest: float
    kurt: float
    dom_freq: float
    tonality: float
    harmonic: float
    cadence_hz: float
    cadence_strength: float
    n_peaks: int
    ipi_cv: float
    doublet_ratio: float
    duty: float
    burst_frac: float
    b_1_10: float
    b_10_40: float
    b_40_120: float
    b_120_250: float

    @property
    def activity(self) -> float:
        """P(something is above the noise floor), from the stronger of the
        RMS- and peak-based SNRs (4 dB midpoint)."""
        return float(1 / (1 + np.exp(-(max(self.snr_db, self.peak_snr_db) - 4.0) / 1.5)))

    def vector(self) -> np.ndarray:
        return np.array(list(asdict(self).values()), dtype=np.float32)

    @staticmethod
    def names() -> list[str]:
        return list(VibFeatures.__dataclass_fields__)


def fft_spectrum(x: np.ndarray, fs: int = config.VIB_SR) -> tuple[np.ndarray, np.ndarray]:
    X = np.abs(np.fft.rfft(x * np.hanning(len(x)))) * 2 / len(x)
    return np.fft.rfftfreq(len(x), 1 / fs), X


def envelope(x: np.ndarray, fs: int = config.VIB_SR, lp_hz: float = 12.0) -> np.ndarray:
    env = np.abs(sps.hilbert(x))
    sos = sps.butter(2, lp_hz, btype="lowpass", fs=fs, output="sos")
    return sps.sosfiltfilt(sos, env)


def analyse(x: np.ndarray, fs: int = config.VIB_SR, baseline_rms: float = BASELINE_RMS) -> VibFeatures:
    """`baseline_rms` is the sensor's quiet-period RMS. The agent keeps an
    adaptive estimate of it (updated only in windows it judges quiet)."""
    x = np.asarray(x, dtype=np.float64)
    if x.size < fs or not np.all(np.isfinite(x)):
        raise ValueError("Vibration window too short or contains non-finite values")
    x = x - x.mean()
    rms = float(np.sqrt(np.mean(x ** 2)))
    snr_db = float(20 * np.log10(rms / max(baseline_rms, 1e-9)))
    peak = float(np.max(np.abs(x)))
    # Gaussian noise peaks reach ~4 sigma over 2500 samples
    peak_snr = float(20 * np.log10(peak / (4 * max(baseline_rms, 1e-9))))

    f, P = sps.welch(x, fs=fs, nperseg=512)
    valid = f >= 2
    dom = float(f[valid][np.argmax(P[valid])])
    ratio = float(np.max(P[valid]) / (np.median(P[valid]) + 1e-20))
    tonality = float(1 - np.exp(-np.log10(ratio + 1) / 2))
    harm = 0.0
    if 2 * dom < fs / 2:
        i2 = int(np.argmin(np.abs(f - 2 * dom)))
        harm = float(np.log10(P[max(i2 - 1, 0): i2 + 2].max() / (np.median(P[valid]) + 1e-20) + 1) / 3)
    tot = P[valid].sum() + 1e-20
    bands = {k: float(P[(f >= lo) & (f < hi)].sum() / tot) for k, (lo, hi) in BANDS.items()}

    env = envelope(x, fs)
    env_n = env - env.mean()
    ac = np.correlate(env_n, env_n, "full")[len(env_n) - 1:]
    ac /= ac[0] + 1e-12
    lo, hi = int(fs / 4.5), int(fs / 0.7)
    lag = lo + int(np.argmax(ac[lo:hi]))
    cad, cad_s = float(fs / lag), float(max(ac[lag], 0.0))

    thr = np.median(env) + 4 * np.median(np.abs(env - np.median(env))) + 1e-12
    peaks, _ = sps.find_peaks(env, height=thr, distance=int(0.08 * fs))
    ipi = np.diff(peaks) / fs
    ipi_cv = float(ipi.std() / ipi.mean()) if len(ipi) >= 2 else 0.0
    doublet = float(np.mean(ipi < 0.3)) if len(ipi) else 0.0
    e = np.clip(env - np.median(env), 0, None)
    duty = float(np.mean(e > 0.5 * e.max())) if e.max() > 0 else 0.0
    # burst concentration: share of energy inside the most energetic 1.5 s
    energy = x ** 2
    w = int(1.5 * fs)
    run = np.convolve(energy, np.ones(w), "valid")
    burst = float(run.max() / (energy.sum() + 1e-20))

    return VibFeatures(rms, snr_db, peak_snr, peak / (rms + 1e-12), float(kurtosis(x)), dom,
                       tonality, harm, cad, cad_s, int(len(peaks)), ipi_cv, doublet, duty, burst,
                       **bands)


class SourceFamilyClassifier:
    """Random forest over VibFeatures -> P(source family). Small (100 trees,
    depth 10) so it runs on a microcontroller-class edge CPU."""

    def __init__(self, seed: int = config.SEED):
        self.model = RandomForestClassifier(n_estimators=100, max_depth=10, min_samples_leaf=3,
                                            class_weight="balanced", random_state=seed, n_jobs=1)

    def fit(self, X: np.ndarray, families: list[str]) -> "SourceFamilyClassifier":
        self.model.fit(X, families)
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        p = self.model.predict_proba(np.atleast_2d(X))
        out = np.zeros((p.shape[0], len(FAMILIES)))
        for j, c in enumerate(self.model.classes_):
            out[:, FAMILIES.index(c)] = p[:, j]
        return out

    def feature_importance(self) -> dict:
        return dict(sorted(zip(VibFeatures.names(), self.model.feature_importances_),
                           key=lambda kv: -kv[1]))
