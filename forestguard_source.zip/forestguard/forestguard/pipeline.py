"""End-to-end data preparation: audio OOF predictions, audio-derived hints,
simulated vibration, fold-matched vibration models, window observations
and monitoring episodes.

Leakage rules (enforced here):
* audio probabilities are out-of-fold (official ESC-50 folds),
* every vibration model / likelihood table used for a window from fold f
  is trained only on simulations of clips from the other four folds; the
  likelihood table uses an inner fold-wise CV so it is not estimated on the
  classifier's own training predictions,
* episodes for fold f are assembled only from fold-f clips.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

from . import audio_dsp, audio_models, config, data
from . import vibration_dsp as vd
from . import vibration_sim as vs
from .agent import WindowObservation
from .fusion import FamilyLikelihoods
from .logging_utils import get_logger

log = get_logger(__name__)


# ----------------------------------------------------------------- audio
def audio_hints(df: pd.DataFrame) -> dict:
    path = config.CACHE_DIR / f"hints_{df['dataset'].iloc[0]}_{len(df)}.json"
    if path.exists():
        return json.loads(path.read_text())
    out = {}
    for i, (fn, p) in enumerate(zip(df["filename"], df["path"])):
        y = audio_dsp.preprocess(audio_dsp.load_audio(p))
        h = vs.audio_hint_from_clip(y, config.AUDIO_SR)
        segs = audio_dsp.segment_activity(y)
        h["segments"] = [[round(s.start_s, 3), round(s.end_s, 3)] for s in segs]
        out[fn] = h
        if (i + 1) % 200 == 0:
            log.info("  audio hints %d/%d", i + 1, len(df))
    config.ensure_dirs()
    path.write_text(json.dumps(out))
    return out


def prepare_audio(backend: str = "handcrafted", denoise: bool = True):
    df = data.load_esc50()
    X, t_feat = audio_models.extract_features(df, backend, denoise=denoise)
    classes = config.FOREST_CLASSES
    oof, t_head = audio_models.crossval_oof(df, X, classes)
    return df, X, oof, {**t_feat, **t_head}


# ------------------------------------------------------------- vibration
def family_of(meta: dict) -> str:
    return vd.PROFILE_TO_FAMILY.get(meta.get("profile", "none"), "none")


def simulate_features(df: pd.DataFrame, hints: dict, key: str, params: vs.SimParams):
    rows, feats = [], []
    for fn, cat, fold in zip(df["filename"], df["category"], df["fold"]):
        w = vs.simulate_window(fn, cat, params, audio_hint=hints[fn], scenario_key=key)
        if w.available:
            feats.append(vd.analyse(w.signal).vector())
        else:
            feats.append(np.full(len(vd.VibFeatures.names()), np.nan, dtype=np.float32))
        rows.append({"filename": fn, "category": cat, "fold": fold, "available": w.available,
                     "family": family_of(w.meta), **{f"m_{k}": v for k, v in w.meta.items()}})
    return pd.DataFrame(rows), np.vstack(feats)


@dataclass
class FoldVibModels:
    family_clf: vd.SourceFamilyClassifier
    threat_clf: RandomForestClassifier
    lik: FamilyLikelihoods


def _rf(seed=config.SEED):
    return RandomForestClassifier(n_estimators=100, max_depth=10, min_samples_leaf=3,
                                  class_weight="balanced", random_state=seed, n_jobs=1)


def train_vibration_models(df: pd.DataFrame, hints: dict, params: vs.SimParams,
                           n_real: int = 3) -> tuple[dict[int, FoldVibModels], pd.DataFrame]:
    """Fit fold-matched vibration models from n_real simulated realisations
    per training clip."""
    metas, Xs = [], []
    for r in range(n_real):
        m, X = simulate_features(df, hints, f"train{r}", params)
        metas.append(m)
        Xs.append(X)
    meta = pd.concat(metas, ignore_index=True)
    X = np.vstack(Xs)
    ok = meta["available"].to_numpy()
    meta, X = meta[ok].reset_index(drop=True), X[ok]
    meta["group"] = meta["category"].map(config.CLASS_TO_GROUP)
    meta["threat"] = meta["category"].map(config.is_threat)
    folds = sorted(df["fold"].unique())
    models: dict[int, FoldVibModels] = {}
    for f in folds:
        tr = meta["fold"].to_numpy() != f
        fam = vd.SourceFamilyClassifier().fit(X[tr], meta.loc[tr, "family"].tolist())
        thr = _rf().fit(X[tr], meta.loc[tr, "threat"].to_numpy())
        # inner CV over the training folds for an unbiased likelihood table
        pred_fam = np.empty(tr.sum(), dtype=object)
        sub = meta[tr].reset_index(drop=True)
        Xtr = X[tr]
        for g in sorted(sub["fold"].unique()):
            inn = sub["fold"].to_numpy() != g
            m = vd.SourceFamilyClassifier().fit(Xtr[inn], sub.loc[inn, "family"].tolist())
            p = m.predict_proba(Xtr[~inn])
            pred_fam[~inn] = [vd.FAMILIES[i] for i in p.argmax(1)]
        lik = FamilyLikelihoods.fit(sub["group"].tolist(), list(pred_fam))
        models[f] = FoldVibModels(fam, thr, lik)
        log.info("  vibration models for test fold %d trained on %d windows", f, int(tr.sum()))
    return models, meta


# ------------------------------------------------------- observations
def make_observation(window_id: int, t_start: float, filename: str, category: str,
                     audio_row: pd.Series, hint: dict, models: FoldVibModels,
                     params: vs.SimParams, key: str) -> tuple[WindowObservation, dict]:
    probs = {c: float(audio_row[c]) for c in config.FOREST_CLASSES}
    t0 = time.perf_counter()
    w = vs.simulate_window(filename, category, params, audio_hint=hint, scenario_key=key)
    obs = WindowObservation(window_id, t_start, probs, audio_f0=float(hint.get("f0", 0.0)),
                            audio_segments=hint.get("segments", []), vib_available=w.available)
    extra = {"vib_meta": w.meta, "p_vib_threat": np.nan, "vib_ms": 0.0}
    if w.available:
        t1 = time.perf_counter()
        f = vd.analyse(w.signal)
        v = f.vector()[None, :]
        pf = models.family_clf.predict_proba(v)[0]
        extra["vib_ms"] = 1000 * (time.perf_counter() - t1)
        i = int(np.argmax(pf))
        obs.vib_family, obs.vib_family_conf = vd.FAMILIES[i], float(pf[i])
        obs.vib_dom_freq, obs.vib_tonality = f.dom_freq, f.tonality
        obs.vib_rms, obs.vib_activity = f.rms, f.activity
        extra["p_vib_threat"] = float(models.threat_clf.predict_proba(v)[0, list(models.threat_clf.classes_).index(True)])
        extra["signal"] = w.signal
    extra["sim_ms"] = 1000 * (time.perf_counter() - t0) - extra["vib_ms"]
    return obs, extra


# ----------------------------------------------------------- episodes
EP_WINDOWS = 12   # 12 x 5 s = 60 s

BENIGN_TYPES = ["calm", "storm", "livestock"]
THREAT_TYPES_EP = ["logging", "vehicle_pass", "foot_patrol", "poaching", "brief_presence"]


def _pool(df_f: pd.DataFrame, groups: list[str] | None = None, classes: list[str] | None = None):
    m = np.ones(len(df_f), bool)
    if groups:
        m &= df_f["group"].isin(groups).to_numpy()
    if classes:
        m &= df_f["category"].isin(classes).to_numpy()
    return df_f.loc[m, "filename"].tolist()


def build_episodes(df: pd.DataFrame, fold: int, n_per_type: int, seed: int = config.SEED) -> list[dict]:
    rng = np.random.default_rng(seed + fold)
    d = df[df["fold"] == fold]
    calm = _pool(d, ["wildlife", "fire_water"])
    weather = _pool(d, ["weather"])
    animals = _pool(d, ["large_animal"])
    cat = dict(zip(d["filename"], d["category"]))

    def background(kind):
        if kind == "calm":
            return [rng.choice(calm) for _ in range(EP_WINDOWS)]
        if kind == "storm":
            return [rng.choice(weather) if rng.random() < 0.6 else rng.choice(calm) for _ in range(EP_WINDOWS)]
        return [rng.choice(animals) if rng.random() < 0.5 else rng.choice(calm) for _ in range(EP_WINDOWS)]

    eps = []
    for kind in BENIGN_TYPES:
        for _ in range(n_per_type):
            eps.append({"kind": kind, "threat": False, "files": background(kind), "threat_windows": []})
    for kind in THREAT_TYPES_EP:
        for _ in range(n_per_type):
            files = background(rng.choice(BENIGN_TYPES))
            if kind == "logging":
                L = int(rng.integers(4, 9)); s = int(rng.integers(0, EP_WINDOWS - L + 1))
                idx = list(range(s, s + L)); src = _pool(d, ["logging"])
            elif kind == "vehicle_pass":
                L = int(rng.integers(2, 4)); s = int(rng.integers(0, EP_WINDOWS - L + 1))
                idx = list(range(s, s + L)); src = _pool(d, ["vehicle"])
            elif kind == "foot_patrol":
                L = int(rng.integers(3, 7)); idx = sorted(rng.choice(EP_WINDOWS, L, replace=False).tolist())
                src = _pool(d, ["human_movement", "human_voice"])
            elif kind == "poaching":
                s = int(rng.integers(0, EP_WINDOWS - 4))
                idx = [s, s + 1, s + 3]; src = None
            else:  # brief_presence
                idx = [int(rng.integers(0, EP_WINDOWS))]; src = _pool(d, ["human_movement", "human_voice"])
            for j, i in enumerate(idx):
                if kind == "poaching":
                    files[i] = rng.choice(_pool(d, ["firearm_proxy"]) if j == 2 else _pool(d, ["human_movement"]))
                else:
                    files[i] = rng.choice(src)
            eps.append({"kind": kind, "threat": True, "files": files, "threat_windows": idx})
    for e in eps:
        e["fold"] = fold
        e["categories"] = [cat[f] for f in e["files"]]
    return eps
