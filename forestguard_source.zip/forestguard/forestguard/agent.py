"""Stateful, explainable decision agent (no LLM; every decision is a
traceable rule applied to fused evidence).

Per 5-second window the agent:
 1. updates its environmental context (running weather estimate from audio),
 2. decides whether to spend energy on vibration analysis (on-demand duty
    cycling: only when audio is suspicious or an investigation is open),
 3. tracks vibration-sensor health (dropouts, rising noise floor) and
    down-weights an unreliable sensor,
 4. fuses audio and vibration evidence (fusion.fuse_window),
 5. updates a decaying per-threat-type belief and an event history,
 6. applies escalation rules whose evidence bar rises when independent
    corroboration is missing or the context makes audio less reliable,
 7. writes a hash-chained audit record explaining the decision.
"""
from __future__ import annotations

import hashlib
import json
from collections import deque
from dataclasses import asdict, dataclass, field
from enum import Enum

import numpy as np

from . import config
from .fusion import THREAT_TYPES, FamilyLikelihoods, FusionResult, fuse_window, logit


class State(str, Enum):
    MONITORING = "MONITORING"
    WATCH = "WATCH"
    ESCALATED = "ESCALATED"


class Action(str, Enum):
    CONTINUE = "CONTINUE_MONITORING"
    ACTIVATE_VIBRATION = "ACTIVATE_VIBRATION_ANALYSIS"
    RAISE_WATCH = "RAISE_WATCH"
    HOLD_FOR_CORROBORATION = "HOLD_FOR_CORROBORATION"
    ESCALATE = "ESCALATE_TO_RANGER"
    DE_ESCALATE = "DE_ESCALATE"
    FLAG_SENSOR = "FLAG_SENSOR_MAINTENANCE"


@dataclass
class AgentConfig:
    vib_policy: str = "on_demand"     # on_demand | always | never
    trigger_p: float = 0.30           # audio P(threat) that wakes vibration analysis
    watch_p: float = 0.50
    persistence_k: int = 2            # suspicious windows needed (with corroboration)
    history: int = 6                  # windows (30 s) of memory for persistence
    missing_extra_k: int = 1          # extra windows required without corroboration
    storm_extra_k: int = 1            # extra windows for engine-like types in storm context
    use_context: bool = True
    corroboration_lr: float = 1.0     # log LR (vibration, type) counting as corroboration
    immediate_p: float = 0.97
    firearm_single_p: float = 0.90
    cooldown: int = 4
    belief_decay: float = 0.6
    storm_ctx: float = 0.40
    # v2 changes (from failure analysis of v1 on the first episode draw):
    merge_human: bool = True            # footsteps + voices = one "human_presence" incident
    expectation_aware_bar: bool = True  # demand corroboration only where coupling is expected


INCIDENT = {"human_movement": "human_presence", "human_voice": "human_presence"}


@dataclass
class WindowObservation:
    window_id: int
    t_start: float
    audio_class_probs: dict           # ESC-50 class -> probability (model output)
    audio_f0: float = 0.0
    audio_segments: list = field(default_factory=list)
    vib_available: bool = False
    vib_family: str | None = None
    vib_family_conf: float = 0.0
    vib_dom_freq: float = 0.0
    vib_tonality: float = 0.0
    vib_rms: float = 0.0
    vib_activity: float = 0.0

    def group_probs(self) -> dict:
        out: dict[str, float] = {}
        for c, p in self.audio_class_probs.items():
            g = config.CLASS_TO_GROUP.get(c)
            if g:
                out[g] = out.get(g, 0.0) + float(p)
        return out

    def p_threat(self) -> float:
        return float(sum(p for c, p in self.audio_class_probs.items() if config.is_threat(c)))


@dataclass
class Decision:
    window_id: int
    t_start: float
    state_before: str
    state_after: str
    action: str
    threat_type: str
    p_audio: float
    p_fused: float
    belief: float
    vibration_used: bool
    reasons: list
    flags: list
    evidence: dict
    alert_id: int | None = None
    prev_hash: str = ""
    hash: str = ""


class AuditLog:
    """Append-only, hash-chained decision log (SHA-256 over each record and
    the previous hash), so any later edit of a record breaks the chain."""

    def __init__(self):
        self.records: list[dict] = []
        self._last = "GENESIS"

    def append(self, d: Decision) -> Decision:
        d.prev_hash = self._last
        body = asdict(d)
        body.pop("hash")
        d.hash = hashlib.sha256(json.dumps(body, sort_keys=True, default=str).encode()).hexdigest()
        self._last = d.hash
        self.records.append(asdict(d))
        return d

    def verify(self) -> bool:
        prev = "GENESIS"
        for r in self.records:
            body = dict(r)
            h = body.pop("hash")
            if body["prev_hash"] != prev:
                return False
            if hashlib.sha256(json.dumps(body, sort_keys=True, default=str).encode()).hexdigest() != h:
                return False
            prev = h
        return True

    def to_jsonl(self, path) -> None:
        with open(path, "w") as f:
            for r in self.records:
                f.write(json.dumps(r, default=str) + "\n")


class ForestGuardAgent:
    def __init__(self, likelihoods: FamilyLikelihoods, cfg: AgentConfig | None = None,
                 baseline_rms: float = 0.050, node_id: str = "node-01"):
        self.lik = likelihoods
        self.cfg = cfg or AgentConfig()
        self.node_id = node_id
        self.state = State.MONITORING
        self.belief = {g: 0.0 for g in THREAT_TYPES}
        self.hist: deque = deque(maxlen=self.cfg.history)
        self.weather_ctx = 0.0
        self.calib_rms = baseline_rms
        self.noise_ema = baseline_rms
        self.vib_access: deque = deque(maxlen=5)
        self.quiet_streak = 0
        self.alerts: list[dict] = []
        self.log = AuditLog()
        self.vib_windows_used = 0
        self.windows_seen = 0
        self.sensor_flagged = False

    # ------------------------------------------------------------ helpers
    def _incident(self, g: str) -> str:
        return INCIDENT.get(g, g) if self.cfg.merge_human else g

    def _count(self, g: str) -> int:
        inc = self._incident(g)
        return sum(1 for h in self.hist if h["suspicious"] and self._incident(h["type"]) == inc)

    def _corroborated(self, g: str) -> bool:
        inc = self._incident(g)
        return any(self._incident(h["type"]) == inc and h["vib_lr"] >= self.cfg.corroboration_lr
                   for h in self.hist)

    def expected_coupling(self, g: str) -> float:
        """P(vibration shows a source | threat type g), from the training-fold
        likelihood table: 1 - P(family = none | g)."""
        from .vibration_dsp import FAMILIES
        return float(1 - self.lik.table[g][FAMILIES.index("none")])

    def _vib_reliability(self) -> tuple[float, list[str]]:
        notes = []
        rel = 1.0
        if self.noise_ema > 1.8 * self.calib_rms:
            rel = 0.5
            notes.append(f"vibration noise floor {self.noise_ema / self.calib_rms:.1f}x calibration: weight halved")
        return rel, notes

    # ------------------------------------------------------------ main step
    def step(self, obs: WindowObservation) -> Decision:
        c = self.cfg
        self.windows_seen += 1
        before = self.state
        reasons: list[str] = []
        gp = obs.group_probs()
        pa = obs.p_threat()

        # 1. context
        self.weather_ctx = 0.7 * self.weather_ctx + 0.3 * gp.get("weather", 0.0)
        storm = c.use_context and self.weather_ctx > c.storm_ctx

        # 2. vibration access policy
        want_vib = (c.vib_policy == "always" or
                    (c.vib_policy == "on_demand" and (pa >= c.trigger_p or self.state != State.MONITORING)))
        use_vib = want_vib and obs.vib_available
        if want_vib:
            self.vib_access.append(obs.vib_available)
            self.vib_windows_used += 1
        if want_vib and c.vib_policy == "on_demand" and self.state == State.MONITORING:
            reasons.append(f"audio P(threat)={pa:.2f} >= {c.trigger_p}: vibration analysis activated")

        # 3. sensor health
        flags_extra = []
        if want_vib and not obs.vib_available:
            reasons.append("vibration channel missing for this window")
        if len(self.vib_access) == 5 and sum(not a for a in self.vib_access) >= 3 and not self.sensor_flagged:
            self.sensor_flagged = True
            flags_extra.append("sensor_maintenance")
            reasons.append("vibration missing in >=3 of last 5 requests: maintenance flagged")
        if use_vib and pa < 0.2 and obs.vib_family in ("none", "weather"):
            self.noise_ema = 0.9 * self.noise_ema + 0.1 * obs.vib_rms
        rel, rel_notes = self._vib_reliability()
        reasons += rel_notes

        # 4. fusion
        fr: FusionResult = fuse_window(
            gp, pa, obs.vib_family if use_vib else None, obs.vib_family_conf, self.lik,
            audio_f0=obs.audio_f0, vib_dom_freq=obs.vib_dom_freq, vib_tonality=obs.vib_tonality,
            vib_reliability=rel)
        if not want_vib and "vibration_missing" in fr.flags:  # duty-cycled off, not a fault
            fr.flags[fr.flags.index("vibration_missing")] = "vibration_not_requested"
        g = fr.threat_type
        vib_lr = fr.terms.get("vib_log_lr_type", 0.0)
        suspicious = fr.p_fused >= c.watch_p

        # 5. belief + history
        for k in self.belief:
            self.belief[k] *= c.belief_decay
        if suspicious:
            self.belief[g] += float(np.clip(logit(fr.p_type_fused), -3, 6))
        self.hist.append({"type": g, "suspicious": suspicious, "vib_lr": vib_lr if use_vib else 0.0,
                          "p": fr.p_fused})

        if use_vib:
            sign = "supports" if vib_lr > 0.3 else ("argues against" if vib_lr < -0.3 else "is neutral on")
            reasons.append(f"vibration pattern '{obs.vib_family}' {sign} {g} (log LR {vib_lr:+.2f})")
        if "frequency_match" in fr.flags:
            reasons.append("audio and vibration fundamentals match: same physical source likely")
        if any(f.startswith("conflict") for f in fr.flags):
            reasons.append("modalities disagree: holding decision for more evidence")

        # 6. decision rules
        action = Action.CONTINUE
        alert_id = None
        n = self._count(g)
        corr = self._corroborated(g)
        coupling = self.expected_coupling(g)
        needs_corr = (not c.expectation_aware_bar) or coupling >= 0.5
        k_req = c.persistence_k + (0 if (corr or not needs_corr) else c.missing_extra_k)
        if suspicious and not corr and not needs_corr:
            reasons.append(f"{g} rarely couples into the ground (expected {coupling:.0%}): "
                           "absence of vibration not held against it")
        if storm and g in ("vehicle", "logging", "firearm_proxy") and not corr:
            k_req += c.storm_extra_k
            if suspicious:
                reasons.append(f"storm context ({self.weather_ctx:.2f}): thunder can mimic engines/blasts, bar raised")

        escalate = False
        if suspicious:
            if fr.p_type_fused >= c.immediate_p and vib_lr >= c.corroboration_lr:
                escalate = True
                reasons.append(f"P({g})={fr.p_type_fused:.2f} with independent vibration corroboration: immediate escalation")
            elif g == "firearm_proxy" and fr.p_type_fused >= c.firearm_single_p and not (storm and not corr):
                escalate = True
                reasons.append("impulsive blast-like event: single-event escalation (gunshots rarely repeat on cue)")
            elif n >= k_req:
                escalate = True
                reasons.append(f"{n} suspicious {self._incident(g)} windows in last {len(self.hist) * 5:.0f}s "
                               f"(required {k_req}, corroborated={corr})")
            else:
                reasons.append(f"suspicious {self._incident(g)} ({n}/{k_req} windows): awaiting persistence"
                               + ("" if corr or not needs_corr else " or vibration corroboration"))

        if escalate and self.state != State.ESCALATED:
            self.state = State.ESCALATED
            action = Action.ESCALATE
            alert_id = len(self.alerts) + 1
            self.alerts.append({"alert_id": alert_id, "node": self.node_id, "t_start": obs.t_start,
                                "window_id": obs.window_id, "threat_type": self._incident(g),
                                "confidence": float(fr.p_type_fused), "corroborated": corr or vib_lr >= c.corroboration_lr,
                                "storm_context": bool(storm), "reasons": list(reasons)})
        elif escalate:
            action = Action.CONTINUE
            reasons.append("investigation already open: alert not duplicated")
        elif suspicious:
            if self.state == State.MONITORING:
                self.state = State.WATCH
                action = Action.ACTIVATE_VIBRATION if c.vib_policy == "on_demand" else Action.RAISE_WATCH
            else:
                action = Action.HOLD_FOR_CORROBORATION
        elif "sensor_maintenance" in flags_extra:
            action = Action.FLAG_SENSOR

        # cooldown / de-escalation
        self.quiet_streak = 0 if suspicious else self.quiet_streak + 1
        if self.state != State.MONITORING and self.quiet_streak >= c.cooldown:
            self.state = State.MONITORING
            action = Action.DE_ESCALATE
            reasons.append(f"{c.cooldown} consecutive non-suspicious windows: back to monitoring")
        if not reasons:
            reasons.append(f"no suspicious evidence (audio P(threat)={pa:.2f})")

        d = Decision(obs.window_id, obs.t_start, before.value, self.state.value, action.value, g,
                     round(pa, 4), round(fr.p_fused, 4), round(self.belief[g], 3), use_vib,
                     reasons, fr.flags + flags_extra, {k: (round(v, 4) if isinstance(v, float) else v)
                                                       for k, v in fr.terms.items()}, alert_id)
        return self.log.append(d)

    def summary(self) -> dict:
        return {"windows": self.windows_seen, "alerts": len(self.alerts),
                "vibration_duty_cycle": self.vib_windows_used / max(self.windows_seen, 1),
                "sensor_flagged": self.sensor_flagged, "log_intact": self.log.verify()}
