"""All experiments. Results are written to results/ and every table is
tagged with its evidence level:

  REAL       - measured on real ESC-50 audio (official 5-fold CV)
  SIMULATED  - involves the synthetic vibration channel and simulated
               monitoring episodes built from held-out real audio clips
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict

import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)

from . import config, pipeline
from . import vibration_sim as vs
from .agent import AgentConfig, ForestGuardAgent
from .fusion import LateFusionLR, fuse_window, rule_and, rule_or
from .logging_utils import get_logger

log = get_logger(__name__)


def binary_metrics(y, yhat, score=None) -> dict:
    y, yhat = np.asarray(y, bool), np.asarray(yhat, bool)
    tn, fp, fn, tp = confusion_matrix(y, yhat, labels=[False, True]).ravel()
    out = {"precision": precision_score(y, yhat, zero_division=0),
           "recall": recall_score(y, yhat, zero_division=0),
           "f1": f1_score(y, yhat, zero_division=0),
           "fpr": fp / max(fp + tn, 1), "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn)}
    if score is not None and len(set(y)) == 2:
        s = np.nan_to_num(np.asarray(score, float), nan=0.5)
        out["auc"] = roc_auc_score(y, s)
    return {k: (round(float(v), 4) if isinstance(v, float) else v) for k, v in out.items()}


# --------------------------------------------------------- audio (REAL)
def audio_experiment(df, oof, timing, tag="handcrafted") -> dict:
    classes = config.FOREST_CLASSES
    P = oof[classes].to_numpy()
    y = oof["category"].to_numpy()
    pred = np.array(classes)[P.argmax(1)]
    per_fold = [accuracy_score(y[oof.fold == f], pred[oof.fold == f]) for f in sorted(oof.fold.unique())]
    p_threat = P[:, [classes.index(c) for c in config.THREAT_CLASSES]].sum(1)
    is_t = np.isin(y, config.THREAT_CLASSES)
    cm = confusion_matrix(y, pred, labels=classes)
    per_class = pd.DataFrame({"class": classes,
                              "recall": cm.diagonal() / cm.sum(1),
                              "group": [config.CLASS_TO_GROUP[c] for c in classes]})
    res = {"evidence": "REAL", "backend": tag, "n_clips": int(len(y)), "n_classes": len(classes),
           "accuracy_mean": round(float(np.mean(per_fold)), 4), "accuracy_std": round(float(np.std(per_fold)), 4),
           "accuracy_per_fold": [round(a, 4) for a in per_fold],
           "macro_f1": round(float(f1_score(y, pred, average="macro")), 4),
           "threat_vs_natural": binary_metrics(is_t, p_threat >= 0.5, p_threat),
           "timing_ms_per_5s_clip": {k: round(v, 3) for k, v in timing.items()}}
    pd.DataFrame(cm, index=classes, columns=classes).to_csv(config.RESULTS_DIR / f"audio_confusion_{tag}.csv")
    per_class.to_csv(config.RESULTS_DIR / f"audio_per_class_{tag}.csv", index=False)
    # which natural classes are most often mistaken for threats (false-alarm sources)
    nat = ~is_t
    fa = pd.Series(y[nat & (p_threat >= 0.5)]).value_counts()
    res["false_alarm_sources"] = {k: int(v) for k, v in fa.items()}
    return res


# --------------------------------------------- window level (SIMULATED)
def window_dataset(df, oof, hints, models, params, key="test") -> pd.DataFrame:
    rows = []
    oof_i = oof.set_index("filename")
    for fn, cat, fold in zip(df["filename"], df["category"], df["fold"]):
        obs, ex = pipeline.make_observation(0, 0.0, fn, cat, oof_i.loc[fn], hints[fn], models[fold], params, key)
        fr = fuse_window(obs.group_probs(), obs.p_threat(), obs.vib_family, obs.vib_family_conf,
                         models[fold].lik, audio_f0=obs.audio_f0, vib_dom_freq=obs.vib_dom_freq,
                         vib_tonality=obs.vib_tonality)
        rows.append({"filename": fn, "category": cat, "fold": fold, "threat": config.is_threat(cat),
                     "p_audio": obs.p_threat(), "p_vib": ex["p_vib_threat"], "missing": not obs.vib_available,
                     "vib_family": obs.vib_family, "true_family": pipeline.family_of(ex["vib_meta"]),
                     "p_fused": fr.p_fused, "vib_ms": ex["vib_ms"]})
    return pd.DataFrame(rows)


def window_experiment(wd: pd.DataFrame) -> dict:
    y = wd["threat"].to_numpy()
    pa, pv, miss = wd["p_audio"].to_numpy(), wd["p_vib"].to_numpy(), wd["missing"].to_numpy()
    late = np.zeros(len(wd))
    for f in sorted(wd.fold.unique()):  # learned late fusion, fold-wise
        tr, te = wd.fold.to_numpy() != f, wd.fold.to_numpy() == f
        m = LateFusionLR().fit(pa[tr], np.nan_to_num(pv[tr], nan=0.5), miss[tr], y[tr])
        late[te] = m.predict_proba(pa[te], np.nan_to_num(pv[te], nan=0.5), miss[te])
    methods = {
        "audio_only": (pa >= 0.5, pa),
        "vibration_only": (np.where(miss, False, pv >= 0.5), np.where(miss, 0.5, pv)),
        "AND_rule": (rule_and(pa, pv, miss), None),
        "OR_rule": (rule_or(pa, pv, miss), None),
        "learned_late_fusion": (late >= 0.5, late),
        "bayesian_evidence_fusion": (wd["p_fused"].to_numpy() >= 0.5, wd["p_fused"].to_numpy()),
    }
    out = {"evidence": "SIMULATED", "n_windows": int(len(wd)),
           "vibration_missing_rate": round(float(miss.mean()), 4), "methods": {}}
    for k, (yhat, s) in methods.items():
        out["methods"][k] = binary_metrics(y, yhat, s)
    # false-alarm breakdown on natural classes, audio-only vs fusion
    nat = ~y
    out["false_alarms_by_class"] = {
        "audio_only": wd.loc[nat & (pa >= 0.5), "category"].value_counts().to_dict(),
        "bayesian_evidence_fusion": wd.loc[nat & (wd.p_fused >= 0.5), "category"].value_counts().to_dict()}
    av = ~miss
    fam_acc = float((wd.loc[av, "vib_family"] == wd.loc[av, "true_family"]).mean())
    out["vibration_family_accuracy"] = round(fam_acc, 4)
    return out


# --------------------------------------------- episodes (SIMULATED)
AGENT_VARIANTS = {
    "agent_full": AgentConfig(),
    # first design, kept for transparency (separate counts for footsteps and
    # voices; corroboration demanded for every type)
    "agent_v1": AgentConfig(merge_human=False, expectation_aware_bar=False),
    # low-false-alarm operating point found during selection on the dev draw
    "agent_conservative": AgentConfig(merge_human=True, expectation_aware_bar=False),
    "agent_always_vibration": AgentConfig(vib_policy="always"),
    "agent_no_vibration": AgentConfig(vib_policy="never"),
    # fairer ablation: without vibration, corroboration is impossible, so do
    # not also demand the extra persistence window
    "agent_no_vibration_k2": AgentConfig(vib_policy="never", missing_extra_k=0),
    "agent_no_context": AgentConfig(use_context=False),
}


def build_episode_observations(df, oof, hints, models, params, n_per_type, tag="ep", seed=None):
    seed = config.EPISODE_SEED if seed is None else seed
    oof_i = oof.set_index("filename")
    out = []
    for f in sorted(df["fold"].unique()):
        for e_i, ep in enumerate(pipeline.build_episodes(df, f, n_per_type, seed=seed)):
            obs_list = []
            for w, (fn, cat) in enumerate(zip(ep["files"], ep["categories"])):
                obs, ex = pipeline.make_observation(w, 5.0 * w, fn, cat, oof_i.loc[fn], hints[fn],
                                                    models[f], params, f"{tag}{f}-{e_i}-{w}")
                obs_list.append((obs, ex))
            out.append((ep, obs_list))
    return out


def run_episode_methods(episodes, models, variants=None) -> pd.DataFrame:
    variants = AGENT_VARIANTS if variants is None else variants
    first = next(iter(variants))
    rows = []
    for ep, obs_list in episodes:
        f = ep["fold"]
        first_t = 5.0 * min(ep["threat_windows"]) if ep["threat"] else None
        res = {}
        # stateless baselines
        pa = np.array([o.p_threat() for o, _ in obs_list])
        fused = np.array([fuse_window(o.group_probs(), o.p_threat(), o.vib_family, o.vib_family_conf,
                                      models[f].lik, o.audio_f0, o.vib_dom_freq, o.vib_tonality).p_fused
                          for o, _ in obs_list])
        for name, hits in (("audio_any_window", pa >= 0.5), ("fused_any_window", fused >= 0.5)):
            idx = np.flatnonzero(hits)
            res[name] = (len(idx) > 0, int(len(idx)), 5.0 * idx[0] if len(idx) else None, 1.0 if "fused" in name else 0.0)
        # audio + persistence only (2 suspicious windows within 30 s, no vibration)
        cnt, alert_t, n_alerts, last = 0, None, 0, -99
        for i, p in enumerate(pa):
            recent = [j for j in range(max(0, i - 5), i + 1) if pa[j] >= 0.5]
            if p >= 0.5 and len(recent) >= 2 and i - last > 5:
                n_alerts += 1; last = i
                alert_t = alert_t if alert_t is not None else 5.0 * i
        res["audio_persistence"] = (n_alerts > 0, n_alerts, alert_t, 0.0)
        for name, cfg in variants.items():
            ag = ForestGuardAgent(models[f].lik, cfg)
            t0 = time.perf_counter()
            for o, _ in obs_list:
                ag.step(o)
            ms = 1000 * (time.perf_counter() - t0) / len(obs_list)
            t_alert = ag.alerts[0]["t_start"] if ag.alerts else None
            res[name] = (len(ag.alerts) > 0, len(ag.alerts), t_alert, ag.summary()["vibration_duty_cycle"])
            if name == first:
                agent_ms = ms
                types = [a["threat_type"] for a in ag.alerts]
        for name, (alerted, n, t, duty) in res.items():
            rows.append({"method": name, "fold": f, "kind": ep["kind"], "threat": ep["threat"],
                         "alerted": alerted, "n_alerts": n,
                         "ttd_s": (t - first_t) if (alerted and ep["threat"] and t is not None) else np.nan,
                         "early_alert": bool(alerted and ep["threat"] and t is not None and t < first_t),
                         "vib_duty": duty, "agent_ms": agent_ms if name == first else np.nan,
                         "alert_types": ",".join(types) if name == first else ""})
    return pd.DataFrame(rows)


def summarize_episodes(er: pd.DataFrame) -> pd.DataFrame:
    out = []
    for m, g in er.groupby("method", sort=False):
        b = binary_metrics(g["threat"], g["alerted"])
        benign = g[~g["threat"]]
        hours = len(benign) * pipeline.EP_WINDOWS * 5 / 3600
        out.append({"method": m, "evidence": "SIMULATED", "episodes": len(g), **b,
                    "false_alerts_per_benign_hour": round(benign["n_alerts"].sum() / hours, 2),
                    "median_time_to_detect_s": float(np.nanmedian(g["ttd_s"])) if g["ttd_s"].notna().any() else np.nan,
                    "vibration_duty_cycle": round(float(g["vib_duty"].mean()), 3)})
    return pd.DataFrame(out)


def per_kind(er: pd.DataFrame) -> pd.DataFrame:
    return (er.groupby(["method", "kind"])["alerted"].mean().unstack("kind").round(3))


def sweep(df, oof, hints, base: vs.SimParams, field: str, values, n_per_type=8) -> pd.DataFrame:
    rows = []
    for v in values:
        p = vs.SimParams(**{**asdict(base), field: v})
        models, _ = pipeline.train_vibration_models(df, hints, p, n_real=2)
        eps = build_episode_observations(df, oof, hints, models, p, n_per_type, tag=f"sw{field}{v}")
        s = summarize_episodes(run_episode_methods(eps, models))
        s.insert(0, field, v)
        rows.append(s)
        log.info("sweep %s=%s done", field, v)
    return pd.concat(rows, ignore_index=True)
