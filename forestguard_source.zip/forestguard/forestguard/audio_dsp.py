"""Acoustic signal processing: loading, filtering, segmentation, spectrograms,
hand-crafted features and cross-modal descriptors (onset cadence, low
fundamental frequency) that the fusion stage compares against vibration.
"""
from __future__ import annotations

from dataclasses import dataclass

import librosa
import numpy as np
from scipy import signal as sps

from . import config

N_MELS = 64
N_FFT = 1024
HOP = 256  # 16 ms at 16 kHz


def load_audio(path: str, sr: int = config.AUDIO_SR) -> np.ndarray:
    y, _ = librosa.load(path, sr=sr, mono=True)
    if y.size == 0:
        raise ValueError(f"Empty audio file: {path}")
    return y.astype(np.float32)


def highpass(y: np.ndarray, sr: int = config.AUDIO_SR,
             cutoff: float = config.HIGHPASS_HZ, order: int = 4) -> np.ndarray:
    """Zero-phase Butterworth high-pass; removes wind and handling rumble."""
    sos = sps.butter(order, cutoff, btype="highpass", fs=sr, output="sos")
    return sps.sosfiltfilt(sos, y).astype(np.float32)


def spectral_gate(y: np.ndarray, sr: int = config.AUDIO_SR,
                  noise_quantile: float = 0.15, strength: float = 1.5) -> np.ndarray:
    """Stationary-noise suppression: estimate a per-frequency noise floor from
    the quietest frames and attenuate bins that do not rise above it."""
    S = librosa.stft(y, n_fft=N_FFT, hop_length=HOP)
    mag, phase = np.abs(S), np.angle(S)
    frame_energy = mag.sum(axis=0)
    quiet = frame_energy <= np.quantile(frame_energy, noise_quantile)
    if quiet.sum() < 2:
        return y
    noise = mag[:, quiet].mean(axis=1, keepdims=True)
    mask = np.clip((mag - strength * noise) / (mag + 1e-10), 0.0, 1.0)
    out = librosa.istft(mask * mag * np.exp(1j * phase), hop_length=HOP, length=len(y))
    return out.astype(np.float32)


def preprocess(y: np.ndarray, sr: int = config.AUDIO_SR, denoise: bool = True) -> np.ndarray:
    y = highpass(y, sr)
    if denoise:
        y = spectral_gate(y, sr)
    peak = np.max(np.abs(y))
    return y / peak if peak > 0 else y


def log_mel(y: np.ndarray, sr: int = config.AUDIO_SR) -> np.ndarray:
    M = librosa.feature.melspectrogram(y=y, sr=sr, n_fft=N_FFT, hop_length=HOP,
                                       n_mels=N_MELS, fmin=50, fmax=sr // 2)
    return librosa.power_to_db(M, ref=np.max)


@dataclass
class Segment:
    start_s: float
    end_s: float
    peak_rms: float


def segment_activity(y: np.ndarray, sr: int = config.AUDIO_SR,
                     rise_db: float = 10.0, min_dur: float = 0.05,
                     merge_gap: float = 0.15) -> list[Segment]:
    """Energy-based event segmentation with an adaptive threshold: a frame is
    active when its RMS exceeds the clip's own noise floor (10th percentile
    of frame dB) by `rise_db`. The threshold therefore follows the ambient
    level instead of being a fixed loudness value; a continuous source
    (engine) becomes one long segment, footsteps become many short ones."""
    rms = librosa.feature.rms(y=y, frame_length=N_FFT, hop_length=HOP)[0]
    db = 20 * np.log10(rms + 1e-8)
    active = db > np.percentile(db, 10) + rise_db
    times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=HOP)
    segs: list[Segment] = []
    start = None
    for i, a in enumerate(active):
        if a and start is None:
            start = i
        if (not a or i == len(active) - 1) and start is not None:
            end = i if not a else i + 1
            segs.append(Segment(float(times[start]), float(times[min(end, len(times) - 1)]),
                                float(rms[start:end].max())))
            start = None
    merged: list[Segment] = []
    for s in segs:
        if merged and s.start_s - merged[-1].end_s < merge_gap:
            merged[-1] = Segment(merged[-1].start_s, s.end_s, max(merged[-1].peak_rms, s.peak_rms))
        else:
            merged.append(s)
    return [s for s in merged if s.end_s - s.start_s >= min_dur]


def onset_times(y: np.ndarray, sr: int = config.AUDIO_SR) -> np.ndarray:
    env = librosa.onset.onset_strength(y=y, sr=sr, hop_length=HOP)
    frames = librosa.onset.onset_detect(onset_envelope=env, sr=sr, hop_length=HOP,
                                        backtrack=False, units="frames")
    return librosa.frames_to_time(frames, sr=sr, hop_length=HOP)


def onset_cadence_hz(y: np.ndarray, sr: int = config.AUDIO_SR,
                     fmin: float = 0.5, fmax: float = 4.0) -> tuple[float, float]:
    """Dominant repetition rate of the onset envelope (e.g. step cadence) and
    its autocorrelation strength in [0, 1]."""
    env = librosa.onset.onset_strength(y=y, sr=sr, hop_length=HOP)
    env = env - env.mean()
    if np.allclose(env, 0):
        return 0.0, 0.0
    ac = np.correlate(env, env, mode="full")[len(env) - 1:]
    ac /= ac[0] + 1e-10
    fps = sr / HOP
    lo, hi = int(fps / fmax), int(fps / fmin)
    hi = min(hi, len(ac) - 1)
    if hi <= lo:
        return 0.0, 0.0
    lag = lo + int(np.argmax(ac[lo:hi]))
    return float(fps / lag), float(max(ac[lag], 0.0))


def low_fundamental_hz(y: np.ndarray, sr: int = config.AUDIO_SR,
                       fmin: float = 20.0, fmax: float = 250.0) -> tuple[float, float]:
    """Harmonic-product-spectrum estimate of a low fundamental (engine firing
    frequency, saw stroke harmonics). Returns (f0, tonality) where tonality is
    the peak-to-median ratio of the HPS, squashed to [0, 1]."""
    n = 1 << 15
    seg = y[: min(len(y), n)] * np.hanning(min(len(y), n))
    spec = np.abs(np.fft.rfft(seg, n=n))
    freqs = np.fft.rfftfreq(n, 1 / sr)
    hps = spec.copy()
    for h in (2, 3, 4):
        dec = spec[::h]
        hps[: len(dec)] *= dec
    band = (freqs >= fmin) & (freqs <= fmax)
    if not band.any():
        return 0.0, 0.0
    b = hps[band]
    idx = int(np.argmax(b))
    if idx in (0, len(b) - 1):          # peak on the band edge: no real fundamental
        return 0.0, 0.0
    ratio = b[idx] / (np.median(b) + 1e-20)
    tonality = float(1 - np.exp(-np.log10(ratio + 1) / 4))
    return float(freqs[band][idx]), tonality


def handcrafted_features(y: np.ndarray, sr: int = config.AUDIO_SR) -> np.ndarray:
    """Clip-level feature vector for the classical baseline backend:
    log-mel mean/std (128), MFCC + delta mean/std (80), spectral shape
    statistics (14), onset/periodicity descriptors (4). Total 226 dims."""
    lm = log_mel(y, sr)
    mfcc = librosa.feature.mfcc(S=lm, n_mfcc=20)
    d1 = librosa.feature.delta(mfcc)
    S = np.abs(librosa.stft(y, n_fft=N_FFT, hop_length=HOP))
    cen = librosa.feature.spectral_centroid(S=S, sr=sr)[0]
    bw = librosa.feature.spectral_bandwidth(S=S, sr=sr)[0]
    roll = librosa.feature.spectral_rolloff(S=S, sr=sr)[0]
    flat = librosa.feature.spectral_flatness(S=S)[0]
    zcr = librosa.feature.zero_crossing_rate(y, frame_length=N_FFT, hop_length=HOP)[0]
    rms = librosa.feature.rms(S=S, frame_length=N_FFT)[0]
    contrast = librosa.feature.spectral_contrast(S=S, sr=sr).mean(axis=1)  # 7
    shape = np.array([cen.mean() / sr, cen.std() / sr, bw.mean() / sr, roll.mean() / sr,
                      flat.mean(), zcr.mean(), np.log(rms.std() / (rms.mean() + 1e-8) + 1e-8)])
    cad, cad_s = onset_cadence_hz(y, sr)
    f0, ton = low_fundamental_hz(y, sr)
    peri = np.array([cad / 4.0, cad_s, f0 / 250.0, ton])
    return np.concatenate([lm.mean(1), lm.std(1), mfcc.mean(1), mfcc.std(1),
                           d1.mean(1), d1.std(1), shape, contrast / 50.0, peri]).astype(np.float32)
