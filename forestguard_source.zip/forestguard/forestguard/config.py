"""Central configuration: paths, seeds, sample rates and the event taxonomy.

The taxonomy below uses ESC-50 category names exactly as they appear in
meta/esc50.csv (verified by inspecting the file, 50 classes x 40 clips,
official folds 1-5).
"""
from __future__ import annotations

import os
from pathlib import Path

# ---------------------------------------------------------------- paths
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = Path(os.environ.get("FG_DATA_ROOT", PROJECT_ROOT / "data"))
ESC50_ROOT = Path(os.environ.get("FG_ESC50_ROOT", DATA_ROOT / "ESC-50"))
FSC22_ROOT = Path(os.environ.get("FG_FSC22_ROOT", DATA_ROOT / "FSC22"))
RESULTS_DIR = Path(os.environ.get("FG_RESULTS_DIR", PROJECT_ROOT / "results"))
CACHE_DIR = Path(os.environ.get("FG_CACHE_DIR", PROJECT_ROOT / "cache"))
VIB_DIR = RESULTS_DIR / "vibration_csv"

# ---------------------------------------------------------------- signal
SEED = 42
# Episodes are drawn with a separate seed. Seed 42 was used during development
# (agent v1 failure analysis); every reported episode result uses this fresh draw.
EPISODE_SEED = 2026
AUDIO_SR = 16_000          # YAMNet expects 16 kHz mono; we use it for every backend
VIB_SR = 500               # simulated geophone sample rate (Hz); Nyquist 250 Hz
CLIP_SECONDS = 5.0         # ESC-50 clip length (verified)
HIGHPASS_HZ = 80.0         # removes wind/handling rumble from the microphone channel

# ---------------------------------------------------------------- taxonomy
# Forest-relevant subset of ESC-50. Domestic classes (vacuum cleaner,
# keyboard typing, toilet flush, ...) are excluded because they cannot occur
# in a forest deployment and would inflate or distort the benchmark.
THREAT_GROUPS: dict[str, list[str]] = {
    "logging": ["chainsaw", "hand_saw"],
    "vehicle": ["engine", "helicopter"],
    "human_movement": ["footsteps"],
    "human_voice": ["laughing", "coughing"],
    # ESC-50 has no gunshot class. Fireworks is the closest impulsive
    # explosive sound and is used ONLY as a labelled proxy.
    "firearm_proxy": ["fireworks"],
}
NATURAL_GROUPS: dict[str, list[str]] = {
    "weather": ["thunderstorm", "rain", "wind"],
    "fire_water": ["crackling_fire", "water_drops"],
    "large_animal": ["cow", "pig", "sheep", "dog"],
    "wildlife": ["chirping_birds", "insects", "crickets", "frog", "crow"],
}

CLASS_TO_GROUP: dict[str, str] = {}
for _g, _cs in {**THREAT_GROUPS, **NATURAL_GROUPS}.items():
    for _c in _cs:
        CLASS_TO_GROUP[_c] = _g

FOREST_CLASSES: list[str] = sorted(CLASS_TO_GROUP)
THREAT_CLASSES: list[str] = sorted(c for g in THREAT_GROUPS.values() for c in g)
NATURAL_CLASSES: list[str] = sorted(c for g in NATURAL_GROUPS.values() for c in g)


def is_threat(category: str) -> bool:
    return category in THREAT_CLASSES


def ensure_dirs() -> None:
    for d in (RESULTS_DIR, CACHE_DIR, VIB_DIR):
        d.mkdir(parents=True, exist_ok=True)
