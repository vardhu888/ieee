"""SIMULATED ground-vibration generator.

Everything produced here is synthetic and labelled as such (``simulated``
column = True, ``# SIMULATED`` header in every CSV). It exists because no
paired acoustic-seismic forest dataset was available; it must never be
presented as real sensor evidence.

Physical model (vertical-velocity geophone, fs = 500 Hz)
-------------------------------------------------------
received(f) = source(f) * G(r) * exp(-pi f r / (Q v)) * H_geophone(f) + noise

* G(r) = sqrt(r0 / r): geometric spreading of surface (Rayleigh) waves.
* exp(-pi f r / (Q v)): anelastic absorption, Q = 20, v = 200 m/s (loose
  forest soil, order-of-magnitude values) -> high frequencies die first.
* H_geophone: 2nd-order high-pass at 4.5 Hz (a common geophone corner).
* noise: sensor self-noise (white) + ambient low-frequency ground noise.

Design choices that prevent a trivially separable (circular) simulation:
1. Natural sources also produce vibration: thunder rumble, wind-rocked
   roots, rain impacts, livestock and dog gait (cadence overlaps humans).
2. Source distance is random (3-60 m), so distant threats can be
   undetectable in vibration and nearby animals can be loud.
3. Unrelated background animals walk past with probability p_bg_animal,
   independently of the audio label.
4. Sensor faults: mains-hum artifact (50 Hz, India grid) and dropout.
5. Where measurable, timing/frequency parameters are taken from the REAL
   audio clip (footstep onset times, engine/saw fundamental), so the two
   modalities share a physical source rather than a label.
"""
from __future__ import annotations

import zlib
from dataclasses import asdict, dataclass, field

import numpy as np
import pandas as pd
from scipy import signal as sps

from . import config

Q_FACTOR = 20.0
WAVE_SPEED = 200.0
R0 = 5.0
GEOPHONE_CORNER = 4.5


@dataclass
class SimParams:
    snr_scale: float = 1.0        # multiplies every source amplitude (sensor quality / coupling)
    dropout_p: float = 0.05       # probability the vibration channel is missing for a window
    bg_animal_p: float = 0.15     # unrelated animal walking past
    hum_p: float = 0.05           # 50 Hz mains-hum artifact
    noise_rms: float = 0.05       # sensor self-noise
    dist_range: tuple[float, float] = (3.0, 60.0)


@dataclass
class VibrationWindow:
    filename: str
    category: str
    available: bool
    signal: np.ndarray | None
    meta: dict = field(default_factory=dict)


def _rng(*keys) -> np.random.Generator:
    return np.random.default_rng(zlib.crc32("|".join(map(str, keys)).encode()))


def _propagate(x: np.ndarray, r: float, fs: int = config.VIB_SR) -> np.ndarray:
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / fs)
    gain = np.sqrt(R0 / max(r, 0.5)) * np.exp(-np.pi * f * r / (Q_FACTOR * WAVE_SPEED))
    return np.fft.irfft(X * gain, n=len(x))


def _geophone(x: np.ndarray, fs: int = config.VIB_SR) -> np.ndarray:
    sos = sps.butter(2, GEOPHONE_CORNER, btype="highpass", fs=fs, output="sos")
    return sps.sosfilt(sos, x)


def _impulse(n: int, fs: int, f_res: float, decay_s: float) -> np.ndarray:
    t = np.arange(n) / fs
    return np.sin(2 * np.pi * f_res * t) * np.exp(-t / decay_s)


def _add_impulses(x, times, amps, rng, fs, f_res=(15, 35), decay=(0.03, 0.06)):
    n_imp = int(0.4 * fs)
    for t0, a in zip(times, amps):
        i0 = int(t0 * fs)
        if i0 >= len(x):
            continue
        k = _impulse(n_imp, fs, rng.uniform(*f_res), rng.uniform(*decay))
        seg = min(n_imp, len(x) - i0)
        x[i0:i0 + seg] += a * k[:seg]
    return x


def _gait_times(rng, dur, cadence, jitter=0.06, doublet=None):
    t, out = rng.uniform(0, 1 / cadence), []
    while t < dur:
        out.append(t)
        if doublet is not None:
            out.append(t + doublet)
        t += (1 / cadence) * (1 + rng.normal(0, jitter))
    return np.array([x for x in out if x < dur])


def _harmonic(rng, n, fs, f0, n_harm=4, am_rate=(0.2, 1.0), am_depth=0.4):
    t = np.arange(n) / fs
    f0_t = f0 * (1 + 0.02 * np.sin(2 * np.pi * rng.uniform(0.05, 0.3) * t))  # slow RPM drift
    phase = 2 * np.pi * np.cumsum(f0_t) / fs
    x = sum(np.sin(h * phase + rng.uniform(0, 2 * np.pi)) / h
            for h in range(1, n_harm + 1) if h * f0 < fs / 2)
    am = 1 + am_depth * np.sin(2 * np.pi * rng.uniform(*am_rate) * t)
    return x * am


def _bandnoise(rng, n, fs, lo, hi):
    sos = sps.butter(4, [lo, hi], btype="bandpass", fs=fs, output="sos")
    return sps.sosfilt(sos, rng.normal(0, 1, n))


def _burst_env(rng, n, fs, n_bursts, dur=(0.5, 2.0)):
    t = np.arange(n) / fs
    env = np.zeros(n)
    for _ in range(n_bursts):
        c, w = rng.uniform(0, n / fs), rng.uniform(*dur)
        env += np.exp(-0.5 * ((t - c) / (w / 2.5)) ** 2)
    return env


def source_signal(category: str, rng: np.random.Generator, n: int, fs: int,
                  audio_hint: dict | None = None) -> tuple[np.ndarray, dict]:
    """Source waveform at the reference distance for one ESC-50 category.
    Returns (signal, info) where info records the parameters used."""
    hint = audio_hint or {}
    dur = n / fs
    x = np.zeros(n)
    info: dict = {"profile": "none"}
    group = config.CLASS_TO_GROUP.get(category, "")

    if category == "footsteps":
        on = np.asarray(hint.get("onsets", []))
        if len(on) >= 3:
            times, info["timing_source"] = on, "audio_onsets"
        else:
            cad = rng.uniform(1.6, 2.2)
            times, info["timing_source"] = _gait_times(rng, dur, cad), "random_gait"
        x = _add_impulses(x, times, rng.uniform(1.5, 2.5, len(times)), rng, fs)
        info.update(profile="biped_gait", n_impulses=int(len(times)))

    elif group == "large_animal":
        p_walk = {"cow": 0.7, "sheep": 0.6, "pig": 0.6, "dog": 0.5}[category]
        if rng.random() < p_walk:
            if category == "dog":
                cad, amp, dbl = rng.uniform(2.5, 4.0), (0.15, 0.4), None
            else:
                cad = rng.uniform(0.8, 1.6)
                amp = (2.0, 4.0) if category == "cow" else (0.6, 1.5)
                dbl = rng.uniform(0.10, 0.25)
            times = _gait_times(rng, dur, cad, jitter=0.08, doublet=dbl)
            x = _add_impulses(x, times, rng.uniform(*amp, len(times)), rng, fs, f_res=(10, 25))
            info.update(profile="quadruped_gait" if dbl else "light_gait", cadence_hz=round(cad, 2))
        else:
            info.update(profile="animal_stationary")

    elif category == "engine":
        f0 = hint.get("f0", 0.0)
        f0 = f0 if 15 <= f0 <= 120 else rng.uniform(20, 60)
        x = rng.uniform(2.0, 5.0) * _harmonic(rng, n, fs, f0) + 0.5 * _bandnoise(rng, n, fs, 5, 40)
        info.update(profile="machinery_vehicle", f0_hz=round(f0, 1))

    elif category == "helicopter":
        f0 = rng.uniform(15, 30)
        x = rng.uniform(0.5, 1.5) * _harmonic(rng, n, fs, f0, n_harm=3)
        info.update(profile="machinery_airborne", f0_hz=round(f0, 1))

    elif category == "chainsaw":
        f0 = hint.get("f0", 0.0)
        f0 = f0 if 80 <= f0 <= 240 else rng.uniform(120, 200)
        x = rng.uniform(0.3, 1.0) * _harmonic(rng, n, fs, f0, n_harm=2, am_rate=(0.3, 1.5), am_depth=0.7)
        info.update(profile="machinery_handheld", f0_hz=round(f0, 1))
        if rng.random() < 0.3:  # felling: a large broadband impact
            x = _add_impulses(x, [rng.uniform(0.5, dur - 0.5)], [rng.uniform(3, 6)], rng, fs,
                              f_res=(8, 20), decay=(0.1, 0.2))
            info["tree_fall"] = True

    elif category == "hand_saw":
        rate = rng.uniform(1.0, 2.0)
        env = (np.sin(2 * np.pi * rate * np.arange(n) / fs) > 0.2).astype(float)
        x = rng.uniform(0.2, 0.5) * env * _bandnoise(rng, n, fs, 30, 120)
        info.update(profile="periodic_stroke", stroke_hz=round(rate, 2))

    elif category == "fireworks":
        k = int(rng.integers(1, 4))
        times = np.sort(rng.uniform(0.2, dur - 0.3, k))
        x = _add_impulses(x, times, rng.uniform(0.5, 2.0, k), rng, fs, f_res=(20, 80), decay=(0.01, 0.03))
        info.update(profile="blast_transient", n_impulses=k)

    elif group == "human_voice":
        if rng.random() < 0.25:  # speaker shifting / walking a few steps
            times = _gait_times(rng, dur, rng.uniform(1.6, 2.2))[: int(rng.integers(1, 4))]
            x = _add_impulses(x, times, rng.uniform(0.5, 1.0, len(times)), rng, fs)
            info.update(profile="incidental_steps", n_impulses=int(len(times)))
        else:
            info.update(profile="no_ground_coupling")

    elif category == "thunderstorm":
        x = rng.uniform(2.0, 6.0) * _burst_env(rng, n, fs, int(rng.integers(1, 3))) * _bandnoise(rng, n, fs, 2, 30)
        info.update(profile="weather_rumble")

    elif category == "rain":
        k = rng.poisson(rng.uniform(50, 200) * dur)
        times = rng.uniform(0, dur, k)
        x = _add_impulses(x, times, rng.uniform(0.02, 0.06, k), rng, fs, f_res=(40, 120), decay=(0.005, 0.01))
        info.update(profile="rain_impacts")

    elif category == "wind":
        gust = 1 + _burst_env(rng, n, fs, int(rng.integers(1, 4)), dur=(1.0, 3.0))
        x = rng.uniform(0.2, 1.0) * gust * _bandnoise(rng, n, fs, 1, 8)
        info.update(profile="root_sway")

    return x, info


def simulate_window(filename: str, category: str, params: SimParams | None = None,
                    audio_hint: dict | None = None, scenario_key: str = "",
                    fs: int = config.VIB_SR, seconds: float = config.CLIP_SECONDS) -> VibrationWindow:
    """One 5-second SIMULATED geophone window for one audio clip."""
    p = params or SimParams()
    rng = _rng(config.SEED, filename, scenario_key, p.snr_scale, p.dropout_p)
    n = int(fs * seconds)
    meta = {"simulated": True, "snr_scale": p.snr_scale}
    if rng.random() < p.dropout_p:
        meta.update(dropout=True)
        return VibrationWindow(filename, category, False, None, meta)

    src, info = source_signal(category, rng, n, fs, audio_hint)
    r = rng.uniform(*p.dist_range)
    x = _propagate(src, r, fs) * p.snr_scale
    meta.update(info, distance_m=round(r, 1), dropout=False)

    if rng.random() < p.bg_animal_p:
        cad = rng.uniform(0.8, 2.4)
        bg = _add_impulses(np.zeros(n), _gait_times(rng, seconds, cad, 0.08),
                           rng.uniform(0.5, 2.5, int(cad * seconds) + 2), rng, fs, f_res=(10, 30))
        x += _propagate(bg, rng.uniform(5, 40), fs) * p.snr_scale
        meta["bg_animal"] = True
    if rng.random() < p.hum_p:
        x += rng.uniform(0.05, 0.2) * np.sin(2 * np.pi * 50 * np.arange(n) / fs)
        meta["mains_hum"] = True

    ambient = 0.03 * _bandnoise(rng, n, fs, 1, 20)
    x = _geophone(x + ambient, fs) + rng.normal(0, p.noise_rms, n)
    return VibrationWindow(filename, category, True, x.astype(np.float32), meta)


def audio_hint_from_clip(y: np.ndarray, sr: int) -> dict:
    """Physical parameters measured on the REAL audio clip that the
    simulator reuses (footstep onset times, low fundamental)."""
    from . import audio_dsp
    f0, ton = audio_dsp.low_fundamental_hz(y, sr)
    return {"onsets": audio_dsp.onset_times(y, sr).tolist(), "f0": f0 if ton > 0.3 else 0.0}


def to_csv(win: VibrationWindow, path, fs: int = config.VIB_SR) -> None:
    """Export one window as a structured CSV with a SIMULATED header."""
    with open(path, "w") as f:
        f.write("# SIMULATED geophone signal - not real sensor data\n")
        f.write(f"# source_clip={win.filename} category={win.category} "
                + " ".join(f"{k}={v}" for k, v in win.meta.items()) + "\n")
        if not win.available:
            f.write("time_s,velocity,simulated\n")
            return
        t = np.arange(len(win.signal)) / fs
        pd.DataFrame({"time_s": np.round(t, 4), "velocity": win.signal,
                      "simulated": True}).to_csv(f, index=False)


def params_dict(p: SimParams) -> dict:
    return asdict(p)
