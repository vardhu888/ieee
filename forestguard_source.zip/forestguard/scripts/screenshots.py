"""Capture dashboard screenshots with headless Chrome (Playwright).
Start the dashboard first:  streamlit run app/dashboard.py --server.headless true
Then:                       python scripts/screenshots.py [--url http://localhost:8501]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "submission" / "screenshots"
TABS = ["Live monitor", "Signals & sensor correlation", "Agent decisions & audit log", "Experiments",
        "System & deployment"]


def wait_ready(page, timeout=90_000):
    page.wait_for_selector("text=FORESTGUARD AI", timeout=timeout)
    page.wait_for_function("() => !document.querySelector('[data-testid=\"stStatusWidget\"]') || "
                           "!document.querySelector('[data-testid=\"stStatusWidget\"]').innerText.includes('Running')",
                           timeout=timeout)
    page.wait_for_timeout(2500)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8501")
    a = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path="/usr/bin/google-chrome", headless=True,
                              args=["--no-sandbox"]) if Path("/usr/bin/google-chrome").exists() else p.chromium.launch()
        page = b.new_page(viewport={"width": 1600, "height": 1000}, device_scale_factor=1)
        page.goto(a.url)
        wait_ready(page)
        for i, t in enumerate(TABS):
            page.get_by_role("tab", name=t).click()
            page.wait_for_timeout(3500)
            if t == "Agent decisions & audit log":
                exp = page.locator("[data-testid='stExpander'] summary")
                for j in range(min(exp.count(), 12)):
                    if "ESCALATE" in exp.nth(j).inner_text():
                        exp.nth(j).click()
                        page.wait_for_timeout(800)
                        break
            name = OUT / f"{i + 1:02d}_{t.split(' ')[0].lower()}.png"
            page.screenshot(path=str(name), full_page=True)
            print("saved", name)
        b.close()


if __name__ == "__main__":
    sys.exit(main())
