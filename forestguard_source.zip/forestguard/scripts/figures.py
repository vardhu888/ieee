"""Static figures for the report and slides (matplotlib, PNG, 160 dpi).
Palette: validated reference categorical slots 1-3 and a single-hue blue
ramp for magnitudes; text in ink tokens, never series colours."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
S1, S2, S3 = "#2a78d6", "#eb6834", "#1baf7a"
BLUES = LinearSegmentedColormap.from_list("blues", ["#fcfcfb", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"])

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "text.color": INK, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
    "axes.spines.top": False, "axes.spines.right": False, "font.size": 10,
    "axes.titlesize": 12, "axes.titleweight": "bold", "axes.titlelocation": "left",
    "lines.linewidth": 2, "legend.frameon": False,
})

NICE = {"audio_any_window": "Audio, any window", "fused_any_window": "Fusion, any window",
        "audio_persistence": "Audio + persistence", "agent_full": "Agent (full, sensitive mode)", "agent_v1": "Agent v1 (first design)",
        "agent_conservative": "Agent, conservative mode",
        "agent_always_vibration": "Agent, vibration always on", "agent_no_vibration": "Agent, no vibration",
        "agent_no_vibration_k2": "Agent, no vibration (k=2)", "agent_no_context": "Agent, no context rule",
        "audio_only": "Audio only", "vibration_only": "Vibration only", "AND_rule": "AND rule",
        "OR_rule": "OR rule", "learned_late_fusion": "Learned late fusion",
        "bayesian_evidence_fusion": "Bayesian evidence fusion"}


def _tag(ax, text):
    """Evidence tag in the figure's bottom-right corner (clear of the title)."""
    ax.figure.text(0.99, 0.005, text, ha="right", va="bottom", fontsize=8, color=INK2, fontweight="bold")


def audio_confusion(R: Path, out: Path, tag="handcrafted"):
    p = R / f"audio_confusion_{tag}.csv"
    if not p.exists():
        return
    cm = pd.read_csv(p, index_col=0)
    norm = cm.div(cm.sum(1), axis=0)
    fig, ax = plt.subplots(figsize=(9, 8))
    im = ax.imshow(norm.values, cmap=BLUES, vmin=0, vmax=1)
    ax.set_xticks(range(len(cm)), cm.columns, rotation=90, fontsize=8)
    ax.set_yticks(range(len(cm)), cm.index, fontsize=8)
    ax.grid(False)
    ax.set_xlabel("Predicted class"); ax.set_ylabel("True class")
    ax.set_title(f"Audio classifier confusion (row-normalised), {tag}")
    _tag(ax, "REAL · ESC-50 5-fold OOF")
    fig.colorbar(im, ax=ax, fraction=0.04, label="share of true-class clips")
    fig.tight_layout(); fig.savefig(out / f"audio_confusion_{tag}.png", dpi=160); plt.close(fig)


def window_methods(S: dict, out: Path):
    m = S["window_level"]["methods"]
    names = list(m)
    y = np.arange(len(names))
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.barh(y - 0.2, [m[k]["f1"] for k in names], 0.36, color=S1, label="F1", edgecolor=SURFACE, linewidth=2)
    ax.barh(y + 0.2, [m[k]["fpr"] for k in names], 0.36, color=S2, label="False-positive rate", edgecolor=SURFACE, linewidth=2)
    for i, k in enumerate(names):
        ax.text(m[k]["f1"] + 0.01, i - 0.2, f"{m[k]['f1']:.3f}", va="center", fontsize=8, color=INK2)
        ax.text(m[k]["fpr"] + 0.01, i + 0.2, f"{m[k]['fpr']:.3f}", va="center", fontsize=8, color=INK2)
    ax.set_yticks(y, [NICE.get(k, k) for k in names]); ax.invert_yaxis()
    ax.set_xlim(0, 1.05); ax.grid(axis="y", visible=False)
    ax.set_title("Window-level threat detection (880 held-out windows)")
    _tag(ax, "SIMULATED vibration · real audio")
    ax.legend(loc="lower right")
    fig.tight_layout(); fig.savefig(out / "window_methods.png", dpi=160); plt.close(fig)


def episode_tradeoff(R: Path, out: Path):
    p = R / "episode_summary.csv"
    if not p.exists():
        return
    d = pd.read_csv(p)
    fig, ax = plt.subplots(figsize=(9, 6))
    x = d["false_alerts_per_benign_hour"].clip(lower=0.3)
    ax.scatter(x, d["recall"], s=70, color=S1, edgecolor=SURFACE, linewidth=2, zorder=3)
    from adjustText import adjust_text
    texts = [ax.text(xi, yi, NICE.get(k, k), fontsize=8, color=INK) for xi, yi, k in zip(x, d["recall"], d["method"])]
    adjust_text(texts, ax=ax, expand=(1.3, 1.6), arrowprops=dict(arrowstyle="-", color=INK2, lw=0.6))
    ax.set_xscale("log")
    ax.set_xlabel("False alerts per benign monitoring hour (log scale; 0 plotted at 0.3)")
    ax.set_ylabel("Episode recall (intrusions alerted)")
    ax.set_ylim(0.45, 1.02)
    ax.set_title("Alerting trade-off: 60-second monitoring episodes")
    _tag(ax, "SIMULATED episodes · held-out real audio")
    fig.tight_layout(); fig.savefig(out / "episode_tradeoff.png", dpi=160); plt.close(fig)


def detection_by_kind(R: Path, out: Path):
    p = R / "episode_detection_rate_by_kind.csv"
    if not p.exists():
        return
    d = pd.read_csv(p, index_col=0)
    order = ["calm", "storm", "livestock", "brief_presence", "foot_patrol", "vehicle_pass", "poaching", "logging"]
    d = d[[c for c in order if c in d.columns]]
    fig, ax = plt.subplots(figsize=(9, 4.6))
    im = ax.imshow(d.values, cmap=BLUES, vmin=0, vmax=1, aspect="auto")
    for i in range(d.shape[0]):
        for j in range(d.shape[1]):
            v = d.values[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=8, color="#fcfcfb" if v > 0.55 else INK)
    ax.set_xticks(range(d.shape[1]), d.columns, rotation=30, ha="right")
    ax.set_yticks(range(d.shape[0]), [NICE.get(k, k) for k in d.index])
    ax.grid(False)
    ax.axvline(2.5, color=INK, linewidth=1.5)
    ax.set_title("Share of episodes alerted (left of line: benign, should be 0)")
    _tag(ax, "SIMULATED")
    fig.colorbar(im, ax=ax, fraction=0.03)
    fig.tight_layout(); fig.savefig(out / "detection_by_kind.png", dpi=160); plt.close(fig)


def sweeps(R: Path, out: Path):
    for fname, field, xlabel in (("sweep_snr_scale.csv", "snr_scale", "Vibration signal scale (x default coupling)"),
                                 ("sweep_dropout.csv", "dropout_p", "Vibration dropout probability")):
        p = R / fname
        if not p.exists():
            continue
        d = pd.read_csv(p)
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        for col, (meth, color) in enumerate([("agent_full", S1), ("audio_persistence", S2), ("agent_no_vibration_k2", S3)]):
            g = d[d.method == meth].sort_values(field)
            axes[0].plot(g[field], g["recall"], color=color, marker="o", markersize=7, label=NICE[meth])
            axes[1].plot(g[field], g["fpr"], color=color, marker="o", markersize=7, label=NICE[meth])
        axes[0].set_title("Episode recall"); axes[1].set_title("Benign episodes alerted (FPR)")
        for ax in axes:
            ax.set_xlabel(xlabel); ax.set_ylim(0, 1.02)
            if field == "snr_scale":
                ax.set_xscale("log", base=2)
        axes[1].legend(loc="upper right", fontsize=8)
        _tag(axes[1], "SIMULATED sensitivity sweep")
        fig.tight_layout(); fig.savefig(out / f"{fname.replace('.csv', '.png')}", dpi=160); plt.close(fig)


def example_signals(out: Path):
    from forestguard import audio_dsp, config, data, vibration_dsp as vd, vibration_sim as vs
    df = data.load_esc50()
    rows = [df[df.category == c].iloc[3] for c in ("footsteps", "engine", "thunderstorm")]
    fig, axes = plt.subplots(3, 3, figsize=(13, 8))
    for i, r in enumerate(rows):
        y = audio_dsp.preprocess(audio_dsp.load_audio(r.path), denoise=False)
        lm = audio_dsp.log_mel(y)
        axes[i, 0].imshow(lm, origin="lower", aspect="auto", cmap=BLUES.reversed(), extent=[0, 5, 0, 64])
        axes[i, 0].set_title(f"{r.category}: log-mel spectrogram (real)", fontsize=10)
        axes[i, 0].set_ylabel("mel bin"); axes[i, 0].grid(False)
        for s in audio_dsp.segment_activity(y):
            axes[i, 0].axvspan(s.start_s, s.end_s, ymin=0.96, ymax=1, color=S2)
        h = vs.audio_hint_from_clip(audio_dsp.preprocess(audio_dsp.load_audio(r.path)), config.AUDIO_SR)
        w = vs.simulate_window(r.filename, r.category, vs.SimParams(dropout_p=0, bg_animal_p=0, hum_p=0),
                               audio_hint=h, scenario_key="figure")
        t = np.arange(len(w.signal)) / config.VIB_SR
        axes[i, 1].plot(t, w.signal, color=S1, linewidth=0.8)
        axes[i, 1].set_title(f"SIMULATED geophone ({w.meta.get('distance_m')} m, {w.meta.get('profile')})", fontsize=10)
        f, X = vd.fft_spectrum(w.signal)
        axes[i, 2].plot(f, X, color=S1, linewidth=1)
        feat = vd.analyse(w.signal)
        axes[i, 2].axvline(feat.dom_freq, color=S2, linewidth=1.5)
        axes[i, 2].set_title(f"FFT, dominant {feat.dom_freq:.1f} Hz", fontsize=10)
        axes[i, 2].set_xlim(0, 250)
    for ax in axes[-1]:
        ax.set_xlabel("time (s)" if ax is not axes[-1, 2] else "frequency (Hz)")
    axes[-1, 0].set_xlabel("time (s)")
    fig.suptitle("Orange marks: detected acoustic event segments / dominant vibration frequency",
                 fontsize=9, color=INK2, x=0.01, ha="left")
    fig.tight_layout(); fig.savefig(out / "example_signals.png", dpi=150); plt.close(fig)


def make_all(R: Path):
    out = R / "figures"
    out.mkdir(parents=True, exist_ok=True)
    S = json.loads((R / "results_summary.json").read_text())
    audio_confusion(R, out, S["run"]["backend"])
    window_methods(S, out)
    episode_tradeoff(R, out)
    detection_by_kind(R, out)
    sweeps(R, out)
    example_signals(out)


if __name__ == "__main__":
    from forestguard import config
    make_all(config.RESULTS_DIR)
