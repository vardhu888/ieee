"""Cross-dataset robustness test (REAL audio): train the audio head on all of
ESC-50, test on FSC22 clips whose classes map onto our taxonomy.

1. Download FSC22 (Kaggle: "FSC22 - Forest Sound Classification" dataset)
   and unzip it to data/FSC22 (or set FG_FSC22_ROOT).
2. python scripts/cross_dataset_fsc22.py --inspect   # see what is on disk first
3. python scripts/cross_dataset_fsc22.py [--backend yamnet]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from forestguard import audio_models, config, data  # noqa: E402
from forestguard.experiments import binary_metrics  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", default="handcrafted", choices=["handcrafted", "yamnet"])
    ap.add_argument("--inspect", action="store_true")
    a = ap.parse_args()
    if a.inspect:
        print(json.dumps(data.inspect_fsc22(), indent=2))
        return
    config.ensure_dirs()
    esc = data.load_esc50()
    fsc = data.load_fsc22()
    print("FSC22 mapped clips per class:\n", fsc["category"].value_counts().to_string())
    Xe, _ = audio_models.extract_features(esc, a.backend, denoise=False)
    Xf, _ = audio_models.extract_features(fsc, a.backend, denoise=False)
    model = audio_models.fit_full(esc, Xe)
    classes = list(model.classes_)
    P = model.predict_proba(Xf)
    pred = np.array(classes)[P.argmax(1)]
    p_threat = P[:, [classes.index(c) for c in config.THREAT_CLASSES]].sum(1)
    y_t = fsc["is_threat"].to_numpy()
    res = {"evidence": "REAL", "train": "ESC-50 (all folds)", "test": "FSC22 (mapped classes)",
           "backend": a.backend, "n_test": int(len(fsc)),
           "class_accuracy": round(float((pred == fsc["category"].to_numpy()).mean()), 4),
           "group_accuracy": round(float((np.vectorize(config.CLASS_TO_GROUP.get)(pred)
                                          == fsc["group"].to_numpy()).mean()), 4),
           "threat_vs_natural": binary_metrics(y_t, p_threat >= 0.5, p_threat)}
    out = config.RESULTS_DIR / f"cross_dataset_fsc22_{a.backend}.json"
    out.write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
