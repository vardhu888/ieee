"""Generate README.md, submission/PITCH_AND_QA.md and
submission/SUBMISSION_CHECKLIST.md from results/results_summary.json, so
every number in them comes from the results files."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from forestguard import config  # noqa: E402

S = json.loads((config.RESULTS_DIR / "results_summary.json").read_text())
A, AD, WL, EP = S["audio"], S["audio_ablation_denoise"], S["window_level"], S["episodes"]
em = {r["method"]: r for r in EP["summary"]}
full, cons, v1, nov = em["agent_full"], em["agent_conservative"], em["agent_v1"], em["agent_no_vibration_k2"]
aud, per, alw = em["audio_any_window"], em["audio_persistence"], em["agent_always_vibration"]
noctx = em["agent_no_context"]
K = EP["detection_rate_by_kind"]
SEL = S.get("agent_selection_dev", {})
selrow = {r["method"]: r for r in SEL.get("candidates", [])}
LAT = S["latency_ms_per_window"]
lat_total = sum(LAT[k] for k in ("audio_preprocess", "audio_features", "audio_head",
                                 "vibration_analysis_and_classifier", "fusion_and_agent"))
fa_ratio = nov["false_alerts_per_benign_hour"] / max(full["false_alerts_per_benign_hour"], 0.01)
def sw(field, v, m, k):
    return next(r[k] for r in S['sweeps'][field] if r[field] == v and r['method'] == m)


ctx_null = abs(full["recall"] - noctx["recall"]) + abs(full["fpr"] - noctx["fpr"]) < 0.01


def pct(x, d=1):
    return f"{100 * x:.{d}f}%"


NICE = {"audio_any_window": "Audio, alert on any window", "fused_any_window": "Fusion, alert on any window",
        "audio_persistence": "Audio + persistence", "agent_full": "**Agent, sensitive mode (selected)**",
        "agent_v1": "Agent v1 (first design)", "agent_conservative": "Agent, conservative mode",
        "agent_always_vibration": "Agent, vibration always on", "agent_no_vibration": "Agent, no vibration (k=3)",
        "agent_no_vibration_k2": "Agent, no vibration (k=2)", "agent_no_context": "Agent, no context rule",
        "audio_only": "Audio only", "vibration_only": "Vibration only", "AND_rule": "AND rule", "OR_rule": "OR rule",
        "learned_late_fusion": "Learned late fusion (LR)", "bayesian_evidence_fusion": "**Bayesian evidence fusion (ours)**"}

ep_rows = "\n".join(
    f"| {NICE.get(r['method'], r['method'])} | {r['precision']:.3f} | {r['recall']:.3f} | {r['fpr']:.3f} | "
    f"{r['false_alerts_per_benign_hour']} | {r['median_time_to_detect_s']} | {pct(r['vibration_duty_cycle'], 0)} |"
    for r in EP["summary"])
wl_rows = "\n".join(
    f"| {NICE.get(k, k)} | {m['precision']:.3f} | {m['recall']:.3f} | {m['f1']:.3f} | {m['fpr']:.3f} | "
    f"{m.get('auc', float('nan')):.3f} |" if "auc" in m else
    f"| {NICE.get(k, k)} | {m['precision']:.3f} | {m['recall']:.3f} | {m['f1']:.3f} | {m['fpr']:.3f} | – |"
    for k, m in WL["methods"].items())

readme = f"""# FORESTGUARD AI

**Evidence-aware acoustic + vibration sensing with a stateful, explainable agent for detecting
unauthorised human activity in forests.**  Ingénieux IEEE Hackathon, Track 2 (Forests & Wildlife Intelligent Sensing).

> **Evidence levels.** **REAL** = measured on real ESC-50 recordings (official 5-fold CV).
> **SIMULATED** = involves the synthetic ground-vibration channel and monitoring episodes assembled
> from held-out real clips. Simulated results measure the method under the simulator's assumptions;
> they are **not** field performance, and no real multimodal validation is claimed.

## Research question
Can an agent that demands independent vibration corroboration and temporal persistence suppress false
alerts from natural disturbances (thunder, wind, rain, livestock) without unacceptable loss of intrusion
recall, and how does that depend on vibration-sensor quality and availability?

## Headline results
| | Value | Evidence |
|---|---|---|
| 22-class audio accuracy (handcrafted features) | {pct(A['accuracy_mean'])} ± {pct(A['accuracy_std'])} | REAL |
| Threat-vs-natural F1 / AUC (audio) | {A['threat_vs_natural']['f1']:.3f} / {A['threat_vs_natural']['auc']:.3f} | REAL |
| False alerts per benign hour: stateless audio → agent | {aud['false_alerts_per_benign_hour']} → {full['false_alerts_per_benign_hour']} | SIMULATED |
| Agent episode recall (sensitive / conservative mode) | {pct(full['recall'])} / {pct(cons['recall'])} | SIMULATED |
| False-alert reduction from vibration evidence (same agent, with vs without) | {fa_ratio:.1f}× | SIMULATED |
| Vibration analysis duty cycle (on-demand) | {pct(full['vibration_duty_cycle'], 0)} | SIMULATED |
| End-to-end compute per 5 s window | {lat_total:.1f} ms ({pct(lat_total / 5000, 1)} of real time) | measured |

## Quick start
```bash
git clone --depth 1 https://github.com/karolpiczak/ESC-50.git data/ESC-50
pip install -r requirements.txt
python -m pytest -q tests          # expect: 22 passed
python scripts/run_all.py          # ~15-20 min; --quick for a 3-minute smoke run
streamlit run app/dashboard.py     # command-centre dashboard
```
Colab: open `notebooks/ForestGuard_Colab.ipynb` and run the cells in order. Each cell lists its expected
output and how to verify it. YAMNet: `python scripts/run_all.py --backend yamnet` (needs `tensorflow_hub`;
set `FG_RESULTS_DIR` to keep results separate). FSC22: `python scripts/cross_dataset_fsc22.py --inspect`.

## How it works
1. **Acoustic DSP (real audio):** 16 kHz, 80 Hz Butterworth high-pass, energy segmentation against the
   clip's own noise floor (event timestamps), log-mel/MFCC/spectral features, onset cadence, harmonic-product
   low fundamental → 22-class logistic head (out-of-fold).
2. **Vibration simulator (SIMULATED):** surface-wave spreading, anelastic absorption (Q=20, v=200 m/s),
   4.5 Hz geophone response, source distance 3–60 m. Footstep timing and engine/saw fundamentals are measured
   on the real clip. Natural sources (thunder, wind, rain, livestock) also shake the ground; unrelated animals,
   50 Hz hum and dropout are added independently of the label. CSVs carry a `# SIMULATED` header.
3. **Vibration DSP:** RMS/peak SNR, Welch FFT, dominant frequency, tonality, Hilbert envelope, peak detection,
   cadence autocorrelation, kurtosis, duty cycle, burst concentration → random-forest source family.
4. **Fusion:** Bayesian log-odds, `logit P(g|a,v) = logit P(g|a) + log LR_v(g) + frequency-match`, with
   likelihood ratios estimated by inner CV on training folds only. Missing and conflicting evidence are flagged.
5. **Agent:** weather context, on-demand vibration, sensor health, decaying belief, 30 s history, escalation
   when evidence is corroborated or persistent (bar raised where corroboration was expected but absent),
   one alert per incident, cooldown, SHA-256 hash-chained audit log with reasons for every window.

## Results
### Audio classification — REAL
| Metric | Raw | + spectral gate |
|---|---|---|
| 22-class accuracy | {pct(A['accuracy_mean'])} ± {pct(A['accuracy_std'])} | {pct(AD['accuracy_mean'])} ± {pct(AD['accuracy_std'])} |
| Macro F1 | {A['macro_f1']:.3f} | {AD['macro_f1']:.3f} |
| Threat-vs-natural precision / recall / F1 | {A['threat_vs_natural']['precision']:.3f} / {A['threat_vs_natural']['recall']:.3f} / {A['threat_vs_natural']['f1']:.3f} | {AD['threat_vs_natural']['precision']:.3f} / {AD['threat_vs_natural']['recall']:.3f} / {AD['threat_vs_natural']['f1']:.3f} |
| Threat-vs-natural FPR | {A['threat_vs_natural']['fpr']:.3f} | {AD['threat_vs_natural']['fpr']:.3f} |

Per-fold accuracy: {', '.join(pct(x) for x in A['accuracy_per_fold'])}.

### Window-level fusion — SIMULATED ({WL['n_windows']} held-out windows)
| Method | Precision | Recall | F1 | FPR | AUC |
|---|---|---|---|---|---|
{wl_rows}

### Episode-level alerting — SIMULATED ({EP['n_episodes']} × 60 s episodes, test draw seed {config.EPISODE_SEED})
| Method | Precision | Recall | Benign FPR | False alerts / benign h | Median TTD (s) | Vibration duty |
|---|---|---|---|---|---|---|
{ep_rows}

Figures: `results/figures/`. Per-scenario detection rates: `results/episode_detection_rate_by_kind.csv`.

### Protocol and honest notes
* Agent v1 was developed on a separate episode draw (seed 42). Candidate fixes were compared there with a rule
  fixed in advance (max F1 with ≤ 5 false alerts per benign hour), which chose `{SEL.get('chosen', '?')}`.
  All numbers above come from the separate test draw. On the test draw the selected mode gave
  {full['false_alerts_per_benign_hour']} false alerts per hour, against {selrow.get(SEL.get('chosen'), {}).get('false_alerts_per_benign_hour', '?')} on the development draw.
* Learned late fusion is {'slightly better than' if WL['methods']['learned_late_fusion']['f1'] >= WL['methods']['bayesian_evidence_fusion']['f1'] else 'comparable to'} our fusion at single-window F1; the advantage of our design shows at the episode level and in explainability.
* The spectral-gate denoiser lowered accuracy and is off by default.
* The weather-context rule {'had no measurable effect' if ctx_null else 'had a small effect'}.
* Brief single-window human presence is escalated in only {pct(K['agent_full']['brief_presence'], 0)} of episodes, a deliberate trade-off.
* Fireworks stands in for gunshots (ESC-50 has no gunshot class). YAMNet and FSC22 are implemented but were not run in the build environment.

## Project layout
```
forestguard/   config, data, audio_dsp, audio_models, vibration_sim, vibration_dsp, fusion, agent, pipeline, experiments
scripts/       run_all.py, select_agent.py, figures.py, diagrams.py, cross_dataset_fsc22.py, build_docs.py
app/           dashboard.py (Streamlit command centre)
tests/         test_decision_logic.py (22 tests)
notebooks/     ForestGuard_Colab.ipynb
results/       metrics JSON/CSV, figures, vibration_csv/ (SIMULATED), example_audit_log.jsonl
report/        build_report.js (Word report generator)
```

## Data and attribution
* **ESC-50**: K. J. Piczak, "ESC: Dataset for Environmental Sound Classification", ACM MM 2015.
  CC BY-NC 3.0; clips originate from freesound.org.
* **FSC22**: M. Bandara et al., "Forest Sound Classification Dataset: FSC22", *Sensors* 23(4):2032, 2023.
* **YAMNet**: Google, TensorFlow Hub `google/yamnet/1`, trained on AudioSet (Gemmeke et al., ICASSP 2017).
* Vibration data are generated by this project and are synthetic.
"""
(ROOT / "README.md").write_text(readme)

sub = ROOT / "submission"
sub.mkdir(exist_ok=True)
pitch = f"""# FORESTGUARD AI — pitch, technical explanation, demo script and judges' Q&A

All numbers come from `results/results_summary.json`. Say "simulated" whenever a number involves vibration.

## 60-second pitch
Forest acoustic monitors don't fail because they miss chainsaws. They fail because thunder, wind and grazing
cattle sound like threats, and rangers stop trusting them. In our simulation, a stateless detector alerting on
every suspicious window raises **{aud['false_alerts_per_benign_hour']} false alerts per hour** of quiet forest.

FORESTGUARD treats a loud sound as a claim, not a verdict. A geophone asks whether the ground agrees. A stateful
agent asks whether the evidence persists, wakes the vibration sensor only when audio is suspicious, and explains
every decision in a tamper-evident log.

On {EP['n_episodes']} simulated monitoring episodes built from held-out real recordings, the agent cuts false alerts to
**{full['false_alerts_per_benign_hour']} per hour** while still catching **{pct(full['recall'], 0)}** of intrusions, and
{pct(K['agent_full']['logging'], 0)} of logging events. Vibration evidence alone accounts for a **{fa_ratio:.1f}×** reduction. The audio
model is validated on real data; the vibration channel is simulated, and we say so. The next step is a real
geophone pilot. Everything runs in about {lat_total:.0f} ms per 5-second window, so it fits on a solar-powered node.

## 3-minute technical explanation
1. **Problem (20 s).** Decide every 5 seconds whether to keep monitoring, gather more evidence or call a ranger,
   using a microphone and a ground-vibration sensor, under noise, missing data and natural look-alikes.
2. **Signal processing (40 s).** Audio: 80 Hz high-pass, energy segmentation against the clip's own noise floor,
   log-mel/MFCC features, onset cadence and a harmonic-product fundamental, feeding a 22-class model with
   {pct(A['accuracy_mean'])} accuracy (real ESC-50, official folds). Vibration: RMS and peak SNR, Welch FFT, dominant frequency,
   Hilbert envelope, peak detection and gait-cadence autocorrelation, feeding a source-family classifier.
3. **Simulator honesty (30 s).** No paired forest dataset exists, so we simulate the geophone with physics:
   distance attenuation that kills high frequencies, natural sources that also shake the ground, unrelated animals,
   hum and dropout. Footstep timing and engine frequencies come from the real recording. Every file says SIMULATED.
4. **Fusion (30 s).** Bayesian log-odds. The likelihood ratio for each threat type is learned on training folds,
   so "no vibration" counts heavily against a vehicle but barely against a voice. A frequency-match check
   confirms that sound and vibration share one source.
5. **Agent (40 s).** Context, active sensing, sensor health, decaying belief and 30 s memory. It escalates on
   corroboration or persistence and raises the bar when expected corroboration is missing. One alert per incident,
   cooldown, and a SHA-256 chained log with reasons.
6. **Evidence (20 s).** Stateless audio: {aud['false_alerts_per_benign_hour']}/h. Agent: {full['false_alerts_per_benign_hour']}/h at {pct(full['recall'], 0)} recall.
   Same agent without vibration: {nov['false_alerts_per_benign_hour']}/h. Development and test draws are separate, ablations are fair,
   and sweeps show the false-alarm benefit survives weak coupling. Heavy dropout costs recall, and we show that too.

## 5-minute demonstration script
| Time | Do | Say |
|---|---|---|
| 0:00 | Dashboard header, KPI tiles | "One node, 5-second windows. Real audio badge, simulated vibration badge, always visible." |
| 0:30 | Sidebar → scenario **logging**, fold 1 | "A 60-second patrol from held-out clips: chainsaw windows inside background sound." |
| 0:50 | Live monitor timeline | "Blue is audio-only threat probability, orange is fused. Red bands are the true intrusion. The dashed line is the alert." |
| 1:30 | Alert card | "Every alert says why: type, confidence, corroborated or persistence-only." |
| 1:50 | Tab **Signals**, choose a chainsaw window | "Real spectrogram with detected segments, the classifier's top five, the simulated geophone and its FFT. The dominant frequency is compared with the audio fundamental." |
| 2:40 | Cross-correlation plot | "Sound and ground envelopes line up in time: independent evidence of one source." |
| 3:00 | Scenario **storm** | "Thunder is loud and shakes the ground. The agent recognises a weather pattern and does not escalate." |
| 3:30 | Dropout slider to 0.6, re-run **foot_patrol** | "Vibration keeps dropping out. The agent records each gap and flags the sensor for maintenance. Our sweeps show this is our weakest case: at heavy dropout it misses more than a no-vibration agent, and switching policy on that flag is the next fix." |
| 4:00 | Tab **Agent decisions** | "The hash-chained log: reasons, evidence terms and hashes. Edit one record and verification fails; that's a unit test." |
| 4:30 | Tab **Experiments** | "Real audio metrics, simulated fusion and episode results, and the trade-off plot. Then limits: the vibration is simulated, and brief single-window presence is often not escalated." |

## Likely judges' questions
**Q: Isn't fusion trivially good because you simulated the vibration from the labels?**
A: We designed against that. Natural sources also produce vibration (thunder, wind, rain, livestock with
human-like cadence). Distance is random, so many threats are invisible to the geophone. Unrelated animals, hum and
dropout are added independently of the label. Vibration alone reaches only F1 {WL['methods']['vibration_only']['f1']:.3f} and
recall {WL['methods']['vibration_only']['recall']:.3f}. We also report sweeps over sensor strength and dropout rather than one number.
The remaining caveat is that footstep timing and engine frequencies come from the audio, so the frequency-match benefit is
partly built in. We state that in the limitations.

**Q: What is actually real?**
A: Every audio clip, every audio probability (out-of-fold on official folds), all acoustic DSP, and the
{pct(A['accuracy_mean'])} accuracy and {A['threat_vs_natural']['f1']:.3f} threat F1. The vibration channel and episodes are simulated.

**Q: Why not a neural fusion model?**
A: A learned late-fusion baseline is in the table (window F1 {WL['methods']['learned_late_fusion']['f1']:.3f} against our {WL['methods']['bayesian_evidence_fusion']['f1']:.3f}).
Our Bayesian form gives per-type likelihood ratios the agent can reason with and explain, and it needs very little data.

**Q: How is this agentic, not just a classifier with a threshold?**
A: It keeps state (belief and history), acts on its own sensing (wakes the geophone, costing energy only when
needed: {pct(full['vibration_duty_cycle'], 0)} duty cycle with no loss against always-on), adapts to context and sensor health, changes its evidence
bar depending on what corroboration should exist, and chooses among actions with an explanation for each.

**Q: Did you tune on the test set?**
A: No. v1 was developed on a seed-42 episode draw. Fixes were selected there with a rule fixed beforehand, and every
reported episode result is on a separate seed-{config.EPISODE_SEED} draw. That's also why we report the gap: the selected mode gave
{selrow.get(SEL.get('chosen'), {}).get('false_alerts_per_benign_hour', '?')}/h on development but {full['false_alerts_per_benign_hour']}/h on test.

**Q: What happens when the geophone fails?**
A: The agent flags maintenance after three missing windows in five, and keeps alerting from audio with a higher evidence bar. Honestly, that bar is too high when the sensor is mostly gone: at 80% dropout recall is {sw('dropout_p', 0.8, 'agent_full', 'recall'):.2f} against {sw('dropout_p', 0.8, 'agent_no_vibration_k2', 'recall'):.2f} for a no-vibration agent. Switching to the no-vibration policy when the sensor is flagged is the first fix on our list.

**Q: Why is brief presence detection low?**
A: A single 5-second voice or step is weak evidence. We deliberately require persistence or corroboration, which is what
cuts false alerts. A department that wants that recall can lower k, at a measurable false-alarm cost shown by the ablations.

**Q: Gunshots?**
A: ESC-50 has no gunshot class, so fireworks is a labelled proxy with a single-event escalation rule. Validating it
on real gunshot recordings is future work.

**Q: Real-world cost and power?**
A: Roughly ₹10,000–19,000 per node in indicative parts (MEMS microphone, geophone and ADC, ESP32/RPi-class compute,
LoRa, 10 W solar). Compute is {lat_total:.0f} ms per 5 s window on a desktop core, and only events are transmitted.

**Q: Next research question?**
A: Does vibration corroboration still cut false alerts several-fold with real geophones in real soil? A paired pilot
with patrol-log ground truth answers it. After that: multi-node corroboration, localisation and learning
thresholds from ranger feedback.

**Q: Privacy?**
A: Audio stays on the node. Voices are classified only as presence, never recorded or transcribed. Only compact event
messages are sent.
"""
(sub / "PITCH_AND_QA.md").write_text(pitch)

check = f"""# Submission checklist

The official problem statement lists no fixed deliverables. This maps its rubric to evidence.

| Rubric criterion (points) | Where the evidence is | Status |
|---|---|---|
| Research novelty (15) | Report §3, §10; coupling-aware fusion; agent evaluated as an alert policy | Done |
| Technical integration: agentic AI (13) | `forestguard/agent.py`, report §5.5, audit log, 22 tests | Done |
| Technical integration: signal processing (12) | `audio_dsp.py`, `vibration_dsp.py`, report §5.1–5.3, Figure 9 | Done |
| Experiments and evaluation (20) | Report §9: baselines, ablations, sweeps, latency; `results/` | Done |
| Problem significance (10) | Report §2 | Done |
| Research potential (15) | Report §12–13, next research question | Done |
| Prototype evidence (10) | Dashboard, screenshots, `example_audit_log.jsonl`, CSV exports | Done |
| Reproducibility (5) | README, Colab notebook, `run_all.py`, fixed seeds, requirements | Done |

## Files
- [ ] Source code zip (`forestguard_source.zip`)
- [ ] Word report (`FORESTGUARD_Technical_Report.docx`) and PDF
- [ ] Slides (Claude Slides; export to PPTX or PDF)
- [ ] Pitch, demo script, Q&A (`PITCH_AND_QA.md`)
- [ ] Dashboard screenshots (`screenshots/`)
- [ ] Results and figures (`results/`)

## Before presenting
- [ ] Add team members' names to the report title page and slides
- [ ] Run `python -m pytest -q tests` live if asked (expect 22 passed)
- [ ] Optional in Colab: YAMNet run (`--backend yamnet`) and FSC22 cross-dataset test; add the numbers only if run
- [ ] Every vibration number is said aloud as "simulated"
"""
(sub / "SUBMISSION_CHECKLIST.md").write_text(check)
print("docs written")
