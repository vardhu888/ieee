"""Agent configuration selection on the DEVELOPMENT episode draw (seed 42).

Selection rule (fixed before running): highest episode F1 among candidate
configurations with <= 5 false alerts per benign monitoring hour.
Reported test results use the separate draw config.EPISODE_SEED.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from forestguard import audio_models, config, data, pipeline  # noqa: E402
from forestguard import experiments as E  # noqa: E402
from forestguard import vibration_sim as vs  # noqa: E402
from forestguard.agent import AgentConfig  # noqa: E402

DEV_SEED = 42
FA_BUDGET = 5.0
CANDIDATES = {
    "v1_separate_strict": AgentConfig(merge_human=False, expectation_aware_bar=False),
    "merge_human_only": AgentConfig(merge_human=True, expectation_aware_bar=False),
    "expectation_bar_only": AgentConfig(merge_human=False, expectation_aware_bar=True),
    "v2_both": AgentConfig(merge_human=True, expectation_aware_bar=True),
}

if __name__ == "__main__":
    config.ensure_dirs()
    df = data.load_esc50()
    X, _ = audio_models.extract_features(df, "handcrafted", denoise=False)
    oof, _ = audio_models.crossval_oof(df, X, config.FOREST_CLASSES)
    hints = pipeline.audio_hints(df)
    params = vs.SimParams()
    models, _ = pipeline.train_vibration_models(df, hints, params)
    eps = E.build_episode_observations(df, oof, hints, models, params, 20, tag="dev", seed=DEV_SEED)
    s = E.summarize_episodes(E.run_episode_methods(eps, models, CANDIDATES))
    s = s[s.method.isin(CANDIDATES)]
    ok = s[s.false_alerts_per_benign_hour <= FA_BUDGET]
    chosen = (ok if len(ok) else s).sort_values("f1", ascending=False).iloc[0]["method"]
    s.to_csv(config.RESULTS_DIR / "agent_selection_dev.csv", index=False)
    (config.RESULTS_DIR / "agent_selection_dev.json").write_text(json.dumps(
        {"dev_seed": DEV_SEED, "rule": f"max F1 with <= {FA_BUDGET} false alerts per benign hour",
         "chosen": chosen, "candidates": s.to_dict(orient="records")}, indent=2))
    print(s[["method", "precision", "recall", "f1", "fpr", "false_alerts_per_benign_hour"]].to_string())
    print("CHOSEN:", chosen)
