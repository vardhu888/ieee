"""Run every FORESTGUARD experiment and write results, figures, CSV exports,
an example audit log and the dashboard bundle.

Usage:
    python scripts/run_all.py                 # handcrafted backend (runs anywhere)
    python scripts/run_all.py --backend yamnet  # Colab: YAMNet embeddings
    python scripts/run_all.py --quick         # smaller episode counts
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from forestguard import audio_models, config, data, pipeline  # noqa: E402
from forestguard import experiments as E  # noqa: E402
from forestguard import vibration_sim as vs  # noqa: E402
from forestguard.agent import AgentConfig, ForestGuardAgent  # noqa: E402
from forestguard.logging_utils import get_logger  # noqa: E402
from scripts import figures  # noqa: E402

log = get_logger("run_all")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", default="handcrafted", choices=["handcrafted", "yamnet"])
    ap.add_argument("--episodes", type=int, default=20, help="episodes per scenario type per fold")
    ap.add_argument("--sweep-episodes", type=int, default=6)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--skip-sweeps", action="store_true")
    a = ap.parse_args()
    if a.quick:
        a.episodes, a.sweep_episodes = 4, 3
    config.ensure_dirs()
    R = config.RESULTS_DIR
    T0 = time.time()
    summary = {"run": {"backend": a.backend, "seed": config.SEED, "episodes_per_type_per_fold": a.episodes,
                       "started": time.strftime("%Y-%m-%d %H:%M:%S")}}

    # ---------------------------------------------- 1. audio (REAL)
    df = data.load_esc50()
    data.summarize(df).to_csv(R / "dataset_summary.csv", index=False)
    log.info("== Audio classification (REAL), backend=%s", a.backend)
    X, t_feat = audio_models.extract_features(df, a.backend, denoise=False)
    oof, t_head = audio_models.crossval_oof(df, X, config.FOREST_CLASSES)
    oof.to_csv(R / f"audio_oof_{a.backend}.csv", index=False)
    summary["audio"] = E.audio_experiment(df, oof, {**t_feat, **t_head}, a.backend)
    if a.backend == "handcrafted":
        Xd, td = audio_models.extract_features(df, "handcrafted", denoise=True)
        oofd, thd = audio_models.crossval_oof(df, Xd, config.FOREST_CLASSES)
        summary["audio_ablation_denoise"] = E.audio_experiment(df, oofd, {**td, **thd}, "handcrafted_denoised")
    hints = pipeline.audio_hints(df)

    # ------------------------------------- 2. vibration + window level (SIMULATED)
    params = vs.SimParams()
    summary["sim_params"] = vs.params_dict(params)
    log.info("== Vibration models (SIMULATED)")
    models, vmeta = pipeline.train_vibration_models(df, hints, params)
    vmeta.to_csv(R / "vibration_training_meta.csv", index=False)
    summary["vibration_feature_importance"] = {k: round(float(v), 4) for k, v in
                                               list(models[1].family_clf.feature_importance().items())[:10]}
    wd = E.window_dataset(df, oof, hints, models, params)
    wd.to_csv(R / "window_level_predictions.csv", index=False)
    summary["window_level"] = E.window_experiment(wd)

    # CSV export: one simulated window per clip for two clips of every class
    sample = df.groupby("category").head(2)
    for fn, cat in zip(sample["filename"], sample["category"]):
        w = vs.simulate_window(fn, cat, params, audio_hint=hints[fn], scenario_key="test")
        vs.to_csv(w, config.VIB_DIR / f"SIM_{Path(fn).stem}_{cat}.csv")
    summary["vibration_csv_exported"] = int(len(sample))

    # ------------------------------------- 3. episodes (SIMULATED)
    log.info("== Episodes (SIMULATED): %d per type per fold", a.episodes)
    eps = E.build_episode_observations(df, oof, hints, models, params, a.episodes)
    er = E.run_episode_methods(eps, models)
    er.to_csv(R / "episode_results.csv", index=False)
    ep_sum = E.summarize_episodes(er)
    ep_sum.to_csv(R / "episode_summary.csv", index=False)
    pk = E.per_kind(er)
    pk.to_csv(R / "episode_detection_rate_by_kind.csv")
    summary["episodes"] = {"n_episodes": int(er[er.method == "agent_full"].shape[0]),
                           "summary": ep_sum.to_dict(orient="records"),
                           "detection_rate_by_kind": pk.to_dict(orient="index")}

    # latency of each stage (per 5-second window)
    agent_ms = float(er.loc[er.method == "agent_full", "agent_ms"].mean())
    vib_ms = float(np.mean([ex["vib_ms"] for _, ol in eps[:200] for _, ex in ol if ex["vib_ms"] > 0]))
    summary["latency_ms_per_window"] = {
        "audio_preprocess": round(t_feat["preprocess_ms"], 2), "audio_features": round(t_feat["featurize_ms"], 2),
        "audio_head": round(t_head["head_infer_ms"], 4), "vibration_analysis_and_classifier": round(vib_ms, 2),
        "fusion_and_agent": round(agent_ms, 3),
        "note": "single CPU core of the build machine; window length 5000 ms"}

    # ------------------------------------- 4. example audit log
    demo = next(ep for ep in eps if ep[0]["kind"] == "logging")
    ag = ForestGuardAgent(models[demo[0]["fold"]].lik, AgentConfig())
    for o, _ in demo[1]:
        ag.step(o)
    ag.log.to_jsonl(R / "example_audit_log.jsonl")
    summary["example_audit_log"] = {"kind": demo[0]["kind"], "categories": demo[0]["categories"],
                                    "alerts": ag.alerts, "chain_verified": ag.log.verify()}

    # ------------------------------------- 5. sweeps (SIMULATED)
    if not a.skip_sweeps:
        log.info("== Sensitivity sweeps (SIMULATED)")
        sw1 = E.sweep(df, oof, hints, params, "snr_scale", [0.25, 0.5, 1.0, 2.0], a.sweep_episodes)
        sw1.to_csv(R / "sweep_snr_scale.csv", index=False)
        sw2 = E.sweep(df, oof, hints, params, "dropout_p", [0.0, 0.2, 0.5, 0.8], a.sweep_episodes)
        sw2.to_csv(R / "sweep_dropout.csv", index=False)
        summary["sweeps"] = {"snr_scale": sw1.to_dict(orient="records"), "dropout_p": sw2.to_dict(orient="records")}

    # ------------------------------------- 6. dashboard bundle
    with open(config.CACHE_DIR / "dashboard_bundle.pkl", "wb") as f:
        pickle.dump({"oof": oof, "hints": hints, "models": models, "df": df, "params": params,
                     "backend": a.backend}, f)

    sel = R / "agent_selection_dev.json"
    if sel.exists():
        summary["agent_selection_dev"] = json.loads(sel.read_text())
    summary["run"]["seconds"] = round(time.time() - T0, 1)
    (R / "results_summary.json").write_text(json.dumps(summary, indent=2, default=str))
    figures.make_all(R)
    log.info("All done in %.0f s. Results in %s", time.time() - T0, R)


if __name__ == "__main__":
    main()
