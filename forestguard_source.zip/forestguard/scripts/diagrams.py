"""System architecture, agent workflow and deployment diagrams (PNG)."""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from forestguard import config  # noqa: E402

SURF, INK, INK2, LINE = "#fcfcfb", "#0b0b0b", "#52514e", "#b9b8b3"
BLUE, ORANGE, AQUA, RED = "#cde2fb", "#fbe0d3", "#d3f1e5", "#f7d6d6"
BLUE_E, ORANGE_E, AQUA_E, RED_E = "#2a78d6", "#eb6834", "#1baf7a", "#d03b3b"


def box(ax, x, y, w, h, title, body="", fc=BLUE, ec=BLUE_E, fs=9.5):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.003,rounding_size=0.012",
                                fc=fc, ec=ec, lw=1.6))
    ax.text(x + w / 2, y + h - 0.025, title, ha="center", va="top", fontsize=fs, fontweight="bold", color=INK)
    if body:
        ax.text(x + w / 2, y + h - 0.065, body, ha="center", va="top", fontsize=fs - 2, color=INK2, linespacing=1.35)


def arrow(ax, p, q, text="", color=INK2, rad=0.0):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=14, color=color, lw=1.5,
                                 connectionstyle=f"arc3,rad={rad}"))
    if text:
        ax.text((p[0] + q[0]) / 2, (p[1] + q[1]) / 2 + 0.015, text, ha="center", fontsize=7.5, color=INK2)


def canvas(w=13, h=7):
    fig, ax = plt.subplots(figsize=(w, h))
    fig.patch.set_facecolor(SURF)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    return fig, ax


def architecture(out: Path):
    fig, ax = canvas()
    ax.text(0.01, 0.98, "FORESTGUARD AI — system architecture", fontsize=14, fontweight="bold", va="top")
    ax.text(0.01, 0.935, "Blue: real audio path  ·  Orange: SIMULATED vibration path  ·  Green: decision layer",
            fontsize=9, color=INK2, va="top")
    box(ax, 0.01, 0.62, 0.14, 0.22, "Microphone", "ESC-50 clips (real)\n16 kHz mono\n5 s windows")
    box(ax, 0.18, 0.62, 0.18, 0.22, "Acoustic DSP", "80 Hz high-pass\nspectral gate (ablated)\nenergy segmentation\nlog-mel, MFCC, onsets, f0")
    box(ax, 0.39, 0.62, 0.17, 0.22, "Audio classifier", "handcrafted 226-d or\nYAMNet 2048-d embedding\n→ logistic head\n22 classes, OOF")
    box(ax, 0.01, 0.20, 0.14, 0.24, "Geophone", "SIMULATED\nphysics generator\n500 Hz, 4.5 Hz corner\ndropout, hum", ORANGE, ORANGE_E)
    box(ax, 0.18, 0.20, 0.18, 0.24, "Vibration DSP", "RMS / SNR, Welch FFT\ndominant freq, tonality\nHilbert envelope, peaks\ncadence autocorrelation", ORANGE, ORANGE_E)
    box(ax, 0.39, 0.20, 0.17, 0.24, "Source-family model", "random forest (100 trees)\nhuman / animal gait,\nmachinery, transient,\nweather, none", ORANGE, ORANGE_E)
    box(ax, 0.60, 0.40, 0.17, 0.26, "Evidence fusion", "Bayesian log-odds\nlikelihood ratios from\ntraining folds\nfrequency-match check\nmissing / conflict flags", AQUA, AQUA_E)
    box(ax, 0.80, 0.40, 0.19, 0.26, "Stateful agent", "context · wakes vibration\nanalysis on demand\nsensor health\ndecaying belief\npersistence + corroboration\nhash-chained audit log", AQUA, AQUA_E)
    box(ax, 0.80, 0.08, 0.19, 0.20, "Actions", "continue monitoring\nwatch / activate vibration\nescalate to ranger\nflag maintenance", RED, RED_E)
    box(ax, 0.58, 0.08, 0.19, 0.20, "Command centre", "Streamlit dashboard\nalerts with reasons\nhuman verification", RED, RED_E)
    arrow(ax, (0.15, 0.73), (0.18, 0.73)); arrow(ax, (0.36, 0.73), (0.39, 0.73))
    arrow(ax, (0.15, 0.32), (0.18, 0.32)); arrow(ax, (0.36, 0.32), (0.39, 0.32))
    arrow(ax, (0.56, 0.71), (0.60, 0.62))
    ax.text(0.585, 0.70, "P(class), f0", fontsize=7.5, color=INK2)
    arrow(ax, (0.56, 0.32), (0.60, 0.44))
    ax.text(0.585, 0.33, "P(family)", fontsize=7.5, color=INK2)
    arrow(ax, (0.08, 0.62), (0.08, 0.44), "", ORANGE_E)
    ax.text(0.09, 0.53, "real onsets / f0\nparameterise the simulator", fontsize=7.5, color=ORANGE_E)
    arrow(ax, (0.77, 0.53), (0.80, 0.53))
    arrow(ax, (0.895, 0.40), (0.895, 0.28))
    arrow(ax, (0.80, 0.18), (0.77, 0.18))
    fig.savefig(out / "architecture.png", dpi=170, bbox_inches="tight"); plt.close(fig)


def agent_workflow(out: Path):
    fig, ax = canvas(13, 6.2)
    ax.text(0.01, 0.98, "Agent decision loop (every 5 s window)", fontsize=14, fontweight="bold", va="top")
    steps = [("1 Context", "weather EMA from\naudio; storm mode"),
             ("2 Sense", "wake vibration if\nP(threat)≥0.3 or\ninvestigation open"),
             ("3 Health", "dropout count,\nnoise-floor drift →\ndown-weight sensor"),
             ("4 Fuse", "log-odds + LR(v)\n+ freq match;\nflag missing/conflict"),
             ("5 Remember", "decaying belief\nper threat type;\n30 s history"),
             ("6 Decide", "rules below;\nraise bar if not\ncorroborated"),
             ("7 Record", "reasons + evidence\nSHA-256 chained\naudit record")]
    for i, (t, b) in enumerate(steps):
        box(ax, 0.01 + i * 0.141, 0.60, 0.122, 0.26, t, b, AQUA, AQUA_E, fs=10)
        if i:
            arrow(ax, (0.01 + i * 0.141 - 0.016, 0.73), (0.01 + i * 0.141, 0.73))
    box(ax, 0.02, 0.06, 0.30, 0.42, "Escalate to ranger if any:",
        "• P(type) ≥ 0.97 and vibration log-LR ≥ 1\n   (independent corroboration now)\n"
        "• blast-like event P ≥ 0.90 (single event)\n"
        "• suspicious windows of same type in 30 s ≥ k\n"
        "   k = 2 if corroborated, 3 if not,\n   +1 in storm for vehicle/logging/blast",
        RED, RED_E, fs=10)
    for j, (s, c, e, d) in enumerate([("MONITORING", BLUE, BLUE_E, "default; vibration asleep"),
                                      ("WATCH", ORANGE, ORANGE_E, "suspicious evidence;\nvibration active"),
                                      ("ESCALATED", RED, RED_E, "one alert per incident;\nno duplicates")]):
        box(ax, 0.40 + j * 0.2, 0.18, 0.16, 0.22, s, d, c, e, fs=10)
    arrow(ax, (0.56, 0.32), (0.60, 0.32)); ax.text(0.58, 0.34, "suspicious", ha="center", fontsize=8, color=INK2)
    arrow(ax, (0.76, 0.32), (0.80, 0.32)); ax.text(0.78, 0.34, "rule met", ha="center", fontsize=8, color=INK2)
    arrow(ax, (0.88, 0.18), (0.48, 0.18), "", INK2, rad=-0.25)
    ax.text(0.68, 0.035, "4 quiet windows → de-escalate (from WATCH or ESCALATED)", ha="center", fontsize=8, color=INK2)
    fig.savefig(out / "agent_workflow.png", dpi=170, bbox_inches="tight"); plt.close(fig)


def deployment(out: Path):
    fig, ax = canvas(13, 6)
    ax.text(0.01, 0.98, "Proposed field deployment (future work — not validated)", fontsize=14, fontweight="bold", va="top")
    for i in range(3):
        box(ax, 0.02, 0.62 - i * 0.26, 0.26, 0.22, f"Sensor node {i + 1}",
            "MEMS mic + 4.5 Hz geophone\nMCU runs DSP + agent\nsolar panel + Li-ion\nevents only, no raw audio")
        arrow(ax, (0.28, 0.73 - i * 0.26), (0.40, 0.55), "LoRa event\n< 100 B")
    box(ax, 0.40, 0.42, 0.18, 0.24, "Gateway", "LoRaWAN / 4G\nbuffers if offline\ncross-node checks", ORANGE, ORANGE_E)
    box(ax, 0.64, 0.42, 0.18, 0.24, "Central monitoring", "alerts + reasons\nmap of nodes\nnode health", AQUA, AQUA_E)
    box(ax, 0.86, 0.42, 0.13, 0.24, "Ranger", "verifies on site;\nfeedback labels\nretrain", RED, RED_E)
    arrow(ax, (0.58, 0.54), (0.64, 0.54)); arrow(ax, (0.82, 0.54), (0.86, 0.54))
    arrow(ax, (0.92, 0.42), (0.18, 0.08), "verified labels → recalibrate thresholds per site", INK2, rad=-0.15)
    fig.savefig(out / "deployment.png", dpi=170, bbox_inches="tight"); plt.close(fig)


if __name__ == "__main__":
    o = config.RESULTS_DIR / "figures"
    o.mkdir(parents=True, exist_ok=True)
    architecture(o); agent_workflow(o); deployment(o)
    print("diagrams written to", o)
